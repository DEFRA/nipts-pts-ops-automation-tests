// Stages the SPA for deployment: build/web/ (no bundler by design — JSX is transpiled in the browser).
// config.js is NOT copied: the CDK deployment generates it per environment.
import { cpSync, existsSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const src = join(root, 'web');
const out = join(root, 'build', 'web');

rmSync(out, { recursive: true, force: true });
mkdirSync(out, { recursive: true });

const skip = new Set(['config.js', 'config.example.js']);
for (const name of readdirSync(src)) {
  if (!skip.has(name)) cpSync(join(src, name), join(out, name), { recursive: true });
}

// CloudFront serves "/" from index.html; keep the original file name for existing bookmarks.
const entry = join(out, 'Carbon Cost Dashboard.html');
if (!existsSync(entry)) throw new Error('web/Carbon Cost Dashboard.html is missing');
cpSync(entry, join(out, 'index.html'));

console.log(`SPA staged in ${out} (${readdirSync(out).length} files)`);
