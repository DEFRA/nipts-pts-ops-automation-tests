import { emitMetric, logger } from '../logger';
import { getRepository } from '../repo';
import { resumeDeferred } from '../services/adoSync';
import { ingestCarbonOnce } from '../services/ingestService';

export interface SchedulerEvent {
  task: 'ingest_carbon' | 'resume_deferred';
}

/** Invoked by EventBridge Scheduler (ingest every 30 min, resume every 5 min). Throws on failure so retries/DLQ engage. */
export async function handler(event: SchedulerEvent): Promise<{ task: string; count: number }> {
  const repo = getRepository();
  const start = Date.now();
  try {
    let count: number;
    switch (event.task) {
      case 'ingest_carbon':
        count = await ingestCarbonOnce(repo);
        break;
      case 'resume_deferred':
        count = await resumeDeferred(repo);
        break;
      default:
        throw new Error(`Unknown task: ${(event as { task?: string }).task}`);
    }
    emitMetric('SchedulerTaskDuration', Date.now() - start, 'Milliseconds', { Task: event.task });
    emitMetric('SchedulerTaskItems', count, 'Count', { Task: event.task });
    logger.info({ task: event.task, count }, 'scheduler task complete');
    return { task: event.task, count };
  } catch (err) {
    logger.error({ err, task: event.task }, 'scheduler task failed');
    throw err;
  }
}
