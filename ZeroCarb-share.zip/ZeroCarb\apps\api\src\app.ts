import cors from 'cors';
import express, { type ErrorRequestHandler } from 'express';
import helmet from 'helmet';
import { randomUUID } from 'node:crypto';
import { envList } from './config';
import { authenticate, authMode, type AuthMode, type TokenVerifier } from './http/auth';
import { HttpError } from './http/errors';
import { protectedRoutes, publicRoutes } from './http/routes';
import { logger } from './logger';
import { getRepository } from './repo';
import type { Repository } from './repo/types';

export interface AppDeps {
  repo?: Repository;
  mode?: AuthMode;
  verifier?: TokenVerifier;
  version?: string;
}

export function createApp(deps: AppDeps = {}) {
  const repo = deps.repo ?? getRepository();
  const mode = deps.mode ?? authMode();
  const version = deps.version ?? process.env.APP_VERSION ?? 'dev';

  const app = express();
  app.disable('x-powered-by');
  app.set('trust proxy', true);

  app.use((req, res, next) => {
    req.requestId = req.header('x-request-id') ?? req.header('x-amzn-trace-id') ?? randomUUID();
    res.setHeader('x-request-id', req.requestId);
    next();
  });
  app.use(helmet());
  // Same-origin behind CloudFront in AWS; CORS is only for local dev against a separate static server.
  const origins = envList('CORS_ALLOWED_ORIGINS', []);
  if (origins.length) {
    app.use(cors({ origin: origins, methods: ['GET', 'POST', 'OPTIONS'], allowedHeaders: ['Content-Type', 'Accept', 'Authorization'], maxAge: 600 }));
  }
  app.use('/api', (_req, res, next) => { res.setHeader('Cache-Control', 'no-store'); next(); });
  app.use(express.json({ limit: '512kb' }));

  app.use((req, res, next) => {
    const start = Date.now();
    res.on('finish', () => {
      logger.info({ requestId: req.requestId, method: req.method, path: req.path, status: res.statusCode, ms: Date.now() - start, sub: req.principal?.sub }, 'request');
    });
    next();
  });

  const api = express.Router();
  api.use(publicRoutes(repo, mode, version));
  api.use(authenticate(mode, deps.verifier));
  api.use(protectedRoutes(repo));
  app.use('/api', api);

  app.use((_req, res) => { res.status(404).json({ error: 'not_found' }); });

  const onError: ErrorRequestHandler = (err, req, res, _next) => {
    if (err instanceof HttpError) {
      return res.status(err.status).json({ error: err.message, ...err.extra });
    }
    if (err?.type === 'entity.parse.failed' || err instanceof SyntaxError) return res.status(400).json({ error: 'Body must be JSON' });
    if (err?.type === 'entity.too.large') return res.status(413).json({ error: 'payload_too_large' });
    logger.error({ err, requestId: req.requestId, path: req.path }, 'unhandled error');
    // Internals stay in the logs; clients get a correlation id.
    res.status(500).json({ error: 'internal', request_id: req.requestId });
  };
  app.use(onError);
  return app;
}
