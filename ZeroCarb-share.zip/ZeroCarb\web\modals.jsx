/* global React, useStore, CCD_DATA */
// =======================================================================
// Modals: Connect Azure, Override Budget, Apply Recommendation,
//         Run Now, Weekly Digest
// All use the store's openModal({ element, onClose })
// =======================================================================

// ----- Reusable shell -----
function ModalShell({ title, subtitle, children, onClose, footer }) {
  return (
    <div className="modal-inner">
      <header className="modal-head">
        <div>
          <div className="modal-eyebrow">CARBON-AWARE WORKFLOW</div>
          <h2 className="modal-title">{title}</h2>
          {subtitle && <p className="modal-sub">{subtitle}</p>}
        </div>
        <button className="modal-close" aria-label="Close" onClick={onClose}>×</button>
      </header>
      <div className="modal-body">{children}</div>
      {footer && <footer className="modal-foot">{footer}</footer>}
    </div>
  );
}

// ----- Azure Configuration (Org URL + PAT) -----
// Initial configuration panel for connecting Azure DevOps. The PAT is sent
// once to POST /api/ado/connect and persisted backend-side — it never returns
// to the browser. On success the store marks the connection live and pulls
// the pipeline catalogue this deployment governs.
function AzureConfigModal({ onClose, tabs }) {
  const { toast, setConnected, azure, disconnectAzure } = useStore();
  const api = window.greenQaApi;

  const [orgUrl, setOrgUrl] = React.useState(
    azure.orgUrl || window.GREEN_QA_DEFAULT_ORG_URL || ''
  );
  const [pat, setPat]       = React.useState('');
  const [busy, setBusy]     = React.useState(false);
  const [result, setResult] = React.useState(null); // { ok, message } | { error }

  const alreadyConnected = azure.connected;

  const connect = () => {
    if (!api || !api.isConfigured()) {
      setResult({ error: 'API base URL is not configured (window.GREEN_QA_API_URL).' });
      return;
    }
    setBusy(true);
    setResult(null);
    api.adoConnect({ org_url: orgUrl, pat }).then((res) => {
      setBusy(false);
      if (res.ok && res.data && res.data.connected) {
        setConnected(res.data);
        setResult({ ok: true, message: res.data.message || ('Connected to ' + res.data.organization + '.') , data: res.data });
        toast({
          kind: 'success',
          title: 'Azure DevOps connected',
          message: 'Connected to ' + res.data.organization,
          detail: 'Loading pipelines…'
        });
      } else {
        setResult({ error: res.error || 'Connection failed. Check the Org URL and PAT.' });
      }
    });
  };

  const disconnect = () => {
    disconnectAzure();
    setResult(null);
    setPat('');
    toast({ kind: 'info', title: 'Disconnected', message: 'Azure DevOps connection cleared.' });
  };

  return (
    <ModalShell
      title="Azure Configuration"
      subtitle="Connect Azure DevOps to load your pipelines. The token is stored securely on the server and never kept in the browser."
      onClose={onClose}
      footer={
        <>
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          {alreadyConnected && (
            <button className="btn secondary" onClick={disconnect} disabled={busy}>Disconnect</button>
          )}
          <button className="btn" onClick={connect} disabled={busy || !orgUrl || !pat}>
            {busy ? 'Connecting…' : (alreadyConnected ? 'Reconnect' : 'Connect')}
          </button>
        </>
      }
    >
      {tabs}
      {alreadyConnected && !result && (
        <div className="inline-notice" role="status" style={{ marginBottom: 'var(--s-3)' }}>
          Currently connected to <strong>{azure.organization}</strong>
          {' · '}{azure.pipelines} pipelines loaded.
          Reconnect to switch organization.
        </div>
      )}

      <div className="form-grid">
        <label>
          <span className="form-label">Organization URL</span>
          <input
            className="form-field"
            value={orgUrl}
            placeholder="https://dev.azure.com/your-org"
            onChange={e => setOrgUrl(e.target.value)}
            autoFocus
          />
        </label>
        <label>
          <span className="form-label">Personal Access Token (PAT)</span>
          <input
            className="form-field"
            type="password"
            value={pat}
            placeholder="paste a PAT with Build (Read & execute)"
            onChange={e => setPat(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && orgUrl && pat && !busy) connect(); }}
          />
        </label>
        <div className="form-note">
          The PAT needs <strong>Build (Read &amp; execute)</strong> — read alone lists pipelines
          and history but cannot trigger runs. It is sent once to the backend, validated
          against <code>dev.azure.com</code>, and stored server-side — it is never returned
          to or cached in this browser.
        </div>
      </div>

      {result && result.ok && (
        <div className="connect-success" style={{ marginTop: 'var(--s-3)' }}>
          <div className="connect-badge">✓ Connected</div>
          <ul className="connect-summary">
            <li><span>Organization</span><code>{result.data.organization}</code></li>
            <li><span>Project</span><code>{result.data.project}</code></li>
          </ul>
          <p className="muted">Pipelines are loading. You can close this panel.</p>
        </div>
      )}

      {result && result.error && (
        <p className="inline-notice error" role="alert" style={{ marginTop: 'var(--s-3)' }}>
          <strong>Connection failed.</strong> {result.error}
        </p>
      )}
    </ModalShell>
  );
}

// Backwards-compatible alias — older call sites referenced ConnectAzureModal.
const ConnectAzureModal = AzureConfigModal;

// ----- AWS Configuration (Region + Access key pair) -----
// Mirrors the Azure panel: the secret key is sent once to POST /api/aws/connect,
// stored server-side (Secrets Manager) and never returned to the browser.
function AwsConfigModal({ onClose, tabs }) {
  const { toast, aws, setAwsConnected, disconnectAws } = useStore();
  const api = window.greenQaApi;

  const [region, setRegion]     = React.useState(aws.region || 'eu-west-2');
  const [keyId, setKeyId]       = React.useState('');
  const [secret, setSecret]     = React.useState('');
  const [busy, setBusy]         = React.useState(false);
  const [result, setResult]     = React.useState(null);

  const alreadyConnected = aws.connected;
  const ready = region && keyId && secret;

  const connect = () => {
    if (!api || !api.isConfigured()) {
      setResult({ error: 'API base URL is not configured (window.GREEN_QA_API_URL).' });
      return;
    }
    setBusy(true);
    setResult(null);
    api.awsConnect({
      region: region.trim(),
      access_key_id: keyId.trim(), secret_access_key: secret.trim()
    }).then((res) => {
      setBusy(false);
      if (res.ok && res.data && res.data.connected) {
        setAwsConnected(res.data);
        setSecret('');
        setResult({ ok: true, data: res.data });
        toast({ kind: 'success', title: 'AWS connected', message: res.data.message });
      } else {
        setResult({ error: res.error || 'Connection failed. Check the region, endpoint and keys.' });
      }
    });
  };

  const disconnect = () => {
    disconnectAws();
    setResult(null);
    setKeyId('');
    setSecret('');
    toast({ kind: 'info', title: 'Disconnected', message: 'AWS connection cleared.' });
  };

  return (
    <ModalShell
      title="AWS Configuration"
      subtitle="Connect AWS CodePipeline to load your pipelines. The secret key is stored securely on the server and never kept in the browser."
      onClose={onClose}
      footer={
        <>
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          {alreadyConnected && <button className="btn secondary" onClick={disconnect} disabled={busy}>Disconnect</button>}
          <button className="btn" onClick={connect} disabled={busy || !ready}>
            {busy ? 'Connecting…' : (alreadyConnected ? 'Reconnect' : 'Connect')}
          </button>
        </>
      }
    >
      {tabs}
      {alreadyConnected && !result && (
        <div className="inline-notice" role="status" style={{ marginBottom: 'var(--s-3)' }}>
          Currently connected to account <strong>{aws.accountId}</strong> in <strong>{aws.region}</strong>.
          Reconnect to switch account.
        </div>
      )}

      <div className="form-grid">
        <label>
          <span className="form-label">AWS region</span>
          <input className="form-field" value={region} placeholder="eu-west-2"
            onChange={e => setRegion(e.target.value)} autoFocus />
        </label>
        <label>
          <span className="form-label">Access key ID</span>
          <input className="form-field" value={keyId} placeholder="AKIA…" autoComplete="off"
            onChange={e => setKeyId(e.target.value)} />
        </label>
        <label>
          <span className="form-label">Secret access key</span>
          <input className="form-field" type="password" value={secret} autoComplete="new-password"
            placeholder="paste the secret access key"
            onChange={e => setSecret(e.target.value)}
            onKeyDown={(e) => { if (e.key === 'Enter' && ready && !busy) connect(); }} />
        </label>
        <div className="form-note">
          Use an IAM user with <strong>codepipeline:ListPipelines</strong> (read-only is enough).
          The key pair is validated against AWS, then stored server-side — it is never returned to
          or cached in this browser.
        </div>
      </div>

      {result && result.ok && (
        <div className="connect-success" style={{ marginTop: 'var(--s-3)' }}>
          <div className="connect-badge">✓ Connected</div>
          <ul className="connect-summary">
            <li><span>Account</span><code>{result.data.account_id}</code></li>
            <li><span>Region</span><code>{result.data.region}</code></li>
            <li><span>Pipelines</span><code>{result.data.pipelines}</code></li>
          </ul>
        </div>
      )}

      {result && result.error && (
        <p className="inline-notice error" role="alert" style={{ marginTop: 'var(--s-3)' }}>
          <strong>Connection failed.</strong> {result.error}
        </p>
      )}
    </ModalShell>
  );
}

// ----- Cloud Configuration: Azure DevOps + AWS tabs -----
function CloudConfigModal({ onClose, initialTab }) {
  const [tab, setTab] = React.useState(initialTab || 'azure');
  const tabs = (
    <div role="tablist" aria-label="Cloud" style={{ display: 'flex', gap: 'var(--s-2)', marginBottom: 'var(--s-3)' }}>
      {[['azure', 'Azure DevOps'], ['aws', 'AWS']].map(([id, label]) => (
        <button
          key={id}
          role="tab"
          aria-selected={tab === id}
          className={'btn' + (tab === id ? '' : ' secondary')}
          onClick={() => setTab(id)}
        >{label}</button>
      ))}
    </div>
  );
  return tab === 'aws'
    ? <AwsConfigModal onClose={onClose} tabs={tabs} />
    : <AzureConfigModal onClose={onClose} tabs={tabs} />;
}

// ----- Apply Recommendation -----
function ApplyRecommendationModal({ pipeline: p, recRegion, onClose }) {
  const { toast, mutatePipeline } = useStore();
  const { REGION_MAP } = CCD_DATA;
  const from = REGION_MAP[p.region];
  const to = REGION_MAP[recRegion];
  const projectedCo2 = p.current * (to.intensity / from.intensity);
  const saved = p.current - projectedCo2;
  const savedPct = (saved / p.current) * 100;
  const [busy, setBusy] = React.useState(false);

  const apply = () => {
    setBusy(true);
    setTimeout(() => {
      mutatePipeline(p.id, () => ({
        region: recRegion,
        current: +projectedCo2.toFixed(2),
        buildStatus: projectedCo2 > p.budget ? 'warn' : 'pass',
        strategy: 'RUN_NOW',
        strategyReason: 'Re-routed to ' + recRegion + ' on ' + new Date().toLocaleDateString('en-GB')
      }));
      onClose();
      toast({
        kind: 'success',
        title: 'Routing applied',
        message: p.name + ' → ' + recRegion,
        detail: 'Saved ' + saved.toFixed(1) + ' g CO₂ (' + savedPct.toFixed(0) + '%) on next run'
      });
    }, 900);
  };

  return (
    <ModalShell
      title="Apply Recommendation"
      subtitle="The next pipeline run will use the recommended region. Existing in-flight runs are unaffected."
      onClose={onClose}
      footer={
        <>
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" onClick={apply} disabled={busy}>
            {busy ? 'Applying…' : 'Apply re-route'}
          </button>
        </>
      }
    >
      <div className="rec-diff">
        <div className="rec-col">
          <div className="rec-col-label">CURRENT</div>
          <div className="rec-col-region">{p.region}</div>
          <div className="rec-col-city">{from.city}, {from.country}</div>
          <div className="rec-col-num">{from.intensity}<small> gCO₂/kWh</small></div>
          <div className="rec-col-co2">{p.current.toFixed(1)} g per run</div>
        </div>
        <div className="rec-arrow">→</div>
        <div className="rec-col good">
          <div className="rec-col-label">RECOMMENDED</div>
          <div className="rec-col-region">{recRegion}</div>
          <div className="rec-col-city">{to.city}, {to.country}</div>
          <div className="rec-col-num">{to.intensity}<small> gCO₂/kWh</small></div>
          <div className="rec-col-co2">{projectedCo2.toFixed(1)} g per run</div>
        </div>
      </div>
      <div className="rec-saving">
        Projected carbon saved per run:
        <strong> {saved.toFixed(1)} g</strong>
        <span className="muted"> ({savedPct.toFixed(0)}% reduction)</span>
      </div>
      <ul className="rec-effects">
        <li>Routing is updated in <code>pipeline-config.yaml</code> via PR</li>
        <li>In-flight build is not interrupted</li>
        <li>Data residency: <strong>{to.country === from.country ? 'unchanged' : to.country + ' — review with security'}</strong></li>
        <li>Artefact cache: warm in {to.id} (already a peer)</li>
      </ul>
    </ModalShell>
  );
}

// ----- Run Now (carbon gate decision) -----
function RunNowModal({ pipeline: p, onClose }) {
  const { toast, mutatePipeline } = useStore();
  const { REGION_MAP } = CCD_DATA;
  const [step, setStep] = React.useState(0);
  // step 0 = decision tree, 1 = queued, 2 = running, 3 = done

  const home = REGION_MAP[p.region];
  const cleanest = Object.values(REGION_MAP).sort((a, b) => a.intensity - b.intensity)[0];
  const threshold = 120; // gCO2/kWh
  const homeEfficient = home.intensity <= threshold;
  const canDelay = p.criticality !== 'CRITICAL';
  const delayedSaving = 0.34;

  // Decision logic per spec
  const decision = (() => {
    if (homeEfficient) return { action: 'RUN_NOW', region: p.region, reason: 'Home region within efficiency threshold' };
    if (cleanest && cleanest.id !== p.region) return { action: 'SPACE_SHIFT', region: cleanest.id, reason: 'Lowest-emission region available' };
    if (canDelay) return { action: 'TIME_SHIFT', region: p.region, reason: 'Delay up to 4h for green window' };
    return { action: 'RUN_NOW', region: cleanest.id, reason: 'Fallback to lowest-emission region' };
  })();

  const recRegion = decision.region;
  const recIntensity = REGION_MAP[recRegion].intensity;
  const projectedCo2 = p.current * (recIntensity / home.intensity);
  const saved = Math.max(0, p.current - projectedCo2);

  React.useEffect(() => {
    if (step === 1) {
      const t = setTimeout(() => setStep(2), 1200);
      return () => clearTimeout(t);
    }
    if (step === 2) {
      const t = setTimeout(() => setStep(3), 2200);
      return () => clearTimeout(t);
    }
    if (step === 3) {
      mutatePipeline(p.id, () => ({
        region: recRegion,
        current: +projectedCo2.toFixed(2),
        buildStatus: projectedCo2 > p.budget ? 'warn' : 'pass',
        strategy: decision.action,
        lastRunISO: 'just now',
        history7: [...p.history7.slice(1), +projectedCo2.toFixed(2)]
      }));
    }
  }, [step]);

  const close = () => {
    if (step === 3) {
      toast({
        kind: 'success',
        title: 'Run complete · ' + p.name,
        message: projectedCo2.toFixed(1) + ' g CO₂ emitted in ' + recRegion,
        detail: 'Saved ' + saved.toFixed(1) + ' g vs naive routing — strategy ' + decision.action
      });
    }
    onClose();
  };

  return (
    <ModalShell
      title={step < 3 ? 'Run · ' + p.name : 'Run complete'}
      subtitle={step < 3 ? 'Applying carbon-aware scheduling before queueing the build.' : 'Carbon delta recorded against your monthly ledger.'}
      onClose={close}
      footer={
        step === 0 ? (
          <>
            <button className="btn ghost" onClick={close}>Cancel</button>
            <button className="btn" onClick={() => setStep(1)}>Queue with strategy <strong style={{ marginLeft: 4 }}>{decision.action}</strong></button>
          </>
        ) : step === 3 ? (
          <>
            <button className="btn" onClick={close}>Close</button>
          </>
        ) : null
      }
    >
      <SchedulerDecisionTree pipeline={p} home={home} threshold={threshold}
        homeEfficient={homeEfficient} canDelay={canDelay} cleanest={cleanest}
        decision={decision} />

      {step >= 1 && (
        <div className="run-progress">
          <div className={'run-step ' + (step >= 1 ? 'on' : '')}>
            <div className="run-step-dot" />
            <div><strong>Queued</strong> in {recRegion} via Azure DevOps</div>
          </div>
          <div className={'run-step ' + (step >= 2 ? 'on' : '')}>
            <div className="run-step-dot" />
            <div><strong>Running</strong> · {p.lastRunMin} min projected · {p.vcpu} vCPU</div>
          </div>
          <div className={'run-step ' + (step >= 3 ? 'on' : '')}>
            <div className="run-step-dot" />
            <div>
              <strong>Complete</strong> · emitted <strong>{projectedCo2.toFixed(1)} g</strong>
              {saved > 0 && <span style={{ color: 'var(--gov-green-2)', fontWeight: 700 }}> · saved {saved.toFixed(1)} g</span>}
            </div>
          </div>
        </div>
      )}
    </ModalShell>
  );
}

// ----- Scheduler 4-step decision tree (visualised) -----
function SchedulerDecisionTree({ pipeline: p, home, threshold, homeEfficient, canDelay, cleanest, decision }) {
  const steps = [
    {
      q: '1. Is the home region efficient?',
      detail: home.id + ' = ' + home.intensity + ' gCO₂/kWh · threshold ' + threshold,
      yes: homeEfficient,
      pick: homeEfficient,
      result: 'Run now in ' + home.id
    },
    {
      q: '2. Is a lower-emission region reachable?',
      detail: 'Cleanest = ' + cleanest.id + ' @ ' + cleanest.intensity + ' gCO₂/kWh',
      yes: !homeEfficient && cleanest.id !== home.id,
      pick: !homeEfficient && cleanest.id !== home.id,
      result: 'Re-route to ' + cleanest.id
    },
    {
      q: '3. Can we delay up to 4h for a green window?',
      detail: p.criticality + ' criticality · ' + (canDelay ? 'delay permitted' : 'delay not permitted'),
      yes: canDelay,
      pick: !homeEfficient && cleanest.id === home.id && canDelay,
      result: 'Defer ' + (canDelay ? 'up to 4h' : '— not allowed')
    },
    {
      q: '4. Fallback — lowest-emission or default.',
      detail: 'Used only when steps 1–3 fail',
      yes: true,
      pick: !homeEfficient && cleanest.id === home.id && !canDelay,
      result: 'Run in lowest-emission region'
    }
  ];

  return (
    <div className="sched-tree">
      <div className="sched-tree-head">
        <span className="ccd-tag dark">CARBON-AWARE SCHEDULER · v2.1</span>
        <span className="muted">Strategy chosen: <strong style={{ color: 'var(--gov-text)' }}>{decision.action}</strong></span>
      </div>
      <ol className="sched-tree-list">
        {steps.map((s, i) => (
          <li key={i} className={'sched-step' + (s.pick ? ' pick' : '') + (s.yes ? ' yes' : ' no')}>
            <div className="sched-step-num">{i + 1}</div>
            <div className="sched-step-body">
              <div className="sched-step-q">{s.q}</div>
              <div className="sched-step-detail">{s.detail}</div>
            </div>
            <div className="sched-step-verdict">
              {s.pick ? <span className="ccd-tag green">CHOSEN</span> :
                s.yes ? <span className="ccd-tag outline">YES</span> :
                <span className="muted">no</span>}
            </div>
          </li>
        ))}
      </ol>
    </div>
  );
}

// ----- Weekly Digest scheduler -----
function WeeklyDigestModal({ onClose }) {
  const { toast } = useStore();
  const teams = CCD_DATA.TEAMS;
  const [selected, setSelected] = React.useState(['identity','payments','catalog','platform','mobile','data']);
  const [day, setDay] = React.useState('mon');
  const [time, setTime] = React.useState('09:00');
  const [channel, setChannel] = React.useState('email');
  const [busy, setBusy] = React.useState(false);

  const toggle = (id) => setSelected(prev =>
    prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
  );

  const submit = () => {
    setBusy(true);
    setTimeout(() => {
      onClose();
      toast({
        kind: 'success',
        title: 'Weekly digest scheduled',
        message: selected.length + ' teams · ' + day.toUpperCase() + ' at ' + time + ' via ' + channel,
        detail: 'First send: next ' + day.toUpperCase() + ' at ' + time + ' (UTC)'
      });
    }, 700);
  };

  return (
    <ModalShell
      title="Schedule weekly carbon digest"
      subtitle="Send each team a personalised carbon summary. Includes their rank, top emitters, and recommended fixes."
      onClose={onClose}
      footer={
        <>
          <button className="btn ghost" onClick={onClose}>Cancel</button>
          <button className="btn" onClick={submit} disabled={busy || !selected.length}>
            {busy ? 'Scheduling…' : 'Schedule digest'}
          </button>
        </>
      }
    >
      <div className="form-grid">
        <div>
          <span className="form-label">Teams to include · {selected.length} / {teams.length}</span>
          <div className="chip-grid">
            {teams.map(t => (
              <button
                key={t.id}
                type="button"
                className={'chip ' + (selected.includes(t.id) ? 'on' : '')}
                onClick={() => toggle(t.id)}
              >
                {t.name}
              </button>
            ))}
          </div>
        </div>

        <div className="form-row">
          <label style={{ flex: 1 }}>
            <span className="form-label">Day</span>
            <select className="form-field" value={day} onChange={e => setDay(e.target.value)}>
              {['mon','tue','wed','thu','fri'].map(d => <option key={d} value={d}>{d.toUpperCase()}</option>)}
            </select>
          </label>
          <label style={{ flex: 1 }}>
            <span className="form-label">Time (UTC)</span>
            <select className="form-field" value={time} onChange={e => setTime(e.target.value)}>
              {['07:00','08:00','09:00','10:00','11:00','14:00','16:00'].map(t => <option key={t}>{t}</option>)}
            </select>
          </label>
          <label style={{ flex: 1 }}>
            <span className="form-label">Channel</span>
            <select className="form-field" value={channel} onChange={e => setChannel(e.target.value)}>
              <option value="email">Email</option>
              <option value="slack">Slack DM (lead + report)</option>
              <option value="teams">MS Teams</option>
              <option value="all">All channels</option>
            </select>
          </label>
        </div>

        <div className="form-note">
          The digest is composed from the live ledger at send-time. Teams not selected here
          can still subscribe individually via the team page.
        </div>
      </div>
    </ModalShell>
  );
}

// expose to window for app.jsx
Object.assign(window, {
  AzureConfigModal, ConnectAzureModal, AwsConfigModal, CloudConfigModal, ApplyRecommendationModal,
  RunNowModal, WeeklyDigestModal, SchedulerDecisionTree
});
