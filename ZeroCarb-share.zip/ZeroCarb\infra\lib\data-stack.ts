import * as cdk from 'aws-cdk-lib';
import * as backup from 'aws-cdk-lib/aws-backup';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as events from 'aws-cdk-lib/aws-events';
import * as secretsmanager from 'aws-cdk-lib/aws-secretsmanager';
import { Construct } from 'constructs';
import type { EnvConfig } from './config';

export const RESOURCE_SERVER_ID = 'greenqa';

/** Stateful resources: tables, secrets, identity. Kept separate so the app tier can be redeployed freely. */
export class DataStack extends cdk.Stack {
  readonly carbonTable: dynamodb.TableV2;
  readonly executionsTable: dynamodb.TableV2;
  readonly deferredTable: dynamodb.TableV2;
  readonly connectionsTable: dynamodb.TableV2;
  readonly auditTable: dynamodb.TableV2;
  readonly adoPatSecret: secretsmanager.Secret;
  readonly awsCredentialsSecret: secretsmanager.Secret;
  readonly electricityMapsSecret: secretsmanager.Secret;
  readonly webhookSecret: secretsmanager.Secret;
  readonly userPool: cognito.UserPool;
  readonly machineClient: cognito.UserPoolClient;
  readonly cognitoDomain: cognito.UserPoolDomain;

  constructor(scope: Construct, id: string, readonly cfg: EnvConfig, props: cdk.StackProps) {
    super(scope, id, { terminationProtection: cfg.retainData, ...props });

    const removal = cfg.retainData ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY;
    const table = (name: string, partitionKey: string, opts: Partial<dynamodb.TablePropsV2> = {}) =>
      new dynamodb.TableV2(this, `${name}Table`, {
        tableName: `zerocarb-${cfg.name}-${name.toLowerCase()}`,
        partitionKey: { name: partitionKey, type: dynamodb.AttributeType.STRING },
        billing: dynamodb.Billing.onDemand(),
        encryption: dynamodb.TableEncryptionV2.awsManagedKey(),
        pointInTimeRecoverySpecification: { pointInTimeRecoveryEnabled: true },
        deletionProtection: cfg.retainData,
        removalPolicy: removal,
        replicas: cfg.replicaRegions.map((region) => ({ region })),
        ...opts,
      });

    this.carbonTable = table('Carbon', 'pk', { sortKey: { name: 'sk', type: dynamodb.AttributeType.STRING }, timeToLiveAttribute: 'expires_at' });

    this.executionsTable = table('Executions', 'pk', { sortKey: { name: 'sk', type: dynamodb.AttributeType.STRING } });
    this.executionsTable.addGlobalSecondaryIndex({
      indexName: 'by_pipeline_provider',
      partitionKey: { name: 'gsi1pk', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'gsi1sk', type: dynamodb.AttributeType.STRING },
    });
    this.executionsTable.addGlobalSecondaryIndex({
      indexName: 'by_provider',
      partitionKey: { name: 'gsi2pk', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'gsi2sk', type: dynamodb.AttributeType.STRING },
    });

    this.deferredTable = table('Deferred', 'pk');
    this.deferredTable.addGlobalSecondaryIndex({
      indexName: 'by_status',
      partitionKey: { name: 'gsi1pk', type: dynamodb.AttributeType.STRING },
      sortKey: { name: 'gsi1sk', type: dynamodb.AttributeType.STRING },
    });

    this.connectionsTable = table('Connections', 'pk');
    this.auditTable = table('Audit', 'pk', { sortKey: { name: 'sk', type: dynamodb.AttributeType.STRING }, timeToLiveAttribute: 'expires_at' });

    // ---- Secrets (values are set out-of-band; the app treats CHANGE_ME as "not provisioned") -------------------------
    const secret = (id: string, name: string, description: string, generated = false) =>
      new secretsmanager.Secret(this, id, {
        secretName: `zerocarb/${cfg.name}/${name}`,
        description,
        removalPolicy: removal,
        ...(generated
          ? { generateSecretString: { passwordLength: 48, excludePunctuation: true } }
          : { secretStringValue: cdk.SecretValue.unsafePlainText('CHANGE_ME') }),
      });
    this.adoPatSecret = secret('AdoPat', 'ado-pat', 'Azure DevOps PAT (Build/Pipelines read+execute). Set via the dashboard or `aws secretsmanager put-secret-value`.');
    this.awsCredentialsSecret = secret('AwsCredentials', 'aws-pipelines-credentials', 'AWS access key pair (JSON) used to read CodePipeline. Set via the dashboard.');
    this.electricityMapsSecret = secret('ElectricityMaps', 'electricitymaps-token', 'ElectricityMaps API token (optional).');
    this.webhookSecret = secret('Webhook', 'ado-webhook-secret', 'Shared secret for the ADO Service Hook -> /api/ingest-ado-event.', true);

    // ---- Identity -----------------------------------------------------------------------------------------------------
    this.userPool = new cognito.UserPool(this, 'UserPool', {
      userPoolName: `zerocarb-${cfg.name}`,
      selfSignUpEnabled: false,
      signInAliases: { email: true },
      autoVerify: { email: true },
      standardAttributes: { email: { required: true, mutable: true } },
      passwordPolicy: { minLength: 14, requireLowercase: true, requireUppercase: true, requireDigits: true, requireSymbols: true, tempPasswordValidity: cdk.Duration.days(3) },
      mfa: cognito.Mfa[cfg.mfa],
      mfaSecondFactor: { otp: true, sms: false },
      accountRecovery: cognito.AccountRecovery.EMAIL_ONLY,
      deletionProtection: cfg.retainData,
      removalPolicy: removal,
    });

    // Human roles map to the RBAC matrix enforced in apps/api (src/http/auth.ts).
    for (const [group, description] of Object.entries({
      admin: 'Manage the Azure DevOps connection and platform settings',
      operator: 'Trigger runs and carbon ingestion',
      viewer: 'Read-only dashboards',
    })) {
      new cognito.CfnUserPoolGroup(this, `Group-${group}`, { userPoolId: this.userPool.userPoolId, groupName: group, description });
    }

    // Machine-to-machine: CI gate tasks call /decide and /store_result with the client-credentials grant.
    const pipelineScope = new cognito.ResourceServerScope({ scopeName: 'pipeline', scopeDescription: 'Call the CI gate endpoints' });
    const resourceServer = this.userPool.addResourceServer('ResourceServer', { identifier: RESOURCE_SERVER_ID, scopes: [pipelineScope] });
    this.machineClient = this.userPool.addClient('PipelineClient', {
      userPoolClientName: `zerocarb-${cfg.name}-pipeline`,
      generateSecret: true,
      authFlows: {},
      oAuth: { flows: { clientCredentials: true }, scopes: [cognito.OAuthScope.resourceServer(resourceServer, pipelineScope)] },
      accessTokenValidity: cdk.Duration.hours(1),
    });

    this.cognitoDomain = this.userPool.addDomain('Domain', {
      cognitoDomain: { domainPrefix: `zerocarb-${cfg.name}-${cdk.Aws.ACCOUNT_ID}` },
    });

    // ---- Backup (daily, 35 days; prod also keeps monthly for a year) -------------------------------------------------
    const vault = new backup.BackupVault(this, 'Vault', {
      backupVaultName: `zerocarb-${cfg.name}`,
      removalPolicy: removal,
    });
    const plan = new backup.BackupPlan(this, 'Plan', { backupPlanName: `zerocarb-${cfg.name}`, backupVault: vault });
    plan.addRule(new backup.BackupPlanRule({
      ruleName: 'daily',
      scheduleExpression: events.Schedule.cron({ hour: '3', minute: '0' }),
      deleteAfter: cdk.Duration.days(35),
    }));
    if (cfg.name === 'prod') {
      plan.addRule(new backup.BackupPlanRule({
        ruleName: 'monthly',
        scheduleExpression: events.Schedule.cron({ day: '1', hour: '4', minute: '0' }),
        deleteAfter: cdk.Duration.days(365),
      }));
    }
    plan.addSelection('Tables', {
      resources: [
        backup.BackupResource.fromDynamoDbTable(this.executionsTable),
        backup.BackupResource.fromDynamoDbTable(this.deferredTable),
        backup.BackupResource.fromDynamoDbTable(this.connectionsTable),
        backup.BackupResource.fromDynamoDbTable(this.auditTable),
      ],
    });

    cdk.Tags.of(this).add('Tier', 'data');
  }
}
