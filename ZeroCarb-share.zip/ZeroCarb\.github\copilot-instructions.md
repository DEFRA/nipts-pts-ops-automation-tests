# GitHub Copilot — workspace instructions

Copilot Chat auto-loads this file as system context for every chat in this
workspace. Keep it concise; heavier context lives in `HANDOFF.md`, `CLAUDE.md`,
and `docs/ARCHITECTURE.md` — read those before making changes.

## Who you are working with

The primary user is **Saptamita Majumder** (Cognizant contractor to DEFRA,
email `saptamita.majumder@cognizant.com`). She is migrating this project
from her Cognizant laptop to a DEFRA laptop and continuing the work here.

## First things to read (in order)

1. `HANDOFF.md` — the current state snapshot. **Read §14 first** — that's
   where the previous Claude Code session left off. Then skim §5 (blockers),
   §7.4 (how this workspace was set up on this machine), and §15 (PAT
   creation) before starting any task.
2. `CLAUDE.md` — repo orientation (partially stale, see `HANDOFF.md` §5.8).
3. `docs/ARCHITECTURE.md` — canonical component + data-flow reference.
4. `GAPS.md` — mocked vs real inventory, roadmap of what's not yet built.

## Behavioural rules (carried over from the prior Claude Code sessions)

These are non-negotiable preferences the user has already stated. Do not
require her to repeat them.

1. **No source edits without explicit per-task approval.** For ops or deploy
   asks, "no functionality changes" means "no source edits, period." When
   in doubt, describe the change you would make and wait for her to say go.
2. **Multi-step ops guides: one step at a time.** For portal walk-throughs
   or deploy sequences, give ONE action, wait for her to confirm the
   result, then give the next. Do not front-load an eight-step recipe.
3. **Ask before extracting cached git or cloud credentials.** Name the
   account and the specific API call before consuming a stored PAT or
   token.
4. **Don't run git commands against her local repo.** Even read-only
   (`git status`, `git log`, `git diff`) — hand her the command to paste,
   don't invoke it yourself. Reading files with normal file-read tools is
   fine.
5. **GOV.UK Design System voice** in any user-facing copy. Tags
   `green | amber | red`. WCAG 2.2 AA palette is already encoded in
   `styles.css`.

## Project constraints you should know without asking

- **WattTime must replace ElectricityMaps** — deadline was 2026-09-01;
  status unclear on this machine. The WattTime adapter lands in the
  upstream `green_qa_lib`, not the local stub. See `HANDOFF.md` §5.4.
- **Daily FA shutdown rule (DEFRA POC)** — stop the Function App at end
  of day, start next morning. DEFRA governance, do not plan overnight
  timer work that assumes 24×7 availability.
- **SPA local dev needs HTTP, not `file://`** — Babel Standalone XHRs
  the `.jsx` files. Use `start.bat` (Windows) or `python -m http.server
  8000` from the repo root.
- **VS Enterprise licence expires 2026-09-30** — the current Azure
  DevTest sub is tied to it. Chase Cognizant admin for renewal or the
  sub is disabled ~30 days after expiry.

## Where the deploy sequence stopped

Live-deploy walkthrough is paused at **§14 Step 4** of `HANDOFF.md`. When
Saptamita is ready to resume, she'll say so — start by re-reading §14 for
current state, then walk her through Step 4 (portal check of the new
DevTest sub: subscription ID, name, tenant, Owner role).

## Conventions the codebase depends on

- **No bundler in the SPA, ever.** New frontend files are `*.jsx` loaded
  via `<script type="text/babel">`, attached to `window.*`, added to
  `Carbon Cost Dashboard.html` in dependency order. Each file declares its
  expected globals in a `/* global … */` leading comment — keep it honest.
- **Load order in `Carbon Cost Dashboard.html` is real** — see
  `HANDOFF.md` §3 for the chain (`data.js → atoms → tweaks-panel → store
  → …`).
- **`/*EDITMODE-BEGIN*/ … /*EDITMODE-END*/`** markers in `app.jsx` are
  read by an external host tool. Do not remove or rename.
- **`data.js` IDs are stable** (`uksouth`, `auth-service-ci`, …). Many UI
  components index by ID.
- **`schemas.py` dataclasses are the API v1 contract.** Any field change
  needs the `from_dict` parser AND every dashboard fetch site updated.
- **`cosmos_dal.py` in-memory branch must stay in sync** with every new
  query method — its `query_items` does NOT parse SQL, so all callers on
  the in-memory path must re-filter client-side.
- **Connection-string-less by design.** Function App uses managed
  identity for both Key Vault and Cosmos. Preserve when editing Bicep.
- **CI does not run `bicep apply`.** Infra changes run locally via
  `./scripts/deploy.sh dev apply`.

## Model choice

Inside Copilot Chat, prefer **Claude Sonnet 4.5** or newer if available
(model picker in the chat input). Reasoning and tool-use quality on this
codebase's Python + React + Bicep mix is materially better than GPT-4o.
