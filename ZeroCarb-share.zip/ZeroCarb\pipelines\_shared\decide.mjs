#!/usr/bin/env node
// Carbon Cost Dashboard — shared GreenQA decision-gate script (Node 18+).
//
// Called as the first step of every governed pipeline. Posts to /api/decide, echoes the
// decision, and sets output variables that downstream stages condition on:
//   GreenQA_Decision (RUN_NOW | DEFER | RELOCATE | HYBRID), GreenQA_Region, GreenQA_SavingsPct
//
// Required env vars (set by the calling pipeline):
//   PIPELINE_ID, CURRENT_REGION, CANDIDATE_REGIONS (comma-separated), CRITICALITY
//   GREEN_QA_API            https://<cloudfront-domain>/api
//   GREEN_QA_TOKEN_URL      Cognito token endpoint (stack output TokenEndpoint)
//   GREEN_QA_CLIENT_ID      Cognito "pipeline" app client id (stack output PipelineClientId)
//   GREEN_QA_CLIENT_SECRET  that client's secret (secret variable)
// Optional: VCPU_COUNT, MEMORY_GB, DURATION_MIN_EST, MAX_DEFER_HOURS, POOL_MODE, BUILD_BUILDID

const env = (k, d) => process.env[k] ?? d;
const need = (k) => {
  const v = process.env[k];
  if (!v) { console.error(`Missing required env var ${k}`); process.exit(2); }
  return v;
};

const api = need('GREEN_QA_API').replace(/\/+$/, '');

async function accessToken() {
  const res = await fetch(need('GREEN_QA_TOKEN_URL'), {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'client_credentials',
      client_id: need('GREEN_QA_CLIENT_ID'),
      client_secret: need('GREEN_QA_CLIENT_SECRET'),
      scope: 'greenqa/pipeline',
    }),
    signal: AbortSignal.timeout(30_000),
  });
  if (!res.ok) throw new Error(`Token request failed: HTTP ${res.status}`);
  return (await res.json()).access_token;
}

const body = {
  pipeline_id: need('PIPELINE_ID'),
  run_id: env('BUILD_BUILDID', 'dev-run'),
  provider: 'azure',
  pool_mode: env('POOL_MODE', 'self_hosted_multi_region'),
  current_region: need('CURRENT_REGION'),
  candidate_regions: need('CANDIDATE_REGIONS').split(','),
  workload: {
    vcpu_count: parseInt(env('VCPU_COUNT', '2'), 10),
    memory_gb: parseFloat(env('MEMORY_GB', '4.0')),
    duration_minutes_estimate: parseFloat(env('DURATION_MIN_EST', '15')),
  },
  criticality: need('CRITICALITY'),
  max_defer_hours: parseFloat(env('MAX_DEFER_HOURS', '12')),
};
console.log('Request:', JSON.stringify(body));

try {
  const token = await accessToken();
  const res = await fetch(`${api}/decide`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${token}` },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(30_000),
  });
  const text = await res.text();
  console.log('Response:', text);
  if (!res.ok) throw new Error(`/decide returned HTTP ${res.status}`);

  const r = JSON.parse(text);
  console.log(`GreenQA decision: ${r.decision} → ${r.selected_region} (savings ${r.carbon.savings_percent}%)`);
  console.log(`##vso[task.setvariable variable=GreenQA_Decision;isOutput=true]${r.decision}`);
  console.log(`##vso[task.setvariable variable=GreenQA_Region;isOutput=true]${r.selected_region}`);
  console.log(`##vso[task.setvariable variable=GreenQA_SavingsPct;isOutput=true]${r.carbon.savings_percent}`);
} catch (err) {
  console.error(`##vso[task.logissue type=error]GreenQA gate failed: ${err.message}`);
  process.exit(1);
}
