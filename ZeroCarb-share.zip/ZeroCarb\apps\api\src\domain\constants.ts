// Power Usage Effectiveness per cloud provider (industry-published averages).
export const PUE_VALUES: Record<string, number> = {
  azure: 1.185,
  aws: 1.135,
  gcp: 1.1,
};

// gCO2/kWh fallback when no live intensity is available.
export const DEFAULT_CARBON_INTENSITY_GCO2_KWH = 300;

// Industry-average power factors (kWh per resource-hour).
export const VCPU_KWH_PER_HOUR = 0.05;
export const MEMORY_KWH_PER_GB_HOUR = 0.0004;
// GSF SCI guidance: manufacturing footprint amortised over lifetime utilisation.
export const EMBODIED_GCO2_PER_VCPU_HOUR = 0.5;

// Per-region baseline carbon intensity (gCO2eq/kWh), mirrors web/data.js.
export const REGION_INTENSITY_GCO2_KWH: Record<string, number> = {
  // Azure
  northeurope: 218,
  westeurope: 287,
  uksouth: 164,
  ukwest: 172,
  francecentral: 56,
  germanywestcentral: 364,
  italynorth: 312,
  swedencentral: 19,
  norwayeast: 31,
  switzerlandnorth: 41,
  polandcentral: 678,
  spaincentral: 142,
  // AWS
  'eu-west-1': 218,
  'eu-west-2': 164,
  'eu-west-3': 56,
  'eu-north-1': 19,
  'eu-central-1': 364,
};

export type Criticality = 'critical' | 'high' | 'normal' | 'low';
export type Strategy = 'run_now' | 'time_shift' | 'space_shift' | 'hybrid';
