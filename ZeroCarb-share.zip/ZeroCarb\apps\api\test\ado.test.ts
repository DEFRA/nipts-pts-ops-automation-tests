import { afterEach, describe, expect, it, vi } from 'vitest';
import { MemorySecretStore, setSecretStore } from '../src/lib/secrets';
import { MemoryRepository } from '../src/repo/memory';
import { parseAdoTimestamp, parseOrgUrl, runPipeline, validateConnection } from '../src/services/adoClient';
import { regionFromPoolName, resumeDeferred } from '../src/services/adoSync';

afterEach(() => { vi.unstubAllGlobals(); setSecretStore(undefined); });

describe('parseOrgUrl', () => {
  it.each([
    ['https://dev.azure.com/acme', 'acme'],
    ['https://dev.azure.com/acme/', 'acme'],
    ['dev.azure.com/acme/proj', 'acme'],
    ['https://acme.visualstudio.com', 'acme'],
    ['acme', 'acme'],
    ['https://example.com/x', null],
    ['', null],
  ])('%s -> %s', (input, expected) => expect(parseOrgUrl(input)).toBe(expected));
});

describe('parseAdoTimestamp', () => {
  it('handles 7-digit fractional seconds', () => {
    expect(parseAdoTimestamp('2024-05-01T10:00:00.1234567Z')?.toISOString()).toBe('2024-05-01T10:00:00.123Z');
    expect(parseAdoTimestamp('garbage')).toBeNull();
    expect(parseAdoTimestamp(undefined)).toBeNull();
  });
});

describe('validateConnection', () => {
  it('requires a parsable org and a PAT', async () => {
    expect((await validateConnection('https://x.com/y', 'p')).success).toBe(false);
    expect(await validateConnection('acme', '')).toMatchObject({ success: false, error: expect.stringContaining('PAT') });
  });
  it('maps 404 to a not-found message', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 404 })));
    expect(await validateConnection('acme', 'p')).toMatchObject({ success: false, error: expect.stringContaining('not found') });
  });
});

describe('runPipeline', () => {
  it('sends resume variables only when asked and encodes path parts', async () => {
    const fetchMock = vi.fn(async () => new Response(JSON.stringify({ id: 99, _links: { web: { href: 'http://run' } } })));
    vi.stubGlobal('fetch', fetchMock);
    const r = await runPipeline({ organization: 'o', project: 'My Proj', definitionId: '5', decisionId: 'd', pat: 'p' });
    expect(r).toEqual({ success: true, run_id: '99', url: 'http://run' });
    const [url, init] = fetchMock.mock.calls[0] as unknown as [string, RequestInit];
    expect(url).toContain('/My%20Proj/_apis/pipelines/5/runs');
    expect(JSON.parse(init.body as string).variables.GreenQA_ResumedDecisionId.value).toBe('d');

    await runPipeline({ organization: 'o', project: 'p', definitionId: '5', decisionId: 'd', pat: 'p', includeResumeVars: false, templateParameters: { targetRegion: 'ukwest' } });
    const body = JSON.parse((fetchMock.mock.calls[1] as unknown as [string, RequestInit])[1].body as string);
    expect(body.variables).toBeUndefined();
    expect(body.templateParameters).toEqual({ targetRegion: 'ukwest' });
  });

  it('returns errors instead of throwing', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('bad', { status: 400 })));
    expect(await runPipeline({ organization: 'o', project: 'p', definitionId: '1', decisionId: 'd', pat: 'p' })).toEqual({ success: false, error: 'HTTP 400: bad' });
    setSecretStore(new MemorySecretStore());
    expect((await runPipeline({ organization: 'o', project: 'p', definitionId: '1', decisionId: 'd' })).error).toMatch(/PAT not configured/);
  });
});

describe('regionFromPoolName', () => {
  it('recovers the region from pool naming conventions', () => {
    expect(regionFromPoolName('agents-ukwest', 'azure')).toBe('ukwest');
    expect(regionFromPoolName('SF1 (region=ukwest)', 'azure')).toBe('ukwest');
    expect(regionFromPoolName('Azure Pipelines', 'azure')).toBe('uksouth');
    expect(regionFromPoolName(null, 'azure')).toBe('uksouth');
  });
});

describe('resumeDeferred', () => {
  const past = new Date(Date.now() - 60_000).toISOString();
  const ado_parts = { organization: 'o', project: 'p', definition_id: '1' };

  it('fires due runs, then fails them after the max attempts', async () => {
    setSecretStore(new MemorySecretStore());
    process.env.AZURE_DEVOPS_PAT = 'pat';
    const repo = new MemoryRepository();
    await repo.upsertDeferred({ id: 'ok', status: 'pending', defer_until_iso: past, ado_parts });
    await repo.upsertDeferred({ id: 'bad', status: 'pending', defer_until_iso: past, attempts: 2, ado_parts });
    await repo.upsertDeferred({ id: 'orphan', status: 'pending', defer_until_iso: past });
    await repo.upsertDeferred({ id: 'future', status: 'pending', defer_until_iso: new Date(Date.now() + 3.6e6).toISOString(), ado_parts });

    vi.stubGlobal('fetch', vi.fn(async (_u: string, init: RequestInit) => {
      const body = JSON.parse(init.body as string);
      return body.variables.GreenQA_ResumedDecisionId.value === 'ok'
        ? new Response(JSON.stringify({ id: 5 })) : new Response('boom', { status: 500 });
    }));

    expect(await resumeDeferred(repo)).toBe(3);
    expect(await repo.getDeferred('ok')).toMatchObject({ status: 'fired', attempts: 1, ado_run_id: '5' });
    expect(await repo.getDeferred('bad')).toMatchObject({ status: 'failed', attempts: 3 });
    expect(await repo.getDeferred('orphan')).toMatchObject({ status: 'failed', last_error: 'missing_ado_parts' });
    expect((await repo.getDeferred('future'))?.status).toBe('pending');
    delete process.env.AZURE_DEVOPS_PAT;
  });
});
