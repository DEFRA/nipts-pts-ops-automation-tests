import { getSecretStore } from '../lib/secrets';
import { logger } from '../logger';
import { AWS_CONNECTION_ID, type Repository } from '../repo/types';
import type { AwsTarget } from './awsClient';

export interface AwsConnection extends AwsTarget {
  account_id?: string;
  validated_at?: string;
}

/** Metadata lives in the repository; the access key pair lives in Secrets Manager as JSON. */
export async function getAwsConnection(repo: Repository): Promise<AwsConnection | null> {
  let record;
  try {
    record = await repo.getConnection(AWS_CONNECTION_ID);
  } catch (err) {
    logger.error({ err }, 'getAwsConnection: repository read failed');
    return null;
  }
  if (!record?.region) return null;
  const raw = await getSecretStore().get('aws_credentials');
  if (!raw) return null;
  try {
    const { access_key_id, secret_access_key } = JSON.parse(raw) as { access_key_id?: string; secret_access_key?: string };
    if (!access_key_id || !secret_access_key) return null;
    return {
      region: record.region, access_key_id, secret_access_key,
      account_id: record.account_id, validated_at: record.validated_at,
    };
  } catch {
    return null;
  }
}

export async function saveAwsConnection(repo: Repository, c: AwsTarget & { account_id: string; validated_at: string }): Promise<void> {
  await getSecretStore().put('aws_credentials', JSON.stringify({ access_key_id: c.access_key_id, secret_access_key: c.secret_access_key }));
  await repo.upsertConnection({
    region: c.region, access_key_hint: c.access_key_id.slice(-4),
    account_id: c.account_id, validated_at: c.validated_at, source: 'user',
  }, AWS_CONNECTION_ID);
}

export async function deleteAwsConnection(repo: Repository): Promise<void> {
  await repo.deleteConnection(AWS_CONNECTION_ID);
  await getSecretStore().clear('aws_credentials');
}
