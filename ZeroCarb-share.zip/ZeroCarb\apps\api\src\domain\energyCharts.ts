// Energy-Charts (Fraunhofer ISE) carbon-intensity client for continental-European regions.
// Intensity is derived as a generation-weighted mean of per-fuel lifecycle emission factors.
// Data licensed CC BY 4.0 — attribution to Energy-Charts.info is required wherever figures are displayed.
import { envFloat } from '../config';
import { httpGetJson } from '../lib/http';
import { logger } from '../logger';
import { round } from './sci';

export const BASE_URL = 'https://api.energy-charts.info/public_power';

export const REGION_COUNTRY_MAP: Record<string, string> = {
  northeurope: 'ie',
  westeurope: 'nl',
  francecentral: 'fr',
  germanywestcentral: 'de',
  italynorth: 'it',
  swedencentral: 'se',
  norwayeast: 'no',
  switzerlandnorth: 'ch',
  polandcentral: 'pl',
  spaincentral: 'es',
};

// gCO2eq/kWh, IPCC AR5 Annex III median lifecycle values.
export const EMISSION_FACTORS: Record<string, number> = {
  Nuclear: 12,
  'Wind onshore': 11,
  'Wind offshore': 12,
  'Hydro Run-of-River': 24,
  'Hydro water reservoir': 24,
  'Hydro pumped storage': 24,
  Solar: 45,
  Geothermal: 38,
  Biomass: 230,
  'Fossil gas': 490,
  'Fossil oil': 650,
  Waste: 700,
  'Fossil hard coal': 820,
  'Fossil coal-derived gas': 820,
  'Fossil brown coal / lignite': 1050,
};

// Demand, derived percentages, net trade and storage charging are not generation.
const NON_GENERATION_SERIES = new Set([
  'Load', 'Residual load', 'Renewable share of load', 'Renewable share of generation',
  'Cross border electricity trading', 'Hydro pumped storage consumption', 'Battery Consumption',
]);

const RENEWABLE_SHARE_SERIES = 'Renewable share of generation';

export interface EnergyChartsReading {
  grid_intensity: number;
  renewable_percentage: number; // 0..1
  country: string;
  fuel_mix_mw: Record<string, number>;
}

interface Series { name?: string; data?: (number | null)[] }
interface Payload { production_types?: Series[] }

export const supports = (regionCode: string): boolean => regionCode in REGION_COUNTRY_MAP;

const isNum = (v: unknown): v is number => typeof v === 'number' && Number.isFinite(v);

/** Latest slice where at least one fuel reports a value (the API pads the day with nulls). */
function latestIndex(series: Series[]): number | null {
  const length = Math.max(0, ...series.map((s) => (s.data ?? []).length));
  for (let i = length - 1; i >= 0; i--) {
    if (series.some((s) => isNum((s.data ?? [])[i]))) return i;
  }
  return null;
}

function splitSeries(types: Series[]): { known: Series[]; unknown: string[] } {
  const known: Series[] = [];
  const unknown: string[] = [];
  for (const s of types) {
    const name = s.name ?? '';
    if (NON_GENERATION_SERIES.has(name)) continue;
    if (name in EMISSION_FACTORS) known.push(s);
    else unknown.push(name);
  }
  return { known, unknown };
}

function renewableShare(types: Series[], idx: number): number {
  const s = types.find((t) => t.name === RENEWABLE_SHARE_SERIES);
  const v = s?.data?.[idx];
  return isNum(v) ? round(v / 100, 4) : 0;
}

/** [reading, source]; source is 'energy_charts' or a failure reason. */
export async function getRegionIntensity(regionCode: string): Promise<[EnergyChartsReading | null, string]> {
  const country = REGION_COUNTRY_MAP[regionCode];
  if (!country) return [null, 'energy_charts_unsupported_region'];

  const payload = await httpGetJson<Payload>(`${BASE_URL}?country=${country}`, envFloat('ENERGY_CHARTS_TIMEOUT', 10) * 1000);
  if (!payload) return [null, 'energy_charts_unavailable'];

  const types = payload.production_types;
  if (!Array.isArray(types) || !types.length) return [null, 'energy_charts_no_series'];

  const { known, unknown } = splitSeries(types);
  const idx = latestIndex(known);
  if (idx === null) return [null, 'energy_charts_no_recent_data'];

  // Negative values are net consumption and would distort the weighted mean.
  const fuelMix: Record<string, number> = {};
  for (const s of known) {
    const v = (s.data ?? [])[idx];
    if (isNum(v) && v > 0) fuelMix[s.name as string] = v;
  }
  const totalMw = Object.values(fuelMix).reduce((a, b) => a + b, 0);
  if (totalMw <= 0) return [null, 'energy_charts_zero_generation'];

  if (unknown.length) {
    logger.warn({ regionCode, excluded: [...new Set(unknown)].sort() }, 'energy_charts: series excluded (no emission factor)');
  }

  const weighted = Object.entries(fuelMix).reduce((sum, [name, mw]) => sum + mw * EMISSION_FACTORS[name], 0);
  return [
    {
      grid_intensity: round(weighted / totalMw, 1),
      renewable_percentage: renewableShare(types, idx),
      country,
      fuel_mix_mw: fuelMix,
    },
    'energy_charts',
  ];
}
