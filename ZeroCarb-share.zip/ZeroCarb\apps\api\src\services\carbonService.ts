import { settings } from '../config';
import { REGION_INTENSITY_GCO2_KWH } from '../domain/constants';
import { calculateEmbodiedCarbon, calculateEnergyKwh, calculateSci } from '../domain/sci';
import { getProvider } from '../domain/providers';
import type { Repository } from '../repo/types';

/** Latest ingested datacenter intensity for a region, else the configured default. */
export async function getCarbonIntensity(repo: Repository, region: string, provider: string, fallback?: number): Promise<number> {
  const fb = fallback ?? settings.defaultCarbonIntensity();
  try {
    const sample = await repo.getLatestCarbon(provider, region);
    if (sample) return Number(sample.dc_intensity_gco2_kwh ?? fb);
  } catch { /* fall through to the default */ }
  return fb;
}

/** Latest grid intensity for a region, else the published per-region baseline. */
export async function regionBaseIntensity(repo: Repository, provider: string, region: string): Promise<number> {
  let v: unknown;
  try {
    v = (await repo.getLatestCarbon(provider, region))?.grid_intensity_gco2_kwh;
  } catch { /* use the baseline */ }
  if (typeof v === 'number' && v > 0) return v;
  return REGION_INTENSITY_GCO2_KWH[region] ?? 150;
}

/** Total emissions (g) for a run of known duration in a region (default resource profile). */
export async function estimateRunCarbon(
  repo: Repository, region: string, provider: string, durationSeconds: number,
  vcpu = settings.adoRunDefaultVcpu(), memoryGb = settings.adoRunDefaultMemoryGb(),
): Promise<number> {
  const energy = calculateEnergyKwh(durationSeconds, vcpu, memoryGb);
  const embodied = calculateEmbodiedCarbon(vcpu, durationSeconds / 3600, provider);
  const [, breakdown] = calculateSci(energy, await getCarbonIntensity(repo, region, provider), embodied, settings.defaultFunctionalUnit());
  return breakdown.total_emissions_g;
}

export function providerRegionCodes(provider: string): string[] {
  return getProvider(provider).listRegions().map((r) => r.code);
}
