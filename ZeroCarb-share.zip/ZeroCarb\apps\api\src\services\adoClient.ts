// Azure DevOps Pipelines/Build REST client (fetch-based). Only ever talks to dev.azure.com.
import { envStr } from '../config';
import { logger } from '../logger';
import { getSecretStore } from '../lib/secrets';

const ADO_API_VERSION = '7.1';
// Overridable for Azure DevOps Server and for the e2e mock.
const host = (): string => envStr('ADO_BASE_URL', 'https://dev.azure.com').replace(/\/+$/, '');

// Deployment scope: the dashboard only surfaces the pipelines named here.
const DEFAULT_ORG_URL = 'https://dev.azure.com/defragovuk';
const DEFAULT_PROJECT = 'CCTS QAT';
const DEFAULT_PIPELINE_IDS = '12323,12324';

export class AdoHttpError extends Error {
  constructor(public readonly status: number, public readonly body: string) {
    super(`HTTP ${status}`);
  }
}

export const configuredOrgUrl = (): string => envStr('ADO_ORG_URL', DEFAULT_ORG_URL).trim();
export const configuredProject = (): string => envStr('ADO_PROJECT', DEFAULT_PROJECT).trim();
/** Definition IDs this deployment governs. Empty list = whole project. */
export const configuredPipelineIds = (): string[] =>
  envStr('ADO_PIPELINE_IDS', DEFAULT_PIPELINE_IDS).split(',').map((p) => p.trim()).filter(Boolean);

/** Secrets Manager (or env fallback) PAT. */
export async function resolveAdoPat(): Promise<string | null> {
  return getSecretStore().get('ado_pat');
}

const q = encodeURIComponent;
const basic = (pat: string) => Buffer.from(`:${pat}`).toString('base64');

async function adoRequest(url: string, pat: string, init: { method: 'GET' | 'POST'; body?: unknown; timeoutMs: number }): Promise<unknown> {
  const resp = await fetch(url, {
    method: init.method,
    headers: {
      Authorization: `Basic ${basic(pat)}`,
      Accept: 'application/json',
      ...(init.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
    },
    body: init.body !== undefined ? JSON.stringify(init.body) : undefined,
    signal: AbortSignal.timeout(init.timeoutMs),
    redirect: 'manual',
  });
  // 203 / redirect-to-sign-in is how ADO answers a bad PAT.
  if (resp.status === 203 || (resp.status >= 300 && resp.status < 400)) throw new AdoHttpError(203, '');
  const text = await resp.text();
  if (!resp.ok) throw new AdoHttpError(resp.status, text);
  try {
    return text ? JSON.parse(text) : {};
  } catch {
    throw new AdoHttpError(401, 'non-JSON response');
  }
}

const adoGet = (url: string, pat: string, timeoutMs = 20_000) => adoRequest(url, pat, { method: 'GET', timeoutMs }) as Promise<Record<string, any>>; // eslint-disable-line @typescript-eslint/no-explicit-any

export interface RunPipelineParams {
  organization: string;
  project: string;
  definitionId: string;
  decisionId: string;
  variables?: Record<string, string> | null;
  branch?: string | null;
  pat?: string | null;
  includeResumeVars?: boolean;
  templateParameters?: Record<string, unknown> | null;
}

export interface RunPipelineResult {
  success: boolean;
  run_id?: string;
  url?: string;
  error?: string;
}

/** Start a run. Never throws: failures are returned so callers can log them to history. */
export async function runPipeline(p: RunPipelineParams): Promise<RunPipelineResult> {
  const pat = p.pat || (await resolveAdoPat());
  if (!pat) return { success: false, error: 'ADO PAT not configured (set the ado-pat secret or AZURE_DEVOPS_PAT)' };

  const branch = p.branch || envStr('ADO_DEFAULT_BRANCH', 'refs/heads/main');
  const url = `${host()}/${q(p.organization)}/${q(p.project)}/_apis/pipelines/${q(String(p.definitionId))}/runs?api-version=${ADO_API_VERSION}`;

  // ADO 400s on queue-time variables unless the pipeline marks them settable; only the resume flow sends them.
  const runtimeVars: Record<string, { value: string; isSecret: boolean }> = {};
  if (p.includeResumeVars ?? true) {
    runtimeVars.GreenQA_ResumedDecisionId = { value: p.decisionId, isSecret: false };
    runtimeVars.GreenQA_Resumed = { value: 'true', isSecret: false };
  }
  for (const [k, v] of Object.entries(p.variables ?? {})) runtimeVars[k] = { value: String(v), isSecret: false };

  const body: Record<string, unknown> = { resources: { repositories: { self: { refName: branch } } } };
  if (Object.keys(runtimeVars).length) body.variables = runtimeVars;
  // Template parameters must be declared in the pipeline YAML or ADO returns 400.
  if (p.templateParameters) body.templateParameters = p.templateParameters;

  try {
    const payload = (await adoRequest(url, pat, { method: 'POST', body, timeoutMs: 30_000 })) as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
    return { success: true, run_id: String(payload.id), url: payload._links?.web?.href };
  } catch (err) {
    if (err instanceof AdoHttpError) {
      logger.error({ status: err.status, body: err.body.slice(0, 500) }, 'ADO runPipeline HTTP error');
      return { success: false, error: `HTTP ${err.status}: ${err.body.slice(0, 500)}` };
    }
    logger.error({ err: (err as Error).message }, 'ADO runPipeline failed');
    return { success: false, error: (err as Error).message };
  }
}

/** ADO emits 7-digit fractional seconds; truncate to ms so parsing never silently fails. */
export function parseAdoTimestamp(value?: string | null): Date | null {
  if (!value) return null;
  const text = value.trim().replace(/(\.\d{3})\d+/, '$1');
  const d = new Date(text);
  if (Number.isNaN(d.getTime())) {
    logger.info({ value }, 'parseAdoTimestamp: unparseable timestamp');
    return null;
  }
  return d;
}

/** Accepts https://dev.azure.com/{org}, dev.azure.com/{org}, https://{org}.visualstudio.com, or a bare org name. */
export function parseOrgUrl(orgUrl: string): string | null {
  if (!orgUrl) return null;
  const s = orgUrl.trim().replace(/\/+$/, '');
  let m = /dev\.azure\.com\/([^/]+)/i.exec(s);
  if (m) return m[1];
  m = /https?:\/\/([^.]+)\.visualstudio\.com/i.exec(s);
  if (m) return m[1];
  if (!s.includes('/') && !s.includes('.') && !s.includes(' ')) return s;
  return null;
}

export type ValidateResult =
  | { success: true; organization: string; org_url: string; projects: number }
  | { success: false; error: string };

export async function validateConnection(orgUrl: string, pat: string): Promise<ValidateResult> {
  const organization = parseOrgUrl(orgUrl);
  if (!organization) {
    return { success: false, error: 'Could not parse an organization from the Org URL. Expected e.g. https://dev.azure.com/your-org' };
  }
  if (!pat) return { success: false, error: 'A Personal Access Token (PAT) is required.' };

  try {
    const data = await adoGet(`${host()}/${q(organization)}/_apis/projects?api-version=${ADO_API_VERSION}`, pat);
    return {
      success: true,
      organization,
      org_url: orgUrl.trim().replace(/\/+$/, ''),
      projects: Number(data.count ?? (data.value ?? []).length),
    };
  } catch (err) {
    if (err instanceof AdoHttpError) {
      if (err.status === 401 || err.status === 203) {
        return { success: false, error: 'Authentication failed — check the PAT and its scopes (needs Build/Pipelines read).' };
      }
      if (err.status === 404) return { success: false, error: `Organization "${organization}" not found (HTTP 404).` };
      return { success: false, error: `ADO returned HTTP ${err.status}: ${err.body.slice(0, 200)}` };
    }
    const e = err as Error & { cause?: { message?: string } };
    if (e.name === 'TimeoutError' || e.name === 'TypeError') {
      return { success: false, error: `Could not reach dev.azure.com: ${e.cause?.message ?? e.message}` };
    }
    return { success: false, error: `Unexpected error validating connection: ${e.message}` };
  }
}

const mapRunStatus = (state?: string, result?: string): string => {
  const s = (state ?? '').toLowerCase();
  const r = (result ?? '').toLowerCase();
  if (s === 'completed') return ({ succeeded: 'Succeeded', failed: 'Failed', canceled: 'Canceled' } as Record<string, string>)[r] ?? 'Succeeded';
  if (s === 'inprogress' || s === 'canceling') return 'InProgress';
  return 'Queued';
};

function durationSeconds(start?: string | null, finish?: string | null): number | null {
  const s = parseAdoTimestamp(start);
  const f = parseAdoTimestamp(finish);
  if (!s || !f) return null;
  return Math.max(0, Math.trunc((f.getTime() - s.getTime()) / 1000));
}

export async function getRunStatus(organization: string, project: string, pipelineId: string, runId: string, pat: string) {
  const data = await adoGet(
    `${host()}/${q(organization)}/${q(project)}/_apis/pipelines/${q(String(pipelineId))}/runs/${q(String(runId))}?api-version=${ADO_API_VERSION}`,
    pat,
  );
  const state = (data.state ?? '').toLowerCase();
  const result = (data.result ?? '').toLowerCase();
  return {
    status: mapRunStatus(state, result),
    duration_seconds: durationSeconds(data.createdDate, data.finishedDate),
    web_url: data._links?.web?.href ?? null,
    raw_state: state,
    raw_result: result,
  };
}

export interface GroupedPipelines {
  organization: string;
  project: string;
  source: 'live';
  total: number;
  repos: { repo: string; project: string; pipelines: { definition_id: string; name: string; project: string; repo: string; folder: string; web_url: string }[] }[];
}

/** This deployment's pipelines grouped by repository (scoped by ADO_PROJECT + ADO_PIPELINE_IDS). */
export async function listPipelinesGrouped(orgUrl: string, pat: string): Promise<GroupedPipelines> {
  const organization = parseOrgUrl(orgUrl) || orgUrl;
  const project = configuredProject();
  const wanted = configuredPipelineIds();

  let definitions: Record<string, any>[] = []; // eslint-disable-line @typescript-eslint/no-explicit-any
  if (wanted.length) {
    const results = await Promise.all(wanted.map(async (id) => {
      try {
        return await adoGet(`${host()}/${q(organization)}/${q(project)}/_apis/build/definitions/${q(id)}?api-version=${ADO_API_VERSION}`, pat);
      } catch (err) {
        logger.error({ err: (err as Error).message, id, organization, project }, 'listPipelinesGrouped: definition not readable');
        return null;
      }
    }));
    definitions = results.filter((d): d is Record<string, any> => d !== null); // eslint-disable-line @typescript-eslint/no-explicit-any
  } else {
    try {
      const data = await adoGet(
        `${host()}/${q(organization)}/${q(project)}/_apis/build/definitions?api-version=${ADO_API_VERSION}&includeAllProperties=true&queryOrder=lastModifiedDescending`, pat);
      definitions = data.value ?? [];
    } catch (err) {
      logger.error({ err: (err as Error).message, organization, project }, 'listPipelinesGrouped: definitions failed');
    }
  }

  const buckets = new Map<string, GroupedPipelines['repos'][number]>();
  for (const d of definitions) {
    const repo: string = d.repository?.name || '(no repository)';
    if (!buckets.has(repo)) buckets.set(repo, { repo, project, pipelines: [] });
    buckets.get(repo)!.pipelines.push({
      definition_id: String(d.id ?? ''),
      name: d.name ?? '',
      project,
      repo,
      folder: String(d.path || '\\').replace(/^\\+|\\+$/g, ''),
      web_url: d._links?.web?.href ?? '',
    });
  }
  const repos = [...buckets.values()].sort((a, b) => a.repo.localeCompare(b.repo));
  for (const b of repos) b.pipelines.sort((x, y) => x.name.toLowerCase().localeCompare(y.name.toLowerCase()));
  return { organization, project, source: 'live', total: definitions.length, repos };
}

export interface AdoRun {
  run_id: string;
  name: string;
  status: string;
  created_at?: string;
  finished_at?: string;
  duration_seconds: number | null;
  pool?: string;
  commit_sha: string | null;
  author?: string;
  web_url?: string;
}

/** Real run history for one definition, newest first (Build API: carries timings, queue and commit). */
export async function listPipelineRuns(organization: string, project: string, definitionId: string, pat: string, top = 50): Promise<AdoRun[]> {
  const data = await adoGet(
    `${host()}/${q(organization)}/${q(project)}/_apis/build/builds?definitions=${q(String(definitionId))}&$top=${Math.trunc(top)}&queryOrder=queueTimeDescending&api-version=${ADO_API_VERSION}`,
    pat,
  );
  return ((data.value ?? []) as Record<string, any>[]).slice(0, top).map((b) => ({ // eslint-disable-line @typescript-eslint/no-explicit-any
    run_id: String(b.id ?? ''),
    name: b.buildNumber ?? '',
    status: mapRunStatus(b.status, b.result),
    created_at: b.queueTime || b.startTime,
    finished_at: b.finishTime,
    duration_seconds: durationSeconds(b.startTime, b.finishTime),
    pool: b.queue?.name,
    commit_sha: String(b.sourceVersion ?? '').slice(0, 7) || null,
    author: b.requestedFor?.displayName,
    web_url: b._links?.web?.href,
  }));
}
