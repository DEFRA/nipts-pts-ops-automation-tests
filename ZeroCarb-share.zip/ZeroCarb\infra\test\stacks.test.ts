import * as cdk from 'aws-cdk-lib';
import { Match, Template } from 'aws-cdk-lib/assertions';
import { beforeAll, describe, expect, it } from 'vitest';
import { AppStack } from '../lib/app-stack';
import { ENVIRONMENTS, resolveEnv, type DeployEnv } from '../lib/config';
import { DataStack } from '../lib/data-stack';
import { EdgeStack } from '../lib/edge-stack';

function synth(name: DeployEnv) {
  // Skip esbuild bundling: these tests assert topology, not the bundle.
  const app = new cdk.App({ context: { 'aws:cdk:bundling-stacks': [] } });
  const cfg = ENVIRONMENTS[name];
  const env = { account: '111111111111', region: cfg.region };
  const data = new DataStack(app, 'Data', cfg, { env, crossRegionReferences: true });
  const edge = new EdgeStack(app, 'Edge', cfg, { env: { account: env.account, region: 'us-east-1' }, crossRegionReferences: true });
  const appStack = new AppStack(app, 'App', cfg, { env, data, edge, crossRegionReferences: true });
  return { data: Template.fromStack(data), edge: Template.fromStack(edge), app: Template.fromStack(appStack) };
}

describe('prod', () => {
  let t: ReturnType<typeof synth>;
  beforeAll(() => { t = synth('prod'); });

  it('protects data: PITR, deletion protection, retention and a replica', () => {
    t.data.hasResourceProperties('AWS::DynamoDB::GlobalTable', Match.objectLike({
      BillingMode: 'PAY_PER_REQUEST',
      Replicas: Match.arrayWith([Match.objectLike({ Region: 'eu-west-1' }), Match.objectLike({ PointInTimeRecoverySpecification: { PointInTimeRecoveryEnabled: true } })]),
    }));
    t.data.allResourcesProperties('AWS::DynamoDB::GlobalTable', Match.objectLike({ SSESpecification: Match.anyValue() }));
    t.data.hasResource('AWS::Cognito::UserPool', { DeletionPolicy: 'Retain' });
    t.data.hasResourceProperties('AWS::Cognito::UserPool', Match.objectLike({ MfaConfiguration: 'ON' }));
  });

  it('defines the three RBAC groups and the machine scope', () => {
    for (const g of ['admin', 'operator', 'viewer']) t.data.hasResourceProperties('AWS::Cognito::UserPoolGroup', { GroupName: g });
    t.data.hasResourceProperties('AWS::Cognito::UserPoolResourceServer', Match.objectLike({ Identifier: 'greenqa' }));
  });

  it('puts a JWT authorizer on the proxy route only and throttles the stage', () => {
    t.app.hasResourceProperties('AWS::ApiGatewayV2::Authorizer', { AuthorizerType: 'JWT' });
    const routes = t.app.findResources('AWS::ApiGatewayV2::Route');
    const byKey = Object.values(routes).map((r) => r.Properties);
    const open = byKey.filter((p) => p.AuthorizationType === 'NONE').map((p) => p.RouteKey).sort();
    expect(open).toEqual(['GET /api/health', 'POST /api/ingest-ado-event']);
    expect(byKey.find((p) => p.RouteKey === 'ANY /api/{proxy+}')?.AuthorizationType).toBe('JWT');
    t.app.hasResourceProperties('AWS::ApiGatewayV2::Stage', Match.objectLike({ DefaultRouteSettings: { ThrottlingRateLimit: 500, ThrottlingBurstLimit: 1000 } }));
  });

  it('schedules ingest every 30 min and resume every 5 min', () => {
    t.app.hasResourceProperties('AWS::Events::Rule', Match.objectLike({ ScheduleExpression: 'rate(30 minutes)' }));
    t.app.hasResourceProperties('AWS::Events::Rule', Match.objectLike({ ScheduleExpression: 'rate(5 minutes)' }));
  });

  it('keeps the site bucket private and serves it through CloudFront with WAF and HTTPS-only API', () => {
    t.app.hasResourceProperties('AWS::S3::Bucket', Match.objectLike({ PublicAccessBlockConfiguration: Match.objectLike({ BlockPublicAcls: true, RestrictPublicBuckets: true }) }));
    t.app.hasResourceProperties('AWS::CloudFront::Distribution', Match.objectLike({
      DistributionConfig: Match.objectLike({
        WebACLId: Match.anyValue(),
        DefaultRootObject: 'index.html',
        CacheBehaviors: [Match.objectLike({ PathPattern: '/api/*', ViewerProtocolPolicy: 'https-only' })],
      }),
    }));
  });

  it('has WAF managed rules and a rate limit at the edge', () => {
    t.edge.hasResourceProperties('AWS::WAFv2::WebACL', Match.objectLike({ Scope: 'CLOUDFRONT' }));
    const acl = Object.values(t.edge.findResources('AWS::WAFv2::WebACL'))[0].Properties;
    expect(acl.Rules.map((r: { Name: string }) => r.Name)).toEqual(['RateLimitPerIp', 'IpReputation', 'CommonRuleSet', 'KnownBadInputs']);
    expect(acl.Rules[0].Statement.RateBasedStatement.Limit).toBe(1000);
  });

  it('least-privilege: no wildcard resource on secrets or tables for the API role', () => {
    const policies = Object.values(t.app.findResources('AWS::IAM::Policy')).flatMap((p) => p.Properties.PolicyDocument.Statement);
    const wild = policies.filter((s: { Resource: unknown; Action: unknown }) => s.Resource === '*' && JSON.stringify(s.Action).includes('secretsmanager'));
    expect(wild).toEqual([]);
  });

  it('alarms on errors, latency, ingest freshness and DLQ', () => {
    for (const name of ['ApiLambdaErrors', 'Api5xx', 'CarbonIngestStale', 'SchedulerDlqDepth', 'ApiLatencyP95']) {
      t.app.hasResourceProperties('AWS::CloudWatch::Alarm', { AlarmName: `zerocarb-prod-${name}` });
    }
    t.app.resourceCountIs('AWS::CloudWatch::Dashboard', 1);
  });

  it('backs up tables daily and monthly', () => {
    t.data.hasResourceProperties('AWS::Backup::BackupPlan', Match.objectLike({
      BackupPlan: Match.objectLike({ BackupPlanRule: Match.arrayWith([Match.objectLike({ RuleName: 'daily' }), Match.objectLike({ RuleName: 'monthly' })]) }),
    }));
  });
});

describe('dev', () => {
  it('is destroyable, has no replicas and allows seeding', () => {
    const t = synth('dev');
    t.data.hasResource('AWS::Cognito::UserPool', { DeletionPolicy: 'Delete' });
    t.data.hasResourceProperties('AWS::DynamoDB::GlobalTable', Match.objectLike({ Replicas: [Match.objectLike({ Region: 'eu-west-2' })] }));
    t.app.hasResourceProperties('AWS::Lambda::Function', Match.objectLike({
      Environment: { Variables: Match.objectLike({ APP_ENV: 'dev', DEV_SEED_ENABLED: 'true', AUTH_MODE: 'cognito' }) },
    }));
  });
});

describe('config', () => {
  it('rejects unknown environments', () => expect(() => resolveEnv('staging')).toThrow(/Unknown environment/));
});
