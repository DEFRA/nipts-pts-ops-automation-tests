import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { mockClient } from 'aws-sdk-client-mock';
import { beforeEach, describe, expect, it } from 'vitest';
import { DynamoRepository } from '../src/repo/dynamo';

const ddb = mockClient(DynamoDBDocumentClient);
const tables = { carbon: 'carbon', executions: 'exec', deferred: 'def', connections: 'conn', audit: 'audit' };
const repo = () => new DynamoRepository(tables, new DynamoDBClient({ region: 'eu-west-2' }));

beforeEach(() => ddb.reset());

describe('DynamoRepository', () => {
  it('writes executions with key and index attributes', async () => {
    ddb.on(PutCommand).resolves({});
    await repo().upsertExecution({ id: 'p::r', pipeline_id: 'p', provider: 'azure', stored_at: '2026-01-01T00:00:00Z' });
    const item = ddb.commandCalls(PutCommand)[0].args[0].input.Item!;
    expect(item).toMatchObject({ pk: 'p', sk: 'p::r', gsi1pk: 'p#azure', gsi2pk: 'azure', gsi1sk: '2026-01-01T00:00:00Z' });
  });

  it('queries the pipeline index newest first and strips internal keys', async () => {
    ddb.on(QueryCommand).resolves({ Items: [{ pk: 'p', sk: 'x', gsi1pk: 'p#azure', id: 'x', pipeline_id: 'p' }] });
    const rows = await repo().listExecutionsForPipeline('p', 'azure', 10);
    const input = ddb.commandCalls(QueryCommand)[0].args[0].input;
    expect(input).toMatchObject({ IndexName: 'by_pipeline_provider', ScanIndexForward: false });
    expect(rows).toEqual([{ id: 'x', pipeline_id: 'p' }]);
  });

  it('follows pagination for date-range reads', async () => {
    ddb.on(QueryCommand)
      .resolvesOnce({ Items: [{ id: 'a' }], LastEvaluatedKey: { pk: 'k' } })
      .resolvesOnce({ Items: [{ id: 'b' }] });
    expect(await repo().listExecutionsSince('azure', '2026-01-01')).toHaveLength(2);
  });

  it('indexes deferred runs by status and gives samples a TTL', async () => {
    ddb.on(PutCommand).resolves({});
    await repo().upsertDeferred({ id: 'd1', status: 'pending', defer_until_iso: '2026-01-01T01:00:00Z' });
    await repo().upsertCarbonSample({ id: 's', provider: 'azure', region: 'uksouth', sampled_at: 't', grid_intensity_gco2_kwh: 1, dc_intensity_gco2_kwh: 1 });
    const [d, c] = ddb.commandCalls(PutCommand).map((x) => x.args[0].input.Item!);
    expect(d).toMatchObject({ pk: 'd1', gsi1pk: 'pending' });
    expect(c).toMatchObject({ pk: 'azure#uksouth', sk: 't' });
    expect(typeof c.expires_at).toBe('number');
  });

  it('returns the latest carbon sample via a descending limit-1 query', async () => {
    ddb.on(QueryCommand).resolves({ Items: [{ pk: 'azure#uksouth', sk: 't', region: 'uksouth' }] });
    expect(await repo().getLatestCarbon('azure', 'uksouth')).toEqual({ region: 'uksouth' });
    expect(ddb.commandCalls(QueryCommand)[0].args[0].input).toMatchObject({ Limit: 1, ScanIndexForward: false });
  });

  it('returns null for a missing connection', async () => {
    ddb.on(GetCommand).resolves({});
    expect(await repo().getConnection()).toBeNull();
  });
});
