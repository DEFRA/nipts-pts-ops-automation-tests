import * as cdk from 'aws-cdk-lib';
import * as apigwv2 from 'aws-cdk-lib/aws-apigatewayv2';
import * as authorizers from 'aws-cdk-lib/aws-apigatewayv2-authorizers';
import * as integrations from 'aws-cdk-lib/aws-apigatewayv2-integrations';
import * as cloudwatch from 'aws-cdk-lib/aws-cloudwatch';
import * as cwActions from 'aws-cdk-lib/aws-cloudwatch-actions';
import * as cloudfront from 'aws-cdk-lib/aws-cloudfront';
import * as origins from 'aws-cdk-lib/aws-cloudfront-origins';
import * as cognito from 'aws-cdk-lib/aws-cognito';
import * as dynamodb from 'aws-cdk-lib/aws-dynamodb';
import * as events from 'aws-cdk-lib/aws-events';
import * as targets from 'aws-cdk-lib/aws-events-targets';
import * as lambda from 'aws-cdk-lib/aws-lambda';
import * as nodejs from 'aws-cdk-lib/aws-lambda-nodejs';
import * as logs from 'aws-cdk-lib/aws-logs';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as route53Targets from 'aws-cdk-lib/aws-route53-targets';
import * as s3 from 'aws-cdk-lib/aws-s3';
import * as s3deploy from 'aws-cdk-lib/aws-s3-deployment';
import * as sns from 'aws-cdk-lib/aws-sns';
import * as subscriptions from 'aws-cdk-lib/aws-sns-subscriptions';
import * as sqs from 'aws-cdk-lib/aws-sqs';
import { Construct } from 'constructs';
import * as fs from 'node:fs';
import * as path from 'node:path';
import type { EnvConfig } from './config';
import { DataStack, RESOURCE_SERVER_ID } from './data-stack';
import type { EdgeStack } from './edge-stack';

const REPO_ROOT = path.resolve(__dirname, '..', '..');
const API_SRC = path.join(REPO_ROOT, 'apps', 'api', 'src');
const WEB_BUILD = path.join(REPO_ROOT, 'build', 'web');

export interface AppStackProps extends cdk.StackProps {
  data: DataStack;
  edge: EdgeStack;
}

export class AppStack extends cdk.Stack {
  readonly distribution: cloudfront.Distribution;
  readonly apiFunction: nodejs.NodejsFunction;
  readonly schedulerFunction: nodejs.NodejsFunction;
  readonly alarmTopic: sns.Topic;
  readonly spaClient: cognito.UserPoolClient;

  constructor(scope: Construct, id: string, readonly cfg: EnvConfig, props: AppStackProps) {
    super(scope, id, props);
    const { data, edge } = props;
    const removal = cfg.retainData ? cdk.RemovalPolicy.RETAIN : cdk.RemovalPolicy.DESTROY;
    const retention = cfg.logRetentionDays as logs.RetentionDays; // enum values are day counts
    const version = String(this.node.tryGetContext('version') ?? 'dev');

    // ---- Web hosting: private S3 behind CloudFront (OAC) ---------------------------------------------------------------
    const accessLogs = new s3.Bucket(this, 'AccessLogs', {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      objectOwnership: s3.ObjectOwnership.BUCKET_OWNER_PREFERRED,
      lifecycleRules: [{ expiration: cdk.Duration.days(cfg.name === 'prod' ? 400 : 90) }],
      removalPolicy: removal,
      autoDeleteObjects: !cfg.retainData,
    });
    const siteBucket = new s3.Bucket(this, 'SiteBucket', {
      blockPublicAccess: s3.BlockPublicAccess.BLOCK_ALL,
      encryption: s3.BucketEncryption.S3_MANAGED,
      enforceSSL: true,
      versioned: true,
      serverAccessLogsBucket: accessLogs,
      serverAccessLogsPrefix: 'site/',
      removalPolicy: removal,
      autoDeleteObjects: !cfg.retainData,
    });

    // ---- API: Lambda (Express) behind an HTTP API with a Cognito JWT authorizer ----------------------------------------
    const commonEnv: Record<string, string> = {
      APP_ENV: cfg.name,
      APP_VERSION: version,
      LOG_LEVEL: cfg.name === 'prod' ? 'info' : 'debug',
      AUTH_MODE: 'cognito',
      COGNITO_USER_POOL_ID: data.userPool.userPoolId,
      RESOURCE_SERVER_ID,
      TABLE_CARBON: data.carbonTable.tableName,
      TABLE_EXECUTIONS: data.executionsTable.tableName,
      TABLE_DEFERRED: data.deferredTable.tableName,
      TABLE_CONNECTIONS: data.connectionsTable.tableName,
      TABLE_AUDIT: data.auditTable.tableName,
      SECRET_ID_ADO_PAT: data.adoPatSecret.secretArn,
      SECRET_ID_AWS_CREDENTIALS: data.awsCredentialsSecret.secretArn,
      SECRET_ID_ELECTRICITYMAPS: data.electricityMapsSecret.secretArn,
      SECRET_ID_WEBHOOK: data.webhookSecret.secretArn,
      ADO_ORG_URL: cfg.app.adoOrgUrl,
      ADO_PROJECT: cfg.app.adoProject,
      ADO_PIPELINE_IDS: cfg.app.adoPipelineIds,
      GREENQA_EXECUTION_REGIONS: cfg.app.executionRegions,
      DEV_SEED_ENABLED: String(cfg.app.devSeedEnabled),
      NESO_USE_LIVE: String(cfg.app.liveCarbonSources),
      ELECTRICITYMAPS_USE_LIVE: String(cfg.app.liveCarbonSources),
      ENERGY_CHARTS_USE_LIVE: String(cfg.app.liveCarbonSources),
      NODE_OPTIONS: '--enable-source-maps',
    };

    const bundling: nodejs.BundlingOptions = {
      format: nodejs.OutputFormat.ESM,
      target: 'node22',
      minify: true,
      sourceMap: true,
      mainFields: ['module', 'main'],
      banner: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);",
    };
    const fn = (id: string, entry: string, opts: Partial<nodejs.NodejsFunctionProps>) =>
      new nodejs.NodejsFunction(this, id, {
        entry: path.join(API_SRC, 'handlers', entry),
        projectRoot: REPO_ROOT,
        depsLockFilePath: path.join(REPO_ROOT, 'package-lock.json'),
        runtime: lambda.Runtime.NODEJS_22_X,
        architecture: lambda.Architecture.ARM_64,
        tracing: lambda.Tracing.ACTIVE,
        logGroup: new logs.LogGroup(this, `${id}Logs`, { retention, removalPolicy: removal }),
        environment: commonEnv,
        bundling,
        ...opts,
      });

    this.apiFunction = fn('ApiFunction', 'api.ts', {
      functionName: `zerocarb-${cfg.name}-api`,
      memorySize: cfg.api.lambdaMemoryMb,
      timeout: cdk.Duration.seconds(29), // API Gateway's integration limit is 30s
      reservedConcurrentExecutions: cfg.api.reservedConcurrency,
    });
    this.schedulerFunction = fn('SchedulerFunction', 'scheduler.ts', {
      functionName: `zerocarb-${cfg.name}-scheduler`,
      memorySize: 512,
      timeout: cdk.Duration.minutes(5),
      retryAttempts: 0, // EventBridge handles retries
    });

    for (const f of [this.apiFunction, this.schedulerFunction]) {
      for (const t of [data.carbonTable, data.executionsTable, data.deferredTable, data.connectionsTable, data.auditTable]) t.grantReadWriteData(f);
      data.adoPatSecret.grantRead(f);
      data.awsCredentialsSecret.grantRead(f);
      data.electricityMapsSecret.grantRead(f);
      data.webhookSecret.grantRead(f);
    }
    // Only the API may write the PAT (dashboard "connect" flow).
    data.adoPatSecret.grantWrite(this.apiFunction);
    data.awsCredentialsSecret.grantWrite(this.apiFunction);

    this.spaClient = new cognito.UserPoolClient(this, 'SpaClient', {
      userPool: data.userPool,
      userPoolClientName: `zerocarb-${cfg.name}-spa`,
      generateSecret: false,
      authFlows: {},
      preventUserExistenceErrors: true,
      enableTokenRevocation: true,
      accessTokenValidity: cdk.Duration.minutes(60),
      idTokenValidity: cdk.Duration.minutes(60),
      refreshTokenValidity: cdk.Duration.days(1),
      oAuth: {
        flows: { authorizationCodeGrant: true }, // PKCE
        scopes: [cognito.OAuthScope.OPENID, cognito.OAuthScope.EMAIL, cognito.OAuthScope.PROFILE],
        callbackUrls: ['https://placeholder.invalid/'], // replaced below once the CloudFront domain is known
        logoutUrls: ['https://placeholder.invalid/'],
      },
    });

    const issuer = data.userPool.userPoolProviderUrl;
    const authorizer = new authorizers.HttpJwtAuthorizer('CognitoAuthorizer', issuer, {
      jwtAudience: [this.spaClient.userPoolClientId, data.machineClient.userPoolClientId],
    });
    const integration = new integrations.HttpLambdaIntegration('ApiIntegration', this.apiFunction);

    const apiLogs = new logs.LogGroup(this, 'ApiAccessLogs', { retention, removalPolicy: removal });
    const httpApi = new apigwv2.HttpApi(this, 'HttpApi', {
      apiName: `zerocarb-${cfg.name}`,
      description: 'ZeroCarb REST API (/api/*)',
    });
    // Public routes (health probe, ADO webhook secured by shared secret) are more specific than the proxy route.
    httpApi.addRoutes({ path: '/api/health', methods: [apigwv2.HttpMethod.GET], integration });
    httpApi.addRoutes({ path: '/api/ingest-ado-event', methods: [apigwv2.HttpMethod.POST], integration });
    httpApi.addRoutes({ path: '/api/{proxy+}', methods: [apigwv2.HttpMethod.ANY], integration, authorizer });

    const stage = httpApi.defaultStage!.node.defaultChild as apigwv2.CfnStage;
    stage.defaultRouteSettings = { throttlingRateLimit: cfg.api.throttleRate, throttlingBurstLimit: cfg.api.throttleBurst };
    stage.accessLogSettings = {
      destinationArn: apiLogs.logGroupArn,
      format: JSON.stringify({
        requestId: '$context.requestId', ip: '$context.identity.sourceIp', method: '$context.httpMethod', path: '$context.path',
        status: '$context.status', latencyMs: '$context.responseLatency', integrationError: '$context.integrationErrorMessage',
        authorizerError: '$context.authorizer.error', sub: '$context.authorizer.claims.sub',
      }),
    };

    // ---- Scheduled jobs (replace the Functions timer triggers) --------------------------------------------------------
    const dlq = new sqs.Queue(this, 'SchedulerDlq', { retentionPeriod: cdk.Duration.days(14), enforceSSL: true });
    const schedule = (id: string, task: string, rate: cdk.Duration) =>
      new events.Rule(this, id, {
        ruleName: `zerocarb-${cfg.name}-${task.replace('_', '-')}`,
        schedule: events.Schedule.rate(rate),
        targets: [new targets.LambdaFunction(this.schedulerFunction, {
          event: events.RuleTargetInput.fromObject({ task }),
          retryAttempts: 2,
          deadLetterQueue: dlq,
        })],
      });
    schedule('IngestCarbonRule', 'ingest_carbon', cdk.Duration.minutes(30));
    schedule('ResumeDeferredRule', 'resume_deferred', cdk.Duration.minutes(5));

    // ---- CDN -----------------------------------------------------------------------------------------------------------
    const apiDomain = cdk.Fn.select(2, cdk.Fn.split('/', httpApi.apiEndpoint));
    const cognitoHost = `${data.cognitoDomain.domainName}.auth.${data.region}.amazoncognito.com`;
    const securityHeaders = new cloudfront.ResponseHeadersPolicy(this, 'SecurityHeaders', {
      securityHeadersBehavior: {
        // The SPA transpiles JSX in-browser with Babel standalone, which requires 'unsafe-eval'.
        contentSecurityPolicy: {
          override: true,
          contentSecurityPolicy: [
            "default-src 'self'",
            "script-src 'self' 'unsafe-eval' https://cdn.jsdelivr.net",
            "style-src 'self' 'unsafe-inline'",
            "img-src 'self' data:",
            `connect-src 'self' https://${cognitoHost}`,
            "frame-ancestors 'none'",
            "base-uri 'self'",
            "form-action 'self'",
            "object-src 'none'",
          ].join('; '),
        },
        strictTransportSecurity: { override: true, accessControlMaxAge: cdk.Duration.days(730), includeSubdomains: true, preload: true },
        contentTypeOptions: { override: true },
        frameOptions: { override: true, frameOption: cloudfront.HeadersFrameOption.DENY },
        referrerPolicy: { override: true, referrerPolicy: cloudfront.HeadersReferrerPolicy.STRICT_ORIGIN_WHEN_CROSS_ORIGIN },
      },
      customHeadersBehavior: {
        customHeaders: [{ header: 'Permissions-Policy', value: 'geolocation=(), microphone=(), camera=()', override: true }],
      },
    });

    this.distribution = new cloudfront.Distribution(this, 'Cdn', {
      comment: `ZeroCarb ${cfg.name}`,
      defaultRootObject: 'index.html',
      // TLS 1.2+ is only enforceable with a custom-domain certificate (set `domain` for uat/prod).
      minimumProtocolVersion: edge.certificate ? cloudfront.SecurityPolicyProtocol.TLS_V1_2_2021 : undefined,
      httpVersion: cloudfront.HttpVersion.HTTP2_AND_3,
      webAclId: edge.webAcl.attrArn,
      enableLogging: true,
      logBucket: accessLogs,
      logFilePrefix: 'cdn/',
      domainNames: cfg.domain ? [cfg.domain.name] : undefined,
      certificate: edge.certificate,
      defaultBehavior: {
        origin: origins.S3BucketOrigin.withOriginAccessControl(siteBucket),
        viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.REDIRECT_TO_HTTPS,
        cachePolicy: cloudfront.CachePolicy.CACHING_OPTIMIZED,
        responseHeadersPolicy: securityHeaders,
        compress: true,
      },
      additionalBehaviors: {
        '/api/*': {
          origin: new origins.HttpOrigin(apiDomain, { protocolPolicy: cloudfront.OriginProtocolPolicy.HTTPS_ONLY, readTimeout: cdk.Duration.seconds(30) }),
          viewerProtocolPolicy: cloudfront.ViewerProtocolPolicy.HTTPS_ONLY,
          allowedMethods: cloudfront.AllowedMethods.ALLOW_ALL,
          cachePolicy: cloudfront.CachePolicy.CACHING_DISABLED,
          originRequestPolicy: cloudfront.OriginRequestPolicy.ALL_VIEWER_EXCEPT_HOST_HEADER,
          responseHeadersPolicy: cloudfront.ResponseHeadersPolicy.SECURITY_HEADERS,
        },
      },
    });

    const siteUrl = cfg.domain ? `https://${cfg.domain.name}` : `https://${this.distribution.distributionDomainName}`;
    const callbackUrls = [`${siteUrl}/`, ...cfg.extraCallbackOrigins.map((o) => `${o}/`)];
    const cfnClient = this.spaClient.node.defaultChild as cognito.CfnUserPoolClient;
    cfnClient.callbackUrLs = callbackUrls;
    cfnClient.logoutUrLs = callbackUrls;

    if (cfg.domain) {
      const zone = route53.HostedZone.fromHostedZoneAttributes(this, 'Zone', { hostedZoneId: cfg.domain.hostedZoneId, zoneName: cfg.domain.hostedZoneName });
      new route53.ARecord(this, 'Alias', { zone, recordName: cfg.domain.name, target: route53.RecordTarget.fromAlias(new route53Targets.CloudFrontTarget(this.distribution)) });
    }

    // Static assets + runtime config (same-origin API => no CORS; Cognito details are public identifiers).
    const runtimeConfig = [
      "window.GREEN_QA_API_URL = '/api';",
      `window.GREEN_QA_DEFAULT_ORG_URL = ${JSON.stringify(cfg.app.adoOrgUrl)};`,
      `window.GREEN_QA_AUTH = ${cdk.Stack.of(this).toJsonString({
        region: data.region,
        domain: cognitoHost,
        clientId: this.spaClient.userPoolClientId,
      })};`,
      `window.GREEN_QA_ENV = ${JSON.stringify(cfg.name)};`,
    ].join('\n');

    const webSources: s3deploy.ISource[] = fs.existsSync(WEB_BUILD)
      ? [s3deploy.Source.asset(WEB_BUILD, { exclude: ['config.js'] })]
      : [s3deploy.Source.data('index.html', '<!doctype html><title>ZeroCarb</title><p>Run `npm run build:web` before deploying.</p>')];
    if (!fs.existsSync(WEB_BUILD)) cdk.Annotations.of(this).addWarning('build/web not found — run `npm run build:web` before `cdk deploy`.');
    new s3deploy.BucketDeployment(this, 'WebDeployment', {
      sources: [...webSources, s3deploy.Source.data('config.js', runtimeConfig)],
      destinationBucket: siteBucket,
      distribution: this.distribution,
      distributionPaths: ['/*'],
      cacheControl: [s3deploy.CacheControl.noCache()],
      prune: true,
    });

    // ---- Observability -------------------------------------------------------------------------------------------------
    this.alarmTopic = new sns.Topic(this, 'AlarmTopic', { topicName: `zerocarb-${cfg.name}-alarms`, enforceSSL: true });
    if (cfg.alarmEmail) this.alarmTopic.addSubscription(new subscriptions.EmailSubscription(cfg.alarmEmail));
    const notify = new cwActions.SnsAction(this.alarmTopic);

    const alarm = (id: string, metric: cloudwatch.IMetric, threshold: number, desc: string, opts: Partial<cloudwatch.AlarmProps> = {}) => {
      const a = new cloudwatch.Alarm(this, id, {
        alarmName: `zerocarb-${cfg.name}-${id}`,
        alarmDescription: desc,
        metric,
        threshold,
        evaluationPeriods: 3,
        datapointsToAlarm: 2,
        comparisonOperator: cloudwatch.ComparisonOperator.GREATER_THAN_OR_EQUAL_TO_THRESHOLD,
        treatMissingData: cloudwatch.TreatMissingData.NOT_BREACHING,
        ...opts,
      });
      a.addAlarmAction(notify);
      a.addOkAction(notify);
      return a;
    };

    const fiveMin = cdk.Duration.minutes(5);
    alarm('ApiLambdaErrors', this.apiFunction.metricErrors({ period: fiveMin }), 5, 'API Lambda is throwing errors');
    alarm('ApiLambdaThrottles', this.apiFunction.metricThrottles({ period: fiveMin }), 1, 'API Lambda is being throttled');
    alarm('ApiLambdaP99', this.apiFunction.metricDuration({ period: fiveMin, statistic: 'p99' }), 20_000, 'API p99 latency approaching the 29s limit');
    alarm('Api5xx', httpApi.metricServerError({ period: fiveMin }), 5, 'HTTP API returning 5xx');
    alarm('ApiLatencyP95', httpApi.metricLatency({ period: fiveMin, statistic: 'p95' }), 3000, 'HTTP API p95 latency above 3s');
    alarm('SchedulerErrors', this.schedulerFunction.metricErrors({ period: cdk.Duration.minutes(30) }), 1, 'Scheduled carbon ingest / deferred resume failed', { evaluationPeriods: 1, datapointsToAlarm: 1 });
    alarm('SchedulerDlqDepth', dlq.metricApproximateNumberOfMessagesVisible({ period: fiveMin }), 1, 'Scheduler invocations landed in the DLQ', { evaluationPeriods: 1, datapointsToAlarm: 1 });
    const ingestItems = new cloudwatch.Metric({
      namespace: 'ZeroCarb', metricName: 'SchedulerTaskItems', dimensionsMap: { Task: 'ingest_carbon' }, statistic: 'Sum', period: cdk.Duration.hours(1),
    });
    alarm('CarbonIngestStale', ingestItems, 1, 'No carbon samples ingested for 2 hours (data is going stale)', {
      comparisonOperator: cloudwatch.ComparisonOperator.LESS_THAN_THRESHOLD,
      treatMissingData: cloudwatch.TreatMissingData.BREACHING,
      evaluationPeriods: 2,
      datapointsToAlarm: 2,
    });
    for (const [name, table] of [['Executions', data.executionsTable], ['Carbon', data.carbonTable]] as const) {
      alarm(`Dynamo${name}Throttles`, table.metricThrottledRequestsForOperations({
        operations: [dynamodb.Operation.GET_ITEM, dynamodb.Operation.PUT_ITEM, dynamodb.Operation.QUERY], period: fiveMin,
      }), 1, `${name} table throttling`);
    }

    new cloudwatch.Dashboard(this, 'Dashboard', {
      dashboardName: `zerocarb-${cfg.name}`,
      widgets: [
        [
          new cloudwatch.GraphWidget({ title: 'API requests / 5xx / 4xx', width: 8, left: [httpApi.metricCount({ period: fiveMin }), httpApi.metricServerError({ period: fiveMin }), httpApi.metricClientError({ period: fiveMin })] }),
          new cloudwatch.GraphWidget({ title: 'API latency', width: 8, left: [httpApi.metricLatency({ period: fiveMin, statistic: 'p50' }), httpApi.metricLatency({ period: fiveMin, statistic: 'p95' }), httpApi.metricLatency({ period: fiveMin, statistic: 'p99' })] }),
          new cloudwatch.GraphWidget({ title: 'Lambda errors / throttles', width: 8, left: [this.apiFunction.metricErrors({ period: fiveMin }), this.apiFunction.metricThrottles({ period: fiveMin }), this.schedulerFunction.metricErrors({ period: fiveMin })] }),
        ],
        [
          new cloudwatch.GraphWidget({
            title: 'Scheduling decisions',
            width: 12,
            left: ['RUN_NOW', 'DEFER', 'RELOCATE', 'HYBRID'].map((d) => new cloudwatch.Metric({
              namespace: 'ZeroCarb', metricName: 'Decisions', dimensionsMap: { Decision: d, Provider: 'azure' }, statistic: 'Sum', period: cdk.Duration.hours(1), label: d,
            })),
          }),
          new cloudwatch.GraphWidget({ title: 'Carbon samples ingested (per hour)', width: 12, left: [ingestItems] }),
        ],
      ],
    });

    cdk.Tags.of(this).add('Tier', 'app');

    new cdk.CfnOutput(this, 'SiteUrl', { value: siteUrl });
    new cdk.CfnOutput(this, 'ApiUrl', { value: `${siteUrl}/api` });
    new cdk.CfnOutput(this, 'UserPoolId', { value: data.userPool.userPoolId });
    new cdk.CfnOutput(this, 'SpaClientId', { value: this.spaClient.userPoolClientId });
    new cdk.CfnOutput(this, 'PipelineClientId', { value: data.machineClient.userPoolClientId });
    new cdk.CfnOutput(this, 'TokenEndpoint', { value: `https://${cognitoHost}/oauth2/token` });
    new cdk.CfnOutput(this, 'WebhookSecretArn', { value: data.webhookSecret.secretArn });
    new cdk.CfnOutput(this, 'AdoPatSecretArn', { value: data.adoPatSecret.secretArn });
    new cdk.CfnOutput(this, 'SiteBucketName', { value: siteBucket.bucketName });
    new cdk.CfnOutput(this, 'DistributionId', { value: this.distribution.distributionId });
  }
}
