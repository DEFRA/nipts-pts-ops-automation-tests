import { logger } from '../logger';

/** JSON GET with a hard timeout. Returns null on any failure so callers can fall back. */
export async function httpGetJson<T = unknown>(url: string, timeoutMs: number, headers: Record<string, string> = {}): Promise<T | null> {
  try {
    const resp = await fetch(url, {
      headers: { Accept: 'application/json', ...headers },
      signal: AbortSignal.timeout(timeoutMs),
    });
    if (!resp.ok) {
      logger.warn({ url, status: resp.status }, 'http_get_json non-2xx');
      return null;
    }
    return (await resp.json()) as T;
  } catch (err) {
    logger.warn({ url, err: (err as Error).message }, 'http_get_json failed');
    return null;
  }
}
