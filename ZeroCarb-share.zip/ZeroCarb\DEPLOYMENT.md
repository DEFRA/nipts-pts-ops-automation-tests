# Carbon Cost Dashboard — Deployment Guide

This is the **canonical, code-accurate** deployment guide for what is in
this repository. For the (more ambitious) target architecture see
`GAPS.md`. For the system component diagram see `docs/ARCHITECTURE.md`.

> If you've read earlier versions of this file referencing `/v1/*`
> routes, `make deploy`, Front Door, or a `green-qa-utility/` artifact
> layout — those described a future state. The code under
> `backend/azure/functions/` ships `/api/*` routes today.

---

## 1 · Prerequisites

- Azure CLI ≥ 2.55, signed-in (`az login`)
- Bicep CLI ≥ 0.27 (bundled with recent `az`)
- Python 3.11+ (Function App targets Python 3.11)
- Azure Functions Core Tools v4 (`func --version` ≥ 4.0)
- (Optional) Static Web Apps CLI (`npm i -g @azure/static-web-apps-cli`)

Permissions required on the target subscription:
- `Contributor` on the resource group
- `User Access Administrator` (or `Owner`) on the resource group (for the
  RBAC role assignments the Bicep declares)

---

## 2 · What gets deployed

A single Bicep template (`backend/infrastructure/azure/main.bicep`)
provisions one resource group's worth of resources:

| Resource | SKU | Purpose |
|---|---|---|
| Storage Account | `Standard_LRS` | Required by the Functions runtime |
| Log Analytics workspace | `PerGB2018` | App Insights backend, 30-day retention |
| Application Insights | Pay-as-you-go | Function logs + traces |
| Key Vault | Standard, RBAC mode | `electricitymaps-token`, `ado-pat` |
| Cosmos DB | Serverless, SQL API | 4 containers (see `docs/ARCHITECTURE.md` §1) |
| App Service Plan | `Y1` (Linux Consumption) | Function App host |
| Function App | Linux, Python 3.11 | All `/api/*` routes + 2 timer triggers |
| Static Web App | Free | Hosts the SPA |

Identity model:
- Function App has a **system-assigned managed identity**
- Identity gets `Key Vault Secrets User` on the KV (read secrets)
- Identity gets `Cosmos DB Built-in Data Contributor` on the Cosmos account
- No client secrets or connection strings are stored anywhere in the app

---

## 3 · Step-by-step deploy

### 3.1 Clone and configure parameters

```bash
git clone <this-repo>
cd "Carbon Cost Dashboard 22052026"

# Copy the example parameter file and add your tokens.
# Never commit the prod file — .gitignore already excludes *.parameters.{dev,staging,prod}.json
cp backend/infrastructure/azure/main.parameters.example.json \
   backend/infrastructure/azure/main.parameters.prod.json

# Edit main.parameters.prod.json:
#   - environment: "prod"
#   - location: "uksouth" (or your region)
#   - baseName: "greenqa" (or any short stable prefix)
#   - electricityMapsToken / adoPat: provide @secure() values via --parameters override
#     or via a Key Vault reference at deploy time.
```

### 3.2 Create the resource group

```bash
az group create \
  --name rg-green-qa-prod \
  --location uksouth
```

### 3.3 Validate before deploying

```bash
# Lint the Bicep
az bicep lint --file backend/infrastructure/azure/main.bicep

# What-if — preview the exact resources that will be created
az deployment group what-if \
  --resource-group rg-green-qa-prod \
  --template-file backend/infrastructure/azure/main.bicep \
  --parameters backend/infrastructure/azure/main.parameters.prod.json \
               electricityMapsToken="$ELECTRICITY_MAPS_TOKEN" \
               adoPat="$AZURE_DEVOPS_PAT" \
               adminObjectId="$(az ad signed-in-user show --query id -o tsv)"
```

### 3.4 Deploy infrastructure

```bash
az deployment group create \
  --resource-group rg-green-qa-prod \
  --name green-qa-deploy-$(date +%Y%m%d-%H%M%S) \
  --template-file backend/infrastructure/azure/main.bicep \
  --parameters backend/infrastructure/azure/main.parameters.prod.json \
               electricityMapsToken="$ELECTRICITY_MAPS_TOKEN" \
               adoPat="$AZURE_DEVOPS_PAT" \
               adminObjectId="$(az ad signed-in-user show --query id -o tsv)"
```

Capture the outputs — you'll need them in step 3.5:

```bash
az deployment group show \
  --resource-group rg-green-qa-prod \
  --name <deployment-name> \
  --query properties.outputs \
  --output json
# functionAppName, functionAppUrl, cosmosEndpoint, keyVaultUri, staticWebAppUrl
```

### 3.5 Deploy the Function App code

```bash
cd backend/azure/functions

# Pre-flight: verify dependencies install on the local Python 3.11.
python -m venv .venv
.venv/Scripts/activate           # PowerShell: .venv/Scripts/Activate.ps1
pip install -r requirements.txt -r requirements-dev.txt
pytest -q                        # 36 tests, ~0.5s

# Publish (uses outputs.functionAppName from the deployment).
func azure functionapp publish <functionAppName> --python
```

### 3.6 Deploy the SPA

The SPA lives at the repo root (not `dashboard/public/`). Deploy with the
SWA CLI:

```bash
# Get the SWA deployment token from the portal or:
SWA_TOKEN=$(az staticwebapp secrets list \
  --name <staticWebAppName> \
  --resource-group rg-green-qa-prod \
  --query properties.apiKey -o tsv)

# Deploy from repo root.
cd ../../..
swa deploy ./ \
  --deployment-token "$SWA_TOKEN" \
  --env production
```

`staticwebapp.config.json` at the repo root excludes `/backend/*`,
`/docs/*`, and `.remember/*` from serving.

### 3.7 Wire the SPA to the Function App URL

The SPA reads its API base from `window.GREEN_QA_API_URL`. Set this via
the Static Web App's `appsettings` (already provisioned by Bicep) or
inject it at deploy time:

```bash
az staticwebapp appsettings set \
  --name <staticWebAppName> \
  --resource-group rg-green-qa-prod \
  --setting-names GREEN_QA_API_URL="https://<functionAppName>.azurewebsites.net/api"
```

> **Important:** the SPA's API client (`apiClient.js`) and the live data
> wiring are introduced in Step 5 of `CLAUDE.md`'s refined plan. Until
> that step runs, the SPA continues to render fixtures from `data.js`
> and the live URL above is unused.

---

## 4 · Verifying a deployment

```bash
FUNC=$(az deployment group show -g rg-green-qa-prod -n <deployment-name> \
       --query properties.outputs.functionAppHostName.value -o tsv)

# Health: ensure the host is up. (No /api/health route exists today;
# /api/carbon is the cheapest read.)
curl "https://$FUNC/api/carbon?provider=azure&code=$(az functionapp keys list \
  -g rg-green-qa-prod -n <functionAppName> --query functionKeys.default -o tsv)"

# Decide: dry-run a pipeline decision.
curl -X POST "https://$FUNC/api/decide?code=$KEY" \
  -H 'Content-Type: application/json' \
  -d '{
    "pipeline_id":"azdo://contoso/qa/42",
    "run_id":"r-001",
    "current_region":"uksouth",
    "pool_mode":"self_hosted_multi_region",
    "criticality":"normal",
    "workload":{"vcpu_count":2,"memory_gb":4.0,"duration_minutes_estimate":15}
  }'
```

End-to-end probes for every route live in **Step 8** of the deployment
plan (see `CLAUDE.md`).

---

## 5 · Rollback

Function App: deployments are not slotted on the Consumption plan, so
roll back by republishing a previous git ref:

```bash
git checkout <prev-good-sha>
cd backend/azure/functions
func azure functionapp publish <functionAppName> --python
git checkout main
```

Bicep changes: re-deploy from the previous SHA's template. Resources are
declarative; the diff is what gets applied.

Cosmos DB: serverless containers do not have point-in-time restore on
this template. For a production deployment, switch to provisioned
throughput + continuous backup or add periodic backup with
`Microsoft.DocumentDB/databaseAccounts/locations/backupPolicies`.

---

## 6 · Cost (rough order of magnitude)

10 pipelines, 30-min ingestion, 5-min DEFER scan, light dashboard load:

- Cosmos DB (serverless): £4–10 / month (dominated by RU on `query_items`)
- Function App (Consumption): £0–3 / month (well within free grant)
- App Insights + Log Analytics: £5–15 / month (depends on log volume)
- Key Vault: < £1 / month (operation count is low)
- Storage Account: < £1 / month
- Static Web App: £0 (Free SKU)

**Total: ~£10–30 / month** for a single-environment prototype.

---

## 7 · Per-environment deployments

The Bicep accepts `environment` (`dev | staging | prod`). Maintain one
parameter file per environment (all are .gitignored):

```
backend/infrastructure/azure/main.parameters.dev.json
backend/infrastructure/azure/main.parameters.staging.json
backend/infrastructure/azure/main.parameters.prod.json
```

Names are suffixed with the environment + a deterministic 6-char hash of
the resource group id, so dev/staging/prod can coexist in the same
subscription as long as they live in different resource groups.
