/* eslint-env browser */
// =======================================================================
// apiClient — thin fetch wrapper for the ZeroCarb REST API (AWS: CloudFront -> API Gateway -> Lambda).
//
// Configuration (set on `window` by config.js, which the deploy generates):
//
//   window.GREEN_QA_API_URL   '/api' when served behind CloudFront (same origin), or
//                             'http://localhost:7071/api' for local development
//   window.GREEN_QA_AUTH      { region, domain, clientId } — Cognito Hosted UI (see auth.js).
//                             Absent locally, where the API runs with AUTH_MODE=disabled.
//
// If GREEN_QA_API_URL is unset or empty, every method resolves to
// { ok: false, error: 'no_api_url' } and the SPA falls back to fixtures.
//
// Every method returns a uniform Result shape:
//   { ok: true,  data: <T>, source: 'api' }
//   { ok: false, error: <string>, status?: <number>, source: 'api' }
// =======================================================================

(function () {
  'use strict';

  const DEFAULT_TIMEOUT_MS = 8000;

  function getBaseUrl() {
    const u = (window.GREEN_QA_API_URL || '').trim();
    return u.replace(/\/+$/, ''); // strip trailing slash
  }

  function isConfigured() {
    return getBaseUrl().length > 0;
  }

  function withTimeout(promise, ms) {
    if (typeof AbortController === 'undefined') return promise;
    return promise;
  }

  async function request(method, path, body) {
    if (!isConfigured()) {
      return { ok: false, error: 'no_api_url', source: 'api' };
    }
    const url = getBaseUrl() + path;
    const auth = window.greenQaAuth;
    const token = auth && auth.enabled ? await auth.getToken() : null;
    if (auth && auth.enabled && !token) {
      return { ok: false, error: 'unauthenticated', status: 401, source: 'api' };
    }
    const ctl = (typeof AbortController !== 'undefined') ? new AbortController() : null;
    const timer = ctl ? setTimeout(() => ctl.abort(), DEFAULT_TIMEOUT_MS) : null;

    try {
      const init = {
        method,
        headers: { 'Accept': 'application/json' },
        signal: ctl ? ctl.signal : undefined
      };
      if (token) init.headers['Authorization'] = 'Bearer ' + token;
      if (body !== undefined) {
        init.headers['Content-Type'] = 'application/json';
        init.body = JSON.stringify(body);
      }
      const resp = await withTimeout(fetch(url, init), DEFAULT_TIMEOUT_MS);
      const text = await resp.text();
      let data = null;
      try { data = text ? JSON.parse(text) : null; } catch (_) { /* non-JSON */ }
      if (!resp.ok) {
        return {
          ok: false,
          status: resp.status,
          error: (data && data.error) || ('HTTP ' + resp.status),
          source: 'api'
        };
      }
      return { ok: true, data, source: 'api' };
    } catch (err) {
      const reason = (err && err.name === 'AbortError') ? 'timeout' : (err && err.message) || 'network_error';
      return { ok: false, error: reason, source: 'api' };
    } finally {
      if (timer) clearTimeout(timer);
    }
  }

  // ----- Public surface --------------------------------------------------

  const api = {
    isConfigured,
    baseUrl: getBaseUrl,

    // GET /api/me -> { sub, username, roles }
    me: function () {
      return request('GET', '/me');
    },

    // GET /api/carbon?provider=azure
    carbon: function (params) {
      params = params || {};
      const qs = new URLSearchParams();
      if (params.provider) qs.set('provider', params.provider);
      const path = '/carbon' + (qs.toString() ? ('?' + qs.toString()) : '');
      return request('GET', path);
    },

    // GET /api/history?pipeline_id=...&provider=azure&limit=50
    history: function (params) {
      if (!params || !params.pipeline_id) {
        return Promise.resolve({ ok: false, error: 'pipeline_id required', source: 'api' });
      }
      const qs = new URLSearchParams();
      qs.set('pipeline_id', params.pipeline_id);
      qs.set('provider', params.provider || 'azure');
      if (params.limit) qs.set('limit', String(params.limit));
      if (params.refresh) qs.set('refresh', '1');
      return request('GET', '/history?' + qs.toString());
    },

    // POST /api/decide
    decide: function (body) {
      return request('POST', '/decide', body);
    },

    // POST /api/calculate
    calculate: function (body) {
      return request('POST', '/calculate', body);
    },

    // POST /api/budget/check
    budgetCheck: function (body) {
      return request('POST', '/budget/check', body);
    },

    // POST /api/store_result
    storeResult: function (body) {
      return request('POST', '/store_result', body);
    },

    // GET /api/overview?provider=azure&days=30
    overview: function (params) {
      params = params || {};
      const qs = new URLSearchParams();
      if (params.provider) qs.set('provider', params.provider);
      if (params.days) qs.set('days', String(params.days));
      const path = '/overview' + (qs.toString() ? ('?' + qs.toString()) : '');
      return request('GET', path);
    },

    // GET /api/forecast?region=uksouth&provider=azure
    forecast: function (params) {
      params = params || {};
      const qs = new URLSearchParams();
      qs.set('region', params.region || 'uksouth');
      qs.set('provider', params.provider || 'azure');
      return request('GET', '/forecast?' + qs.toString());
    },

    // ----- Azure DevOps connection -----

    // POST /api/ado/connect  { org_url, pat }
    adoConnect: function (body) {
      return request('POST', '/ado/connect', body || {});
    },

    // GET /api/ado/status  -> { connected, organization, org_url, ... } (never the PAT)
    adoStatus: function () {
      return request('GET', '/ado/status');
    },

    // GET /api/ado/pipelines  -> { organization, total, repos: [{ repo, project, pipelines }] }
    adoPipelines: function () {
      return request('GET', '/ado/pipelines');
    },

    // POST /api/ado/disconnect
    adoDisconnect: function () {
      return request('POST', '/ado/disconnect', {});
    },

    // POST /api/ado/run  — trigger a pipeline run + log it to Run History
    adoRun: function (body) {
      return request('POST', '/ado/run', body || {});
    },

    // ----- AWS CodePipeline connection -----

    // POST /api/aws/connect  { region, role_arn? }
    awsConnect: function (body) {
      return request('POST', '/aws/connect', body || {});
    },

    // GET /api/aws/status  -> { connected, region, role_arn, account_id, validated_at }
    awsStatus: function () {
      return request('GET', '/aws/status');
    },

    // GET /api/aws/pipelines  -> { region, total, pipelines: [{ name, region, updated_at }] }
    awsPipelines: function () {
      return request('GET', '/aws/pipelines');
    },

    // POST /api/aws/disconnect
    awsDisconnect: function () {
      return request('POST', '/aws/disconnect', {});
    }
  };

  window.greenQaApi = api;
})();
