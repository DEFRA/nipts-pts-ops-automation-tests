# Architecture

This document is the canonical description of what is *actually* deployed
in this repository. For "what we *want* to deploy" see `GAPS.md`.

## 1. Component diagram

```mermaid
flowchart LR
    subgraph "Client"
      SPA["Carbon Cost Dashboard<br/>(no-build React SPA)<br/>Carbon Cost Dashboard.html<br/>+ *.jsx via Babel Standalone"]
    end

    subgraph "Azure Static Web Apps"
      SWA["Free SKU<br/>serves SPA + staticwebapp.config.json"]
    end

    subgraph "Azure Function App (Linux Consumption, Python 3.11)"
      direction TB
      HTTP["HTTP routes /api/*<br/>decide / calculate / budget/check<br/>history / carbon / store_result<br/>ingest-ado-event"]
      T1["Timer: ingest_carbon<br/>every 30 min"]
      T2["Timer: resume_deferred<br/>every 5 min"]
    end

    subgraph "Stateful backends"
      COSMOS["Cosmos DB (Serverless, SQL API)<br/>carbon_intensity_history (pk:/region)<br/>pipeline_executions (pk:/pipeline_id)<br/>deferred_runs (pk:/pipeline_id)<br/>pipeline_analytics (pk:/pipeline_id)"]
      KV["Key Vault (RBAC mode)<br/>secrets: electricitymaps-token, ado-pat"]
      APPI["App Insights<br/>+ Log Analytics workspace"]
    end

    subgraph "External"
      EM["ElectricityMaps<br/>v3/carbon-intensity/latest"]
      ADO["Azure DevOps<br/>Pipelines REST 7.1"]
    end

    SPA -->|"window.GREEN_QA_API_URL<br/>(wired in Step 5)"| HTTP
    SWA --- SPA
    HTTP --> COSMOS
    HTTP --> KV
    T1 --> EM
    T1 --> COSMOS
    T2 --> COSMOS
    T2 --> KV
    T2 --> ADO
    HTTP --> APPI
    T1 --> APPI
    T2 --> APPI
```

## 2. Data flow — the four key paths

### 2.1 Carbon ingestion (timer, every 30 min)
`ingest_carbon` -> for each provider in `INGEST_PROVIDERS` (default `aws,azure`)
-> for each region in `green_qa_lib.providers` -> `ElectricityMapsClient.get_region_intensity(code)`
-> `CosmosDAL.upsert_carbon_sample(...)` into `carbon_intensity_history`
partitioned on `/region`.

### 2.2 Pipeline decision (HTTP, on demand)
`POST /api/decide` -> `schemas.DecideRequest.from_dict(body)` ->
`decision_service.decide(req, dal)` -> short-circuit if `resumed_decision_id`
present -> `green_qa_lib.scheduling_engine.SchedulingEngine.get_optimal_strategy(...)`
-> coerce to `RUN_NOW` if `pool_mode == ms_hosted_single_region` recommends
cross-region -> if `DEFER` or `HYBRID`, persist to `deferred_runs`.

### 2.3 Deferred resumption (timer, every 5 min)
`resume_deferred` -> `CosmosDAL.list_pending_deferred(now)` ->
`ado_client.run_pipeline(org, project, definition_id, decision_id)` -> retrieve
ADO PAT (Key Vault first, env fallback) -> POST to ADO Pipelines REST ->
`GreenQA_Resumed=true` runtime variable signals the next `/api/decide` to
short-circuit -> bump `attempts`, terminal at `DEFER_MAX_ATTEMPTS`.

### 2.4 Carbon footprint calculation (HTTP, on demand)
`POST /api/calculate` -> `schemas.CalculateRequest.from_dict(body)` ->
`green_qa_lib.sci_calculator.calculate_energy_kwh(...)` ->
`calculate_embodied_carbon(...)` -> read latest intensity for region from
Cosmos snapshot (falls back to `DEFAULT_CARBON_INTENSITY_GCO2_KWH`) ->
`calculate_sci(...)` -> return SCI + full breakdown.

## 3. HTTP API contract (current — `/api/*` not `/v1/*`)

| Method | Route | Purpose |
|---|---|---|
| POST | `/api/decide` | Carbon-aware scheduling decision for a pipeline run |
| POST | `/api/store_result` | Record the actual carbon cost of a completed run |
| POST | `/api/calculate` | Compute the SCI footprint for a hypothetical workload |
| POST | `/api/budget/check` | Compare actual gCO2 to a configured budget rule |
| GET  | `/api/history` | Paginated execution history (pipeline_id + provider) |
| GET  | `/api/carbon` | Latest carbon intensity per region for a provider |
| POST | `/api/ingest-ado-event` | Azure DevOps Service Hook receiver |

The `host.json` sets `extensions.http.routePrefix = "api"`, so HTTP triggers
are reachable at `https://<func>.azurewebsites.net/api/<route>`.

## 4. Identity & secret flow

- Function App has **System-assigned managed identity**.
- The identity is granted **Key Vault Secrets User** (RBAC) on the KV.
- The identity is granted **Cosmos DB Built-in Data Contributor** on the
  Cosmos account.
- No connection strings or client secrets are committed or stored in env vars.
- ADO PAT is fetched from KV first (`KEY_VAULT_URI` + `KV_SECRET_ADO_PAT`),
  falls back to `AZURE_DEVOPS_PAT` env if KV unset. PAT is cached for the
  lifetime of the Function host (rotation requires restart).
- App Settings referencing KV use `@Microsoft.KeyVault(...)` template syntax —
  see `ELECTRICITYMAPS_TOKEN` in `main.bicep`.

## 5. Stub vs production library

`green_qa_lib/` at the repo root is a **stub** marked `__stub__ = True`. It
satisfies every import made by the Function App so the system boots and
runs end-to-end with canned-but-plausible data. Swap-out path:

1. Delete `green_qa_lib/`.
2. Drop the upstream `green_qa_lib/` package in its place (or `pip install`
   it and remove the `sys.path` shim in `function_app.py`).
3. Re-run smoke tests — no Function App code change required.

## 6. Configuration knobs

Every tunable lives in App Settings (or `local.settings.json` for local
dev). See `backend/azure/functions/local.settings.json.example` for the
complete inventory with inline `_comment_*` group headers.

Key knobs:

| Setting | Default | Effect |
|---|---|---|
| `DEFER_MAX_ATTEMPTS` | `3` | After this many attempts, deferred runs go to `failed` |
| `MIN_SAVINGS_PERCENT` | `10` | Engine ignores shifts below this threshold |
| `ALLOW_HYBRID` | `true` | Permit space+time combined strategy |
| `DEFAULT_CARBON_INTENSITY_GCO2_KWH` | `300.0` | `/api/calculate` fallback when no live intensity |
| `INGEST_PROVIDERS` | `aws,azure` | Comma-separated list scanned every 30 min |
| `HISTORY_DEFAULT_LIMIT` / `HISTORY_MAX_LIMIT` | `50` / `500` | `/api/history` paging caps |
| `ADO_DEFAULT_BRANCH` | `refs/heads/main` | Branch passed to ADO Pipelines REST when resuming |
