# =======================================================================
# preview_pipeline.ps1 -- Server-side "compile test" for the GreenQA
# pipelines against a branch, using the ADO preview-run REST API.
#
# A preview run fully expands the YAML (extends template, parameter
# `values` allow-list, pool/demands selection) and returns the finalYaml
# WITHOUT queuing a job or needing an online agent -- ideal for testing a
# branch before raising a PR.
#
# Auth: set a PAT (scope: Build read & execute) in the session first, e.g.
#   ! $env:AZURE_DEVOPS_PAT = '<your-pat>'
# then from repo root:
#   .\scripts\preview_pipeline.ps1
#   .\scripts\preview_pipeline.ps1 -Region westeurope
#   .\scripts\preview_pipeline.ps1 -Branch attach-pipelines-sf1-pool -ShowYaml
# =======================================================================
[CmdletBinding()]
param(
    [string] $Org      = 'vibecode',
    [string] $Project  = 'GreenQA Pipelines',
    [string] $Branch   = 'attach-pipelines-sf1-pool',
    [string] $Region   = 'swedencentral',   # targetRegion to preview-route to
    [string] $Pool     = 'SF1',
    [switch] $ShowYaml                       # print the expanded finalYaml
)

$ErrorActionPreference = 'Stop'
$pat = $env:AZURE_DEVOPS_PAT
if (-not $pat) { throw "Set `$env:AZURE_DEVOPS_PAT first (Build read & execute scope)." }

$auth   = 'Basic ' + [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes(":$pat"))
$hdr    = @{ Authorization = $auth }
$orgUrl = "https://dev.azure.com/$Org"
$projEnc = [uri]::EscapeDataString($Project)

# The 5 pipeline definition names (must match the names in ADO).
$names = @(
    'billing-prod-hotfix',
    'nightly-ci-azure-fn',
    'api-tests-smoke',
    'ml-train-fraud-detection',
    'e2e-tests-ms-hosted'
)

Write-Host "Listing pipelines in '$Project'..." -ForegroundColor Cyan
$list = Invoke-RestMethod -Headers $hdr -Method GET `
    -Uri "$orgUrl/$projEnc/_apis/pipelines?api-version=7.1-preview.1"
$byName = @{}
foreach ($p in $list.value) { $byName[$p.name] = $p.id }

$fail = 0
foreach ($n in $names) {
    if (-not $byName.ContainsKey($n)) {
        Write-Host ("  SKIP  {0}: no pipeline with this name in ADO" -f $n) -ForegroundColor Yellow
        continue
    }
    $id = $byName[$n]
    # 05 is the MS-hosted lock demo -> only 'auto' is valid for it.
    $region = if ($n -eq 'e2e-tests-ms-hosted') { 'auto' } else { $Region }
    $body = @{
        previewRun         = $true
        templateParameters = @{ targetRegion = $region; agentPoolName = $Pool }
        resources          = @{ repositories = @{ self = @{ refName = "refs/heads/$Branch" } } }
    } | ConvertTo-Json -Depth 6

    $uri = "$orgUrl/$projEnc/_apis/pipelines/$id/preview?api-version=7.1-preview.1"
    try {
        $res = Invoke-RestMethod -Headers $hdr -Method POST -ContentType 'application/json' `
            -Uri $uri -Body $body
        Write-Host ("  PASS  {0} (id {1}) compiled with targetRegion={2}" -f $n, $id, $region) -ForegroundColor Green
        if ($ShowYaml) { "----- finalYaml -----"; $res.finalYaml; "---------------------" }
    }
    catch {
        $fail++
        $msg = $_.ErrorDetails.Message
        if (-not $msg) { $msg = $_.Exception.Message }
        Write-Host ("  FAIL  {0} (id {1}): {2}" -f $n, $id, $msg) -ForegroundColor Red
    }
}

if ($fail) { Write-Host "`n$fail pipeline(s) failed to compile." -ForegroundColor Red; exit 1 }
Write-Host "`nAll pipelines compiled against branch '$Branch'." -ForegroundColor Green
