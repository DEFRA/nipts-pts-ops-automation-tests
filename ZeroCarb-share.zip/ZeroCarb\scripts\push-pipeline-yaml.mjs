#!/usr/bin/env node
// Push the GreenQA region-routing change to a branch and open a PR in Azure DevOps.
// Deliberately does NOT push to main: both definitions have `trigger: main`, so a direct push would fire
// two unrequested CI runs on the trunk. Prints no secrets.
//
//   AZURE_DEVOPS_PAT=... [ADO_ORG_URL=... ADO_PROJECT=...] node scripts/push-pipeline-yaml.mjs
const PAT = process.env.AZURE_DEVOPS_PAT;
if (!PAT) { console.error('Set AZURE_DEVOPS_PAT (Code read & write, Pull Request contribute).'); process.exit(2); }

const orgUrl = (process.env.ADO_ORG_URL ?? 'https://dev.azure.com/defragovuk').replace(/\/+$/, '');
const org = /dev\.azure\.com\/([^/]+)/i.exec(orgUrl)?.[1] ?? orgUrl;
const project = encodeURIComponent(process.env.ADO_PROJECT ?? 'CCTS QAT');
const REPO = process.env.ADO_REPO ?? 'Greendashboard';
const BRANCH = 'greenqa/region-routing';
const BASE = `https://dev.azure.com/${org}/${project}/_apis/git/repositories/${REPO}`;
const AUTH = Buffer.from(`:${PAT}`).toString('base64');

const GATE_STEP = `- bash: |
    echo "GreenQA target region: \${{ parameters.targetRegion }}"
    echo "Running on agent     : $(Agent.Name)"
    echo "##vso[build.addbuildtag]region-\${{ parameters.targetRegion }}"
  displayName: 'GreenQA: record target region'

`;

const PARAMS_BLOCK = `# Set at queue time by the Carbon Cost Dashboard so a run can be pinned to a
# region. Declaring it is required: Azure DevOps rejects templateParameters it
# does not recognise with HTTP 400.
parameters:
  - name: targetRegion
    type: string
    default: uksouth
    values:
      - uksouth
      - ukwest

`;

async function request(method, url, payload) {
  const res = await fetch(url, {
    method,
    headers: { Authorization: `Basic ${AUTH}`, Accept: 'application/json', 'Content-Type': 'application/json' },
    body: payload === undefined ? undefined : JSON.stringify(payload),
    signal: AbortSignal.timeout(60_000),
  });
  const text = await res.text();
  if (!res.ok) throw Object.assign(new Error(`HTTP ${res.status}`), { status: res.status, body: text });
  return text ? JSON.parse(text) : {};
}

/** Insert the parameters block before `trigger:` and the gate step first. */
function transform(text) {
  if (text.includes('targetRegion')) return text; // already applied
  const out = text.replace('trigger:\n', `${PARAMS_BLOCK}trigger:\n`);
  const marker = 'steps:\n';
  const idx = out.indexOf(marker) + marker.length;
  return out.slice(0, idx) + GATE_STEP + out.slice(idx);
}

const mainSha = (await request('GET', `${BASE}/refs?filter=heads/main&api-version=7.1`)).value[0].objectId;
console.log(`main @ ${mainSha.slice(0, 8)}`);

let existing = [];
try {
  existing = (await request('GET', `${BASE}/refs?filter=heads/${BRANCH}&api-version=7.1`)).value;
} catch { /* branch lookup failed: treat as absent */ }

let baseSha;
if (existing.length) {
  baseSha = existing[0].objectId;
  console.log(`branch ${BRANCH} exists @ ${baseSha.slice(0, 8)}`);
} else {
  await request('POST', `${BASE}/refs?api-version=7.1`, [{ name: `refs/heads/${BRANCH}`, oldObjectId: '0'.repeat(40), newObjectId: mainSha }]);
  baseSha = mainSha;
  console.log(`created branch ${BRANCH} from main`);
}

const changes = [];
for (const name of ['azure-pipelines.yml', 'azure-pipelines-1.yml']) {
  const url = `${BASE}/items?path=/${name}&api-version=7.1&includeContent=true&versionDescriptor.version=main&versionDescriptor.versionType=branch`;
  const current = (await request('GET', url)).content;
  const updated = transform(current);
  if (updated === current) { console.log(`  ${name}: already has targetRegion, skipping`); continue; }
  changes.push({ changeType: 'edit', item: { path: `/${name}` }, newContent: { content: updated, contentType: 'rawtext' } });
  console.log(`  ${name}: +${updated.length - current.length} chars`);
}

if (!changes.length) { console.log('nothing to push'); process.exit(0); }

const push = await request('POST', `${BASE}/pushes?api-version=7.1`, {
  refUpdates: [{ name: `refs/heads/${BRANCH}`, oldObjectId: baseSha }],
  commits: [{ comment: 'GreenQA: declare targetRegion parameter for carbon-aware region routing', changes }],
});
console.log(`pushed commit ${push.commits[0].commitId.slice(0, 8)} to ${BRANCH}`);

try {
  const pr = await request('POST', `${BASE}/pullrequests?api-version=7.1`, {
    sourceRefName: `refs/heads/${BRANCH}`,
    targetRefName: 'refs/heads/main',
    title: 'GreenQA: declare targetRegion parameter for carbon-aware region routing',
    description:
      'Adds a `targetRegion` template parameter (uksouth | ukwest) to both QA pipelines, plus a step that logs the region ' +
      'and adds a `region-<x>` build tag.\n\nRequired because the Carbon Cost Dashboard posts `templateParameters.targetRegion` ' +
      'when triggering a run, and Azure DevOps rejects undeclared parameters with HTTP 400.\n\nThe `pool:` is unchanged, so runs ' +
      'still execute on Microsoft-hosted agents. Switching to `pool: name: agents-$(targetRegion)` is a follow-up, once the ' +
      'regional self-hosted pools exist.',
  });
  console.log(`PR !${pr.pullRequestId}: https://dev.azure.com/${org}/${project}/_git/${REPO}/pullrequest/${pr.pullRequestId}`);
} catch (e) {
  console.log(`PR creation failed: HTTP ${e.status} ${String(e.body).slice(0, 300)}`);
  console.log(`Branch ${BRANCH} is pushed; open the PR manually.`);
}
