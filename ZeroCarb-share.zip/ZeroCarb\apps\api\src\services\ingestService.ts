import { envBool, envInt, envStr, settings } from '../config';
import { getRegionIntensityClient, type IntensityReading } from '../domain/carbonApi';
import { PUE_VALUES } from '../domain/constants';
import * as energyCharts from '../domain/energyCharts';
import { getProvider } from '../domain/providers';
import { round } from '../domain/sci';
import { getSecretStore } from '../lib/secrets';
import { logger } from '../logger';
import type { Repository } from '../repo/types';

const CONCURRENCY = 4;

/**
 * Energy-Charts is limited to 2 req/min, so supported regions are refreshed in a rotating window
 * (one slot per 30 min); every region is refreshed roughly every 75 minutes.
 */
export function energyChartsBatch(now = Date.now()): Set<string> {
  if (!envBool('ENERGY_CHARTS_USE_LIVE')) return new Set();
  const regions = Object.keys(energyCharts.REGION_COUNTRY_MAP).sort();
  if (!regions.length) return new Set();
  const size = Math.max(1, envInt('ENERGY_CHARTS_BATCH_SIZE', 4));
  const slot = Math.floor(now / 1000 / 1800);
  const start = (slot * size) % regions.length;
  return new Set(Array.from({ length: Math.min(size, regions.length) }, (_, i) => regions[(start + i) % regions.length]));
}

async function energyChartsReading(regionCode: string, providerName: string): Promise<[IntensityReading | null, string]> {
  try {
    const [reading, source] = await energyCharts.getRegionIntensity(regionCode);
    if (!reading) return [null, source];
    const pue = PUE_VALUES[providerName] ?? settings.defaultPue();
    return [{
      grid_intensity: reading.grid_intensity,
      carbon_intensity: round(reading.grid_intensity * pue, 3),
      renewable_percentage: reading.renewable_percentage,
      zone: reading.country.toUpperCase(),
      aws_pue: pue,
    }, source];
  } catch (err) {
    logger.error({ err, regionCode }, 'ingest_carbon: energy_charts failed');
    return [null, 'energy_charts_error'];
  }
}

async function mapLimit<T>(items: T[], limit: number, fn: (item: T) => Promise<void>): Promise<void> {
  let next = 0;
  await Promise.all(Array.from({ length: Math.min(limit, items.length) }, async () => {
    while (next < items.length) await fn(items[next++]);
  }));
}

/** Upserts one carbon sample per region per provider. Returns the number stored. */
export async function ingestCarbonOnce(repo: Repository): Promise<number> {
  let inserted = 0;
  const sampleTs = new Date().toISOString();
  const emToken = (await getSecretStore().get('electricitymaps_token')) ?? envStr('ELECTRICITYMAPS_TOKEN');
  const ecBatch = energyChartsBatch();

  for (const providerName of settings.ingestProviders()) {
    try {
      const provider = getProvider(providerName);
      await mapLimit(provider.listRegions(), CONCURRENCY, async (region) => {
        let data: IntensityReading | null = null;
        let source = '';

        if (ecBatch.has(region.code)) [data, source] = await energyChartsReading(region.code, providerName);

        if (data === null) {
          try {
            [data, source] = await getRegionIntensityClient(region.code, { token: emToken, provider: providerName }).getRegionIntensity(region.code);
          } catch (err) {
            logger.error({ err, providerName, region: region.code }, 'ingest_carbon: failed');
            return;
          }
        }
        if (!data) {
          logger.info({ providerName, region: region.code, source }, 'ingest_carbon: no data');
          return;
        }
        await repo.upsertCarbonSample({
          id: `${providerName}::${region.code}::${sampleTs}`,
          provider: providerName,
          region: region.code,
          grid_intensity_gco2_kwh: data.grid_intensity,
          dc_intensity_gco2_kwh: data.carbon_intensity,
          renewable_pct: data.renewable_percentage,
          zone: data.zone,
          pue: data.aws_pue,
          sampled_at: sampleTs,
          source,
        });
        inserted += 1;
      });
    } catch (err) {
      logger.error({ err, providerName }, 'ingest_carbon: provider loop failed');
    }
  }
  return inserted;
}
