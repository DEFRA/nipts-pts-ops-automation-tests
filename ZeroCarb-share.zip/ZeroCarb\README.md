# Carbon Cost Dashboard / Green QA

GreenOps for CI/CD. Every pipeline run is costed in grams of CO₂ using
the GSF SCI formula. Builds that exceed budget fail at the gate, the
same way a failing test or SLO breach would.

## What's in this repo

```
.
├── Carbon Cost Dashboard.html       # SPA entry — open in a browser
├── *.jsx, data.js, styles.css       # No-build React SPA (Babel Standalone)
├── backend/
│   ├── azure/functions/             # Python v2 Functions: /api/* + 2 timers
│   └── infrastructure/azure/        # main.bicep (single-file IaC)
├── green_qa_lib/                    # STUB of the upstream scheduling lib
├── tests/                           # pytest smoke + contract tests
├── docs/
│   ├── ARCHITECTURE.md              # ★ canonical component diagram
│   ├── DATA_SOURCES.md, EXTERNAL_APIS.md, INFRASTRUCTURE.md, ...
├── DEPLOYMENT.md                    # ★ how to deploy
├── OPERATIONS.md                    # ★ how to run it
├── GAPS.md                          # what's mocked + roadmap to production
└── CLAUDE.md                        # repo orientation for Claude Code
```

The three documents marked ★ are the authoritative ones. Older
references to `/v1/*`, `make deploy`, Front Door, or a `dashboard/public/`
directory describe a future state — see GAPS.md.

## Quick start

### Browse the SPA locally

Open `Carbon Cost Dashboard.html` in any modern browser. There is no
build step. React, ReactDOM, and Babel Standalone load from unpkg with
SRI integrity hashes; the `.jsx` files transpile in the browser.

By default the SPA renders from `data.js` fixtures. To point it at a
running backend (locally or in Azure), set two globals **before** the
SPA's scripts run — either by editing the HTML temporarily, or via
DevTools console + reload, or by injecting them at deploy time via
Azure Static Web Apps appsettings (see `DEPLOYMENT.md` §3.7):

```html
<script>
  window.GREEN_QA_API_URL = 'https://<func>.azurewebsites.net/api';
  window.GREEN_QA_FUNCTION_KEY = '<host-key>';  // host.json AuthLevel=FUNCTION
</script>
```

When the Regions tab loads, the SPA calls `GET /api/carbon` and flips
the masthead badge from `PREVIEW · FIXTURE DATA` to `LIVE DATA`. On any
fetch failure it transparently falls back to fixtures so offline demos
still work.

### Run the backend locally

```bash
cd backend/azure/functions
cp local.settings.json.example local.settings.json
# Edit local.settings.json — leave COSMOS_ENDPOINT blank to use the
# in-memory DAL for stand-alone probing.

python -m venv .venv
.venv/Scripts/activate      # PowerShell: .venv/Scripts/Activate.ps1
pip install -r requirements.txt -r requirements-dev.txt
pytest -q                   # 36 tests, ~0.5s

func start                  # http://localhost:7071/api/...
```

### Deploy to Azure

See `DEPLOYMENT.md` for the full procedure (Bicep what-if → deploy → publish).

## API at a glance

| Route | Purpose |
|---|---|
| `POST /api/decide` | Carbon-aware scheduling decision |
| `POST /api/calculate` | SCI footprint for a workload |
| `POST /api/budget/check` | Compare actual gCO2 to a budget |
| `POST /api/store_result` | Persist actual carbon cost of a run |
| `GET  /api/history` | Paginated execution history |
| `GET  /api/carbon` | Region catalogue + latest intensity |
| `POST /api/ingest-ado-event` | ADO Service Hook receiver |

Plus two timers: `ingest_carbon` (30 min) and `resume_deferred` (5 min).

## Architecture (TL;DR)

`SPA → Function App (/api/*) → Cosmos DB + Key Vault + ElectricityMaps + ADO`
plus App Insights everywhere. See `docs/ARCHITECTURE.md` for the diagram.

## License

(Internal — Cognizant Green QA Platform.)
