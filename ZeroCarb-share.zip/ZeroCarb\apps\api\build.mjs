// Bundles the API for Lambda (dist/lambda.mjs, dist/scheduler.mjs) and containers/local (dist/server.mjs).
import { build } from 'esbuild';

const common = {
  bundle: true,
  platform: 'node',
  target: 'node22',
  format: 'esm',
  outdir: 'dist',
  outExtension: { '.js': '.mjs' },
  sourcemap: true,
  minify: false,
  legalComments: 'none',
  // CJS deps (express etc.) need require() inside an ESM bundle.
  banner: { js: "import { createRequire as __cr } from 'node:module'; const require = __cr(import.meta.url);" },
  logLevel: 'info',
};

await build({
  ...common,
  entryPoints: {
    server: 'src/server.ts',
    lambda: 'src/handlers/api.ts',
    scheduler: 'src/handlers/scheduler.ts',
  },
  // Lambda's runtime provides AWS SDK v3; containers bundle it (BUNDLE_AWS_SDK=1) so the image needs no node_modules.
  external: process.env.BUNDLE_AWS_SDK ? [] : ['@aws-sdk/*'],
});
