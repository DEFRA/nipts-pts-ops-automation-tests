#!/usr/bin/env node
// One-command deploy: node scripts/deploy.mjs <dev|uat|prod> [--require-approval never] [--version <tag>]
// Runs tests, stages the SPA, then `cdk deploy` for the three stacks of the chosen environment.
import { spawnSync } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const [envName, ...rest] = process.argv.slice(2);
if (!['dev', 'uat', 'prod'].includes(envName ?? '')) {
  console.error('Usage: node scripts/deploy.mjs <dev|uat|prod> [--require-approval never] [--version <tag>]');
  process.exit(2);
}
const flag = (name, fallback) => { const i = rest.indexOf(name); return i >= 0 ? rest[i + 1] : fallback; };
const approval = flag('--require-approval', envName === 'prod' ? 'broadening' : 'never');
const version = flag('--version', new Date().toISOString().replace(/[-:T]/g, '').slice(0, 14));

if (!process.env.CDK_DEFAULT_ACCOUNT && !process.env.AWS_ACCOUNT_ID) {
  console.error('Set CDK_DEFAULT_ACCOUNT (or AWS_ACCOUNT_ID) and AWS credentials first.');
  process.exit(2);
}

function run(cmd, args, cwd = root) {
  console.log(`\n$ ${cmd} ${args.join(' ')}`);
  const r = spawnSync(cmd, args, { cwd, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) process.exit(r.status ?? 1);
}

run('npm', ['run', 'typecheck']);
run('npm', ['test']);
run('npm', ['run', 'build:web']);
run('npx', ['cdk', 'deploy', '--all', '-c', `env=${envName}`, '-c', `version=${version}`, '--require-approval', approval, '--outputs-file', `cdk-outputs-${envName}.json`], resolve(root, 'infra'));
console.log(`\nDeployed ${envName} (version ${version}). Stack outputs: infra/cdk-outputs-${envName}.json`);
