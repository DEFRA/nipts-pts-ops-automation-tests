/* global React */
// =======================================================================
// Glossary — plain-English definitions for every term used in the
// Carbon Cost Dashboard. Written for a layman: a product owner, business
// stakeholder or new engineer onboarding to the platform.
//
// Each entry has:
//   - term:        the bit of jargon
//   - shortDef:    one-line definition
//   - explainer:   2–4 sentence plain-English unpack
//   - example:     a concrete worked example
//   - relatedIds:  cross-links to other terms
// =======================================================================

const GLOSSARY = [
  // ----- Section: Carbon basics -----
  {
    section: 'Carbon basics',
    items: [
      {
        id: 'gco2',
        term: 'gCO₂ / g CO₂',
        shortDef: 'Grams of carbon-dioxide-equivalent. The unit we report emissions in.',
        explainer: 'Carbon emissions are usually quoted in grams (g) or kilograms (kg) of CO₂. The little "₂" just means "two oxygens" — CO₂ is one of several greenhouse gases, and we convert other gases (like methane) into "equivalent CO₂" so everything can be added up on one scale.',
        example: 'A single run of the auth-service-ci pipeline produces about 8.4 g CO₂ — roughly the same as charging your phone once.'
      },
      {
        id: 'intensity',
        term: 'Carbon intensity (gCO₂ / kWh)',
        shortDef: 'How dirty each unit of electricity is on a given grid, right now.',
        explainer: 'The electricity grid in Sweden is fed mostly by hydro and nuclear, so each kilowatt-hour (kWh) carries about 19 g of CO₂. The Polish grid leans on coal — each kWh carries about 678 g. Same amount of electricity, very different climate cost. Intensity changes minute-by-minute as different power stations come on and off.',
        example: 'If your pipeline uses 1 kWh of electricity running in Stockholm, it emits ~19 g CO₂. The same job in Warsaw emits ~678 g — 36× worse.',
        relatedIds: ['region', 'scheduler']
      },
      {
        id: 'sci',
        term: 'SCI — Software Carbon Intensity',
        shortDef: 'The industry-standard formula for working out a piece of software\'s carbon footprint.',
        explainer: 'SCI = (E × I) + M. E is the energy your code uses (kWh). I is the carbon intensity of the grid (gCO₂ / kWh). M is the embodied carbon — the manufacturing emissions of the hardware, amortised over its lifetime. Published by the Green Software Foundation; the basis for everything on this dashboard.',
        example: 'A 22-minute pipeline run on 8 vCPU uses ~0.07 kWh. In UK South (164 gCO₂/kWh) that\'s 11.5 g operational + 2 g embodied ≈ 13.5 g total per run.',
        relatedIds: ['intensity', 'embodied', 'operational']
      },
      {
        id: 'operational',
        term: 'Operational carbon',
        shortDef: 'Emissions from running your code — the electricity it consumes right now.',
        explainer: 'About 85% of a typical CI/CD pipeline\'s carbon. Driven by how long the job runs, how many cores it uses, and how clean the grid is in that moment.',
        example: 'A 30-minute test suite on 4 vCPU draws ~0.04 kWh — multiply by grid intensity to get gCO₂.'
      },
      {
        id: 'embodied',
        term: 'Embodied carbon (M)',
        shortDef: 'The manufacturing emissions of the servers, baked in and amortised per run.',
        explainer: 'Making a server creates CO₂ before you ever switch it on — mining metals, casting chips, shipping it to the data centre. We spread that one-off cost across every job the server will ever run. Typically ~15% of pipeline carbon.',
        example: 'A typical cloud server has ~1,200 kg embodied CO₂ and runs ~30,000 jobs across its life — ~40 g per job baked in.'
      },
      {
        id: 'pue',
        term: 'PUE — Power Usage Effectiveness',
        shortDef: 'How much extra power a data centre uses for cooling and lights, on top of the servers.',
        explainer: 'PUE 1.0 = perfectly efficient (every watt goes to compute). PUE 2.0 = doubled (half goes to cooling/etc). Azure averages around 1.185 today, so we multiply raw compute energy by 1.185 when computing emissions.',
        example: 'If your pipeline\'s servers use 1 kWh, the whole data centre actually drew ~1.185 kWh to keep them running.'
      }
    ]
  },

  // ----- Section: Scheduling & routing -----
  {
    section: 'Scheduling & routing',
    items: [
      {
        id: 'scheduler',
        term: 'Carbon-aware scheduler',
        shortDef: 'The decision framework we use to pick when and where each pipeline should run.',
        explainer: 'A four-step decision tree that chooses between RUN_NOW, TIME_SHIFT, SPACE_SHIFT, and HYBRID — see those terms below.',
        relatedIds: ['runnow','timeshift','spaceshift','hybrid']
      },
      {
        id: 'runnow',
        term: 'RUN_NOW',
        shortDef: 'Run immediately, in the current region. No carbon optimisation applied.',
        explainer: 'Used for time-critical jobs (production deploys, hot-fix releases) where you can\'t afford to wait or move, even at the cost of a few extra grams of CO₂.',
        relatedIds: ['scheduler']
      },
      {
        id: 'timeshift',
        term: 'TIME_SHIFT (deferring)',
        shortDef: 'Wait until the grid in this region gets cleaner, then run.',
        explainer: 'Grid intensity changes hour-to-hour as wind picks up, solar peaks, or coal plants shut down for the night. If a job isn\'t urgent, we delay it (typically up to 4 h) for a low-carbon window.',
        example: 'A non-urgent search-indexer job, deferred from 11:00 to 15:30, can save 30–60% of its carbon — same region, just cleaner power.'
      },
      {
        id: 'spaceshift',
        term: 'SPACE_SHIFT (re-routing)',
        shortDef: 'Run the job in a different, cleaner Azure region.',
        explainer: 'Sweden Central and France Central are far cleaner than Germany or Poland. For jobs that don\'t care about data residency we route them to a cleaner region. Latency and egress costs are checked first.',
        example: 'Moving payment-gateway-ci from UK South (164 g/kWh) to France Central (56 g/kWh) cuts per-run carbon by ~66%.'
      },
      {
        id: 'hybrid',
        term: 'HYBRID',
        shortDef: 'Both time-shift AND space-shift — defer the job, then run it in a cleaner region.',
        explainer: 'The best outcome when neither option alone is enough. Used sparingly because it changes both the schedule and the location.',
        example: '"Wait 2 h then run in Sweden Central" — combined ~91% carbon saving over the naive RUN_NOW baseline.'
      },
      {
        id: 'gate',
        term: 'Carbon gate',
        shortDef: 'The CI/CD check that fails a build whose emissions exceed its budget.',
        explainer: 'Works exactly like a failing unit test or a missed SLO: if a pipeline emits more than its allowed gCO₂, the build fails and the engineer must fix it or file an override with a justification.',
        relatedIds: ['budget', 'override']
      },
      {
        id: 'budget',
        term: 'Carbon budget',
        shortDef: 'A per-pipeline ceiling on grams of CO₂ per run.',
        explainer: 'Set by the team that owns the pipeline. Default budgets come from baseline measurements — usually the 75th-percentile run from the past 30 days. The gate uses this number to decide pass/warn/fail.'
      },
      {
        id: 'override',
        term: 'Budget override',
        shortDef: 'A reasoned exception that lets a build pass despite blowing its budget.',
        explainer: 'Engineers can override the gate when business need outweighs the carbon cost (revenue-critical deploy, customer escalation, etc.). All overrides are logged with reason, requester and expiry, and surface in the monthly carbon report.'
      }
    ]
  },

  // ----- Section: Cloud & deployment -----
  {
    section: 'Cloud & deployment',
    items: [
      {
        id: 'region',
        term: 'Azure region',
        shortDef: 'A specific geographic data-centre location (UK South, North Europe, etc.).',
        explainer: 'Each Azure region maps to one or more physical data centres in a country. The grid powering those data centres has its own carbon intensity — that\'s why region choice matters so much.'
      },
      {
        id: 'pipeline',
        term: 'Pipeline (CI/CD)',
        shortDef: 'An automated workflow that builds, tests and deploys a service.',
        explainer: 'When you push code to a repo, a pipeline runs to check it works and ship it. Each run consumes electricity — most of the carbon this dashboard tracks.'
      },
      {
        id: 'sp',
        term: 'Service principal',
        shortDef: 'A robot identity that Azure uses for automated logins — never a person\'s password.',
        explainer: 'The dashboard talks to your Azure subscription through a service principal with Reader-level permissions. It can see pipelines and telemetry but can\'t change anything destructive.'
      },
      {
        id: 'rbac',
        term: 'RBAC — Role-Based Access Control',
        shortDef: 'Who can do what, scoped to an Azure resource.',
        explainer: 'We enforce least-privilege: the dashboard\'s service principal gets only the Reader role, not Contributor. Function App talks to Cosmos via managed identity. No long-lived secrets.'
      },
      {
        id: 'bicep',
        term: 'Bicep',
        shortDef: 'Microsoft\'s infrastructure-as-code language for Azure (replaces raw ARM JSON).',
        explainer: 'Our entire Azure footprint — Cosmos DB, Function App, Static Web App, Key Vault, App Insights, Storage — is described in one Bicep file. Deploying the whole stack is a single `az deployment` command.'
      },
      {
        id: 'kv',
        term: 'Key Vault',
        shortDef: 'Azure\'s secrets locker — passwords, API keys, tokens.',
        explainer: 'No secret is ever stored in code or in the browser. They live in Key Vault and the Function App fetches them via its managed identity. Rotation is automated where possible.'
      }
    ]
  },

  // ----- Section: Data sources & research -----
  {
    section: 'Data sources & research',
    items: [
      {
        id: 'eso',
        term: 'NESO (UK Grid ESO)',
        shortDef: 'The National Energy System Operator — runs Britain\'s electricity grid.',
        explainer: 'Their free `carbonintensity.org.uk` API gives the real-time gCO₂/kWh for every GB region. We use it as the authoritative source for UK pipelines.'
      },
      {
        id: 'electricitymaps',
        term: 'ElectricityMaps',
        shortDef: 'A paid API covering ~250 grid zones worldwide with live carbon intensity.',
        explainer: 'Covers EU regions and most of the world. Used for non-UK pipelines. Free tier exists; we sit on the commercial tier for production reliability.'
      },
      {
        id: 'ember',
        term: 'Ember Climate',
        shortDef: 'A think tank publishing open electricity-mix data — used as a fallback.',
        explainer: 'If ElectricityMaps is degraded, we fall back to Ember\'s slower-moving averages. Less precise but always available.'
      },
      {
        id: 'researchwatcher',
        term: 'Research watcher',
        shortDef: 'Background job that scans EU/UK government sources for new sustainability publications.',
        explainer: 'No broad crawling — only a curated allow-list of audited gov.uk, defra, JRC, EEA, etc. Documents pass a keyword filter before being downloaded. Operators must accept each finding before anything is stored.'
      },
      {
        id: 'alignment',
        term: 'Alignment check',
        shortDef: 'A diff between a new research document and what our utility actually does.',
        explainer: 'When you accept a research finding, we compare it against the live code. Results are three lists: aligned (matches what we do), gaps (we should add), suggestions (nice-to-have). Nothing in code is changed — gaps and suggestions become draft issues for human review.'
      },
      {
        id: 'draftissue',
        term: 'Draft issue',
        shortDef: 'A proposed improvement to the utility, captured from a research alignment.',
        explainer: 'Drafts live in this dashboard\'s local store until you act on them. You can push them to GitHub (when storage is configured as GitHub) where engineering will triage, assign and merge in the usual review process.'
      }
    ]
  },

  // ----- Section: Reporting & compliance -----
  {
    section: 'Reporting & compliance',
    items: [
      {
        id: 'scope3',
        term: 'Scope 3',
        shortDef: 'Indirect emissions from your supply chain — including cloud compute.',
        explainer: 'The carbon emitted by software running on someone else\'s servers is your Scope 3 emissions. CSRD (the EU\'s sustainability reporting directive) requires large companies to disclose Scope 3.'
      },
      {
        id: 'csrd',
        term: 'CSRD / ESRS E1',
        shortDef: 'The EU\'s 2024 Corporate Sustainability Reporting Directive — mandatory climate disclosure.',
        explainer: 'Large EU-listed companies must publish audited Scope 1, 2 and 3 emissions. The dashboard\'s ledger and per-pipeline ledger are designed to feed straight into CSRD-compatible reports.'
      },
      {
        id: 'gsf',
        term: 'GSF — Green Software Foundation',
        shortDef: 'Non-profit defining the standards we follow (SCI, SCI-D, software carbon practice).',
        explainer: 'Open membership across Microsoft, Google, Accenture, Cognizant and others. Their specifications are the basis of how we calculate carbon.'
      }
    ]
  }
];

// ----- index of all term IDs for quick lookup / cross-links -----
const GLOSSARY_INDEX = (() => {
  const idx = {};
  GLOSSARY.forEach(s => s.items.forEach(it => { idx[it.id] = it; }));
  return idx;
})();

// =======================================================================
// GlossaryPanel — the tab content
// =======================================================================
function GlossaryPanel() {
  const [query, setQuery] = React.useState('');
  const q = query.trim().toLowerCase();

  // Sort sections alphabetically; sort items alphabetically by term.
  // Stable, case-insensitive collation.
  const sorted = React.useMemo(() => {
    const collator = new Intl.Collator('en-GB', { sensitivity: 'base', numeric: false });
    return GLOSSARY
      .map(s => ({
        ...s,
        items: [...s.items].sort((a, b) => collator.compare(a.term, b.term))
      }))
      .sort((a, b) => collator.compare(a.section, b.section));
  }, []);

  // Filter by query
  const filtered = sorted.map(s => ({
    ...s,
    items: s.items.filter(it =>
      !q ||
      it.term.toLowerCase().includes(q) ||
      it.shortDef.toLowerCase().includes(q) ||
      it.explainer.toLowerCase().includes(q)
    )
  })).filter(s => s.items.length > 0);

  const totalTerms = GLOSSARY.reduce((n, s) => n + s.items.length, 0);
  const shownTerms = filtered.reduce((n, s) => n + s.items.length, 0);

  const PageHeader = window.Atoms && window.Atoms.PageHeader;

  return (
    <section aria-label="Glossary">
      <PageHeader
        title="Glossary"
        subtitle="Plain-English definitions for every term used in the dashboard."
        actions={
          <label className="inline-select">
            <span className="visually-hidden">Search glossary</span>
            <input
              type="search"
              className="form-field"
              placeholder={'Search'}
              value={query}
              onChange={e => setQuery(e.target.value)}
              style={{ width: 240 }}
              aria-label="Search glossary"
            />
          </label>
        }
      />
      {q && (
        <p className="kpi-strip-meta" aria-live="polite">{shownTerms} of {totalTerms} terms match.</p>
      )}

      {filtered.length === 0 && (
        <p className="glossary-empty" role="status">
          No glossary terms match &quot;<strong>{query}</strong>&quot;.{' '}
          <button type="button" className="research-link" onClick={() => setQuery('')}>Clear search</button>
        </p>
      )}

      {filtered.map(s => (
        <details
          key={s.section}
          className="glossary-section"
          id={'sec-' + s.section.replace(/[^a-z0-9]/gi, '-').toLowerCase()}
          open={!!q}
        >
          <summary className="glossary-section-summary">
            <span className="glossary-section-title">{toTitleCase(s.section)}</span>
          </summary>
          <ul className="glossary-list" role="list">
            {s.items.map(it => (
              <GlossaryEntry key={it.id} item={it} />
            ))}
          </ul>
        </details>
      ))}
    </section>
  );
}

// =======================================================================
// Glossary entry — stylish list item, click row to expand inline.
// Layout: term (left, bold) · short def (middle, muted) · chevron (right).
// Open state reveals explainer + example + cross-links indented underneath.
// =======================================================================
function GlossaryEntry({ item }) {
  const [open, setOpen] = React.useState(false);
  return (
    <li
      id={'term-' + item.id}
      className={'glossary-item' + (open ? ' open' : '')}
    >
      <button
        type="button"
        className="glossary-item-head"
        aria-expanded={open}
        onClick={() => setOpen(o => !o)}
      >
        <span className="glossary-item-term">{item.term}</span>
        <span className="glossary-item-short">{item.shortDef}</span>
        <span className="glossary-item-chev" aria-hidden="true">›</span>
      </button>
      {open && (
        <div className="glossary-item-body">
          <p className="glossary-item-explainer">{item.explainer}</p>
          {item.example && (
            <p className="glossary-item-example">
              <strong>Example </strong>{item.example}
            </p>
          )}
          {item.relatedIds && item.relatedIds.length > 0 && (
            <p className="glossary-item-related">
              <span className="muted">See also: </span>
              {item.relatedIds.map((rid, i) => {
                const rel = GLOSSARY_INDEX[rid];
                if (!rel) return null;
                return (
                  <React.Fragment key={rid}>
                    {i > 0 && ', '}
                    <a href={'#term-' + rid} onClick={(e) => {
                      e.preventDefault();
                      const el = document.getElementById('term-' + rid);
                      if (el) {
                        const r = el.getBoundingClientRect();
                        window.scrollTo({ top: window.scrollY + r.top - 120, behavior: 'smooth' });
                      }
                    }}>{rel.term}</a>
                  </React.Fragment>
                );
              })}
            </p>
          )}
        </div>
      )}
    </li>
  );
}

// Title Case for section headings (e.g. "Cloud & deployment" → "Cloud & Deployment").
// Tiny words like "and / & / of" stay lowercase, unless they're the first word.
function toTitleCase(str) {
  const small = new Set(['and', 'or', 'of', 'the', 'a', 'an', 'in', 'to', 'for', 'on', 'at', 'by', '&']);
  return str.split(/(\s+|&)/).map((w, i) => {
    if (!w.trim()) return w;
    if (i > 0 && small.has(w.toLowerCase())) return w.toLowerCase();
    return w.charAt(0).toUpperCase() + w.slice(1).toLowerCase();
  }).join('');
}

// =======================================================================
// (Legacy) Card for a single term — kept temporarily for safety, unused.
// =======================================================================
function GlossaryCard({ item }) {
  const [open, setOpen] = React.useState(false);
  return (
    <article
      style={{
        border: '1px solid var(--gov-border)',
        background: '#fff',
        padding: 'var(--s-3) var(--s-4)',
        display: 'flex', flexDirection: 'column', gap: 'var(--s-2)'
      }}>
      <header style={{ display: 'flex', alignItems: 'baseline', gap: 'var(--s-2)', justifyContent: 'space-between' }}>
        <h4 style={{ margin: 0, fontSize: 'var(--t-18)', fontWeight: 700 }}>{item.term}</h4>
        <span className="muted" style={{ fontSize: 'var(--t-12)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>#{item.id}</span>
      </header>
      <p style={{ margin: 0, fontWeight: 600, fontSize: 'var(--t-16)' }}>{item.shortDef}</p>
      <p style={{ margin: 0, color: 'var(--gov-text-muted)', lineHeight: 1.5, fontSize: 'var(--t-14)' }}>{item.explainer}</p>
      {item.example && (
        <div style={{
          padding: 'var(--s-2) var(--s-3)',
          background: 'var(--gov-bg-3, #f3f2f1)',
          borderLeft: '4px solid var(--gov-link, #1d70b8)',
          fontSize: 'var(--t-14)',
          lineHeight: 1.5
        }}>
          <strong style={{ fontSize: 'var(--t-12)', textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--gov-text-muted)' }}>Example · </strong>
          {item.example}
        </div>
      )}
      {item.relatedIds && item.relatedIds.length > 0 && (
        <div style={{ fontSize: 'var(--t-14)', color: 'var(--gov-text-muted)' }}>
          <strong style={{ fontSize: 'var(--t-12)', textTransform: 'uppercase', letterSpacing: '0.08em' }}>See also · </strong>
          {item.relatedIds.map((rid, i) => {
            const rel = GLOSSARY_INDEX[rid];
            if (!rel) return null;
            return (
              <React.Fragment key={rid}>
                {i > 0 && ', '}
                <a href={'#term-' + rid} onClick={(e) => {
                  e.preventDefault();
                  const el = document.getElementById('term-' + rid);
                  if (el) {
                    const r = el.getBoundingClientRect();
                    window.scrollTo({ top: window.scrollY + r.top - 120, behavior: 'smooth' });
                  }
                }}>{rel.term}</a>
              </React.Fragment>
            );
          })}
        </div>
      )}
      {/* invisible anchor for cross-links */}
      <span id={'term-' + item.id} style={{ position: 'absolute' }} aria-hidden="true" />
    </article>
  );
}

window.GlossaryPanel = GlossaryPanel;
