// Request/response contract (v1). The parse* functions are the API boundary.
import { randomUUID } from 'node:crypto';

export class ValidationError extends Error {}

type Body = Record<string, unknown>;

function toFloat(v: unknown, fallback: number, field: string): number {
  if (v === undefined || v === null || v === '') return fallback;
  const n = typeof v === 'number' ? v : Number(v);
  if (!Number.isFinite(n)) throw new ValidationError(`${field} must be a number`);
  return n;
}

function toInt(v: unknown, fallback: number, field: string): number {
  return Math.trunc(toFloat(v, fallback, field));
}

function toStr(v: unknown, fallback: string): string {
  return v === undefined || v === null ? fallback : String(v);
}

function optFloat(v: unknown): number | null {
  if (v === undefined || v === null) return null;
  const n = Number(v);
  return Number.isFinite(n) ? n : null;
}

export const utcNowIso = (): string => new Date().toISOString();

// ---- /decide ---------------------------------------------------------------
export interface Workload {
  vcpu_count: number;
  memory_gb: number;
  duration_minutes_estimate: number;
}

export interface DecideRequest {
  pipeline_id: string;
  run_id: string;
  provider: string;
  pool_mode: string;
  current_region: string;
  candidate_regions: string[];
  candidate_pools: Record<string, string> | null;
  workload: Workload;
  criticality: string;
  max_defer_hours: number;
  deadline_iso: string | null;
  resumed_decision_id: string | null;
}

export function parseDecideRequest(body: Body): DecideRequest {
  const wl = (body.workload && typeof body.workload === 'object' ? body.workload : {}) as Body;
  const pools = body.candidate_pools;
  return {
    pipeline_id: toStr(body.pipeline_id, ''),
    run_id: toStr(body.run_id, ''),
    provider: toStr(body.provider, 'azure'),
    pool_mode: toStr(body.pool_mode, 'self_hosted_multi_region'),
    current_region: toStr(body.current_region, ''),
    candidate_regions: Array.isArray(body.candidate_regions) ? body.candidate_regions.map(String) : [],
    candidate_pools: pools && typeof pools === 'object' && !Array.isArray(pools) ? (pools as Record<string, string>) : null,
    workload: {
      vcpu_count: toInt(wl.vcpu_count, 2, 'workload.vcpu_count'),
      memory_gb: toFloat(wl.memory_gb, 4, 'workload.memory_gb'),
      duration_minutes_estimate: toFloat(wl.duration_minutes_estimate, 15, 'workload.duration_minutes_estimate'),
    },
    criticality: toStr(body.criticality, 'normal'),
    max_defer_hours: toFloat(body.max_defer_hours, 24, 'max_defer_hours'),
    deadline_iso: body.deadline_iso ? String(body.deadline_iso) : null,
    resumed_decision_id: body.resumed_decision_id ? String(body.resumed_decision_id) : null,
  };
}

export interface CarbonBreakdown {
  current_gco2: number;
  selected_gco2: number;
  savings_g: number;
  savings_percent: number;
}

export interface DecideResponse {
  decision_id: string;
  decision: 'RUN_NOW' | 'DEFER' | 'RELOCATE' | 'HYBRID';
  selected_region: string;
  selected_pool: string | null;
  defer_until_iso: string | null;
  defer_minutes: number | null;
  carbon: CarbonBreakdown;
  maizx_score: number | null;
  forecast_confidence: number | null;
  reasoning: string;
  created_at: string;
}

export function makeDecideResponse(
  p: Pick<DecideResponse, 'decision' | 'selected_region' | 'selected_pool'> & Partial<DecideResponse>,
): DecideResponse {
  return {
    decision_id: randomUUID(),
    defer_until_iso: null,
    defer_minutes: null,
    carbon: { current_gco2: 0, selected_gco2: 0, savings_g: 0, savings_percent: 0 },
    maizx_score: null,
    forecast_confidence: null,
    reasoning: '',
    created_at: utcNowIso(),
    ...p,
  };
}

// ---- /store_result ---------------------------------------------------------
export interface StoreResultRequest {
  decision_id: string;
  run_id: string;
  pipeline_id: string;
  region: string;
  duration_seconds: number;
  vcpu_count: number;
  memory_gb: number;
  status: string;
  commit_sha: string | null;
  actual_carbon_g: number | null;
  provider: string;
  stored_at: string;
}

export function parseStoreResultRequest(body: Body): StoreResultRequest {
  return {
    decision_id: toStr(body.decision_id, ''),
    run_id: toStr(body.run_id, ''),
    pipeline_id: toStr(body.pipeline_id, ''),
    region: toStr(body.region, ''),
    duration_seconds: toFloat(body.duration_seconds, 0, 'duration_seconds'),
    vcpu_count: toInt(body.vcpu_count, 0, 'vcpu_count'),
    memory_gb: toFloat(body.memory_gb, 0, 'memory_gb'),
    status: toStr(body.status, 'Unknown'),
    commit_sha: body.commit_sha ? String(body.commit_sha) : null,
    actual_carbon_g: optFloat(body.actual_carbon_g),
    provider: toStr(body.provider, 'azure'),
    stored_at: utcNowIso(),
  };
}

// ---- /calculate ------------------------------------------------------------
export interface CalculateRequest {
  region: string;
  duration_seconds: number;
  vcpu_count: number;
  memory_gb: number;
  provider: string;
}

export function parseCalculateRequest(body: Body): CalculateRequest {
  return {
    region: toStr(body.region, 'uksouth'),
    duration_seconds: toFloat(body.duration_seconds, 0, 'duration_seconds'),
    vcpu_count: toInt(body.vcpu_count, 2, 'vcpu_count'),
    memory_gb: toFloat(body.memory_gb, 4, 'memory_gb'),
    provider: toStr(body.provider, 'azure'),
  };
}

// ---- /budget/check ---------------------------------------------------------
export interface BudgetCheckRequest {
  actual_gco2: number;
  transaction_count: number;
  budget_gco2_per_run: number | null;
  budget_gco2_per_transaction: number | null;
  warn_at_percent: number;
  service: string;
  budget_name: string;
}

export function parseBudgetCheckRequest(body: Body): BudgetCheckRequest {
  return {
    actual_gco2: toFloat(body.actual_gco2, 0, 'actual_gco2'),
    transaction_count: toInt(body.transaction_count, 0, 'transaction_count'),
    budget_gco2_per_run: optFloat(body.budget_gco2_per_run),
    budget_gco2_per_transaction: optFloat(body.budget_gco2_per_transaction),
    warn_at_percent: toFloat(body.warn_at_percent, 80, 'warn_at_percent'),
    service: toStr(body.service, 'unknown'),
    budget_name: toStr(body.budget_name, 'default'),
  };
}

// ---- /ado/connect ----------------------------------------------------------
export interface AdoConnectRequest {
  org_url: string;
  pat: string;
}

export function parseAdoConnectRequest(body: Body): AdoConnectRequest {
  return { org_url: toStr(body.org_url, '').trim(), pat: toStr(body.pat, '').trim() };
}
