import { Router, type Request } from 'express';
import { randomUUID } from 'node:crypto';
import { envBool, envStr, settings } from '../config';
import { getRegionForecast } from '../domain/carbonApi';
import { checkBudget, type ServiceBudget } from '../domain/budget';
import { PUE_VALUES, REGION_INTENSITY_GCO2_KWH } from '../domain/constants';
import { executionRegions, getProvider } from '../domain/providers';
import { calculateEmbodiedCarbon, calculateEnergyKwh, calculateSci, round } from '../domain/sci';
import { emitMetric, logger } from '../logger';
import { AWS_CONNECTION_ID, type Repository } from '../repo/types';
import * as schemas from '../schemas';
import { configuredOrgUrl, configuredProject, listPipelinesGrouped, parseOrgUrl, runPipeline, validateConnection } from '../services/adoClient';
import { deleteConnection, getConnection, saveConnection } from '../services/adoConnection';
import { AWS_ACCESS_KEY_RE, AWS_REGION_RE, listAwsPipelines, validateAwsConnection } from '../services/awsClient';
import { deleteAwsConnection, getAwsConnection, saveAwsConnection } from '../services/awsConnection';
import { ingestAdoRuns } from '../services/adoSync';
import { getCarbonIntensity, regionBaseIntensity } from '../services/carbonService';
import { decide } from '../services/decisionService';
import { ingestCarbonOnce } from '../services/ingestService';
import { seedDemoData } from '../services/seedService';
import { requirePermission, verifyWebhook, type AuthMode } from './auth';
import { HttpError, wrap } from './errors';

const DAY_MS = 86_400_000;

function jsonBody(req: Request): Record<string, unknown> {
  const b = req.body;
  if (!b || typeof b !== 'object' || Array.isArray(b)) throw new HttpError(400, 'Body must be JSON');
  return b as Record<string, unknown>;
}

const query = (req: Request, name: string, fallback = ''): string => {
  const v = req.query[name];
  return typeof v === 'string' ? v : fallback;
};

function parse<T>(fn: () => T): T {
  try {
    return fn();
  } catch (err) {
    if (err instanceof schemas.ValidationError) throw new HttpError(400, `Invalid request: ${err.message}`);
    throw err;
  }
}

async function audit(repo: Repository, req: Request, action: string, outcome: 'success' | 'failure', detail?: Record<string, unknown>) {
  const p = req.principal;
  logger.info({ audit: true, action, outcome, actor: p?.sub, roles: p?.roles, requestId: req.requestId, detail }, 'audit');
  try {
    await repo.putAudit({
      actor: p?.sub ?? 'anonymous', roles: p?.roles ?? [], action, outcome, detail,
      request_id: req.requestId, source_ip: req.ip,
    });
  } catch (err) {
    logger.error({ err }, 'audit persistence failed');
  }
}

/** Routes requiring a verified principal. Mounted under /api after authentication. */
export function protectedRoutes(repo: Repository): Router {
  const r = Router();
  const read = requirePermission('read');
  const pipeline = requirePermission('pipeline');
  const operate = requirePermission('operate');
  const admin = requirePermission('admin');

  r.get('/me', read, (req, res) => {
    res.json({ sub: req.principal?.sub, username: req.principal?.username, roles: req.principal?.roles ?? [] });
  });

  // ---- POST /decide ---------------------------------------------------------
  r.post('/decide', pipeline, wrap(async (req, res) => {
    const decideReq = parse(() => schemas.parseDecideRequest(jsonBody(req)));
    if (!decideReq.pipeline_id) throw new HttpError(400, 'pipeline_id is required');
    const resp = await decide(decideReq, repo);
    emitMetric('Decisions', 1, 'Count', { Decision: resp.decision, Provider: decideReq.provider });
    res.json(resp);
  }));

  // ---- POST /store_result ---------------------------------------------------
  r.post('/store_result', pipeline, wrap(async (req, res) => {
    const result = parse(() => schemas.parseStoreResultRequest(jsonBody(req)));
    if (!result.run_id || !result.pipeline_id) throw new HttpError(400, 'run_id and pipeline_id are required');
    const stored = await repo.upsertExecution({
      id: `${result.pipeline_id}::${result.run_id}`,
      decision_id: result.decision_id,
      run_id: result.run_id,
      pipeline_id: result.pipeline_id,
      provider: result.provider,
      region: result.region,
      duration_seconds: result.duration_seconds,
      vcpu_count: result.vcpu_count,
      memory_gb: result.memory_gb,
      status: result.status,
      commit_sha: result.commit_sha,
      actual_carbon_g: result.actual_carbon_g,
      stored_at: result.stored_at,
    });
    res.json({ stored: true, id: stored.id });
  }));

  // ---- GET /history ---------------------------------------------------------
  r.get('/history', read, wrap(async (req, res) => {
    const pipelineId = query(req, 'pipeline_id');
    const provider = query(req, 'provider', 'azure');
    const parsed = Number.parseInt(query(req, 'limit', String(settings.historyDefaultLimit())), 10);
    const limit = Number.isFinite(parsed) ? Math.max(1, Math.min(settings.historyMaxLimit(), parsed)) : settings.historyDefaultLimit();
    if (!pipelineId) throw new HttpError(400, 'pipeline_id query parameter is required');

    // refresh=1 reconciles real runs from Azure DevOps (source of truth for status, duration and region).
    if (['1', 'true', 'yes'].includes(query(req, 'refresh').toLowerCase())) {
      await ingestAdoRuns(repo, provider, pipelineId, limit);
    }
    const items = await repo.listExecutionsForPipeline(pipelineId, provider, limit);
    res.json({ pipeline_id: pipelineId, provider, items });
  }));

  // ---- GET /carbon ----------------------------------------------------------
  r.get('/carbon', read, wrap(async (req, res) => {
    const providerName = query(req, 'provider', envStr('GREEN_QA_PROVIDER_DEFAULT', 'azure'));
    let provider;
    try {
      provider = getProvider(providerName);
    } catch (err) {
      throw new HttpError(400, (err as Error).message);
    }
    const pue = PUE_VALUES[providerName] ?? settings.defaultPue();
    const regionList = provider.listRegions();
    const latest = await repo.latestCarbonByRegion(providerName, regionList.map((x) => x.code)).catch(() => ({}));
    const regions = regionList.map((region) => {
      const sample = (latest as Record<string, Record<string, unknown>>)[region.code] ?? {};
      let grid = sample.grid_intensity_gco2_kwh as number | undefined;
      let dc = sample.dc_intensity_gco2_kwh as number | undefined;
      let source = sample.source as string | undefined;
      if (typeof grid !== 'number') {
        grid = REGION_INTENSITY_GCO2_KWH[region.code] ?? settings.defaultCarbonIntensity();
        dc = round(grid * (region.dc_metrics.pue || pue), 3);
        source = 'baseline';
      }
      return {
        code: region.code,
        display_name: region.display_name,
        country_code: region.country_code,
        electricitymaps_zone: region.electricitymaps_zone,
        latitude: region.latitude,
        longitude: region.longitude,
        pue: region.dc_metrics.pue,
        wue_l_per_kwh: region.dc_metrics.wue_l_per_kwh,
        renewable_pct: sample.renewable_pct ?? region.dc_metrics.renewable_pct,
        grid_intensity_gco2_kwh: grid,
        dc_intensity_gco2_kwh: dc,
        intensity_gco2_kwh: grid,
        sampled_at: sample.sampled_at ?? null,
        source,
      };
    });
    // Carbon is reported for every region; only execution regions can actually run work.
    res.json({ provider: providerName, execution_regions: executionRegions(providerName), regions });
  }));

  // ---- POST /calculate ------------------------------------------------------
  r.post('/calculate', read, wrap(async (req, res) => {
    const calc = parse(() => schemas.parseCalculateRequest(jsonBody(req)));
    if (calc.duration_seconds <= 0) throw new HttpError(400, 'duration_seconds must be > 0');
    const pue = PUE_VALUES[calc.provider] ?? settings.defaultPue();
    const energy = calculateEnergyKwh(calc.duration_seconds, calc.vcpu_count, calc.memory_gb);
    const embodied = calculateEmbodiedCarbon(calc.vcpu_count, calc.duration_seconds / 3600, calc.provider);
    const intensity = await getCarbonIntensity(repo, calc.region, calc.provider);
    const [sci, breakdown] = calculateSci(energy, intensity, embodied, settings.defaultFunctionalUnit());
    res.json({
      region: calc.region,
      provider: calc.provider,
      duration_seconds: calc.duration_seconds,
      vcpu_count: calc.vcpu_count,
      memory_gb: calc.memory_gb,
      pue,
      carbon_intensity_gco2_kwh: intensity,
      energy_kwh: round(energy, 6),
      embodied_carbon_g: round(embodied, 4),
      carbon_emissions_g: breakdown.total_emissions_g,
      carbon_emissions_kg: round(breakdown.total_emissions_g / 1000, 6),
      sci: round(sci, 4),
      breakdown,
      timestamp: new Date().toISOString(),
    });
  }));

  // ---- POST /budget/check ---------------------------------------------------
  r.post('/budget/check', read, wrap(async (req, res) => {
    const b = parse(() => schemas.parseBudgetCheckRequest(jsonBody(req)));
    let budget: ServiceBudget | null = null;
    if (b.budget_gco2_per_run !== null || b.budget_gco2_per_transaction !== null) {
      budget = {
        name: b.budget_name,
        budget_gco2_per_run: b.budget_gco2_per_run,
        budget_gco2_per_transaction: b.budget_gco2_per_transaction,
        warn_at_percent: b.warn_at_percent,
      };
    }
    res.json(checkBudget(b.actual_gco2, b.transaction_count, budget, b.service));
  }));

  // ---- GET /forecast --------------------------------------------------------
  r.get('/forecast', read, wrap(async (req, res) => {
    const region = query(req, 'region', 'uksouth');
    const provider = query(req, 'provider', 'azure');
    const [periods, source] = await getRegionForecast(region, provider, await regionBaseIntensity(repo, provider, region));
    res.json({ region, provider, source, periods, generated_at: new Date().toISOString() });
  }));

  // ---- GET /overview --------------------------------------------------------
  r.get('/overview', read, wrap(async (req, res) => {
    const provider = query(req, 'provider', envStr('GREEN_QA_PROVIDER_DEFAULT', 'azure'));
    const parsedDays = Number.parseInt(query(req, 'days', '30'), 10);
    const days = Number.isFinite(parsedDays) ? Math.max(1, Math.min(90, parsedDays)) : 30;

    const now = Date.now();
    const iso = (offsetDays: number) => new Date(now - offsetDays * DAY_MS).toISOString().slice(0, 10);
    const cutoff30 = iso(days);
    const cutoff7 = iso(7);

    let rows: Awaited<ReturnType<Repository['listExecutionsSince']>> = [];
    try {
      rows = await repo.listExecutionsSince(provider, cutoff30);
    } catch (err) {
      logger.error({ err }, '/overview executions query failed');
    }

    const by30: Record<string, number> = {};
    const by7: Record<string, number> = {};
    const strategyCounts: Record<string, number> = { RUN_NOW: 0, DEFER: 0, RELOCATE: 0, HYBRID: 0 };
    let emitted = 0;
    let saved = 0;
    let runs = 0;

    for (const row of rows) {
      const day = String(row.stored_at ?? '').slice(0, 10);
      if (!day || day < cutoff30) continue;
      const actual = Number(row.actual_carbon_g ?? 0) || 0;
      const baseline = Number(row.baseline_carbon_g ?? 0) || 0;
      by30[day] = (by30[day] ?? 0) + actual;
      if (day >= cutoff7) by7[day] = (by7[day] ?? 0) + actual;
      emitted += actual;
      if (baseline > actual) saved += baseline - actual;
      runs += 1;
      const strat = String(row.decision ?? row.strategy ?? '').toUpperCase();
      if (strat in strategyCounts) strategyCounts[strat] += 1;
    }

    const series = (byDay: Record<string, number>, length: number) =>
      Array.from({ length }, (_, k) => {
        const d = iso(length - 1 - k);
        return { date: d, co2_g: round(byDay[d] ?? 0, 2) };
      });

    const stratTotal = Object.values(strategyCounts).reduce((a, b) => a + b, 0) || 1;
    res.json({
      provider,
      window_days: days,
      totals: {
        co2_emitted_g: round(emitted, 2),
        co2_saved_g: round(saved, 2),
        runs,
        avg_per_run_g: round(runs ? emitted / runs : 0, 2),
      },
      trend_7d: series(by7, 7),
      trend_30d: series(by30, days),
      strategy_mix: Object.entries(strategyCounts).map(([id, count]) => ({ id, count, pct: round(count / stratTotal, 4) })),
      generated_at: new Date(now).toISOString(),
    });
  }));

  // ---- POST /carbon/ingest --------------------------------------------------
  r.post('/carbon/ingest', operate, wrap(async (req, res) => {
    const inserted = await ingestCarbonOnce(repo);
    await audit(repo, req, 'carbon.ingest', 'success', { inserted });
    res.json({ ingested: inserted, providers: settings.ingestProviders() });
  }));

  // ---- Azure DevOps connection ---------------------------------------------
  r.post('/ado/connect', admin, wrap(async (req, res) => {
    const creds = parse(() => schemas.parseAdoConnectRequest(jsonBody(req)));
    if (!creds.org_url) return res.status(400).json({ connected: false, error: 'Org URL is required.' });

    const result = await validateConnection(creds.org_url, creds.pat);
    if (!result.success) {
      await audit(repo, req, 'ado.connect', 'failure', { reason: result.error });
      return res.status(result.error.includes('Authentication') ? 401 : 400).json({ connected: false, error: result.error });
    }

    const validatedAt = new Date().toISOString();
    const project = configuredProject();
    try {
      // The PAT goes to Secrets Manager; the table only holds non-secret metadata.
      await saveConnection(repo, { organization: result.organization, org_url: result.org_url, project, pat: creds.pat, validated_at: validatedAt });
    } catch (err) {
      logger.error({ err }, 'ado_connect: failed to persist connection');
      return res.status(500).json({ connected: false, error: 'Validated, but failed to persist the connection.' });
    }
    await audit(repo, req, 'ado.connect', 'success', { organization: result.organization });
    res.json({
      connected: true,
      organization: result.organization,
      org_url: result.org_url,
      project,
      projects: result.projects,
      validated_at: validatedAt,
      message: `Connected to ${result.organization}.`,
    });
  }));

  r.get('/ado/status', read, wrap(async (_req, res) => {
    const conn = await getConnection(repo).catch(() => null);
    if (!conn) return res.json({ connected: false, default_org_url: configuredOrgUrl() });
    // Never returns the PAT.
    res.json({
      connected: true,
      organization: conn.organization,
      org_url: conn.org_url,
      project: conn.project || configuredProject(),
      validated_at: conn.validated_at,
    });
  }));

  r.post('/ado/disconnect', admin, wrap(async (req, res) => {
    try {
      await deleteConnection(repo);
    } catch (err) {
      logger.error({ err }, 'ado_disconnect failed');
    }
    await audit(repo, req, 'ado.disconnect', 'success');
    res.json({ connected: false });
  }));

  r.get('/ado/pipelines', read, wrap(async (_req, res) => {
    const conn = await getConnection(repo).catch(() => null);
    if (!conn) return res.status(409).json({ error: 'not_connected', message: 'Connect Azure DevOps first.' });
    try {
      res.json(await listPipelinesGrouped(conn.org_url, conn.pat));
    } catch (err) {
      logger.error({ err }, 'ado_pipelines failed');
      res.status(502).json({ error: `Failed to list pipelines: ${(err as Error).message}` });
    }
  }));

  /** Trigger a real ADO run for the selected region and log it to Run History. */
  r.post('/ado/run', operate, wrap(async (req, res) => {
    const body = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<string, unknown>;
    const definitionId = String(body.pipeline_id ?? '').trim();
    const region = String(body.region ?? '').trim();
    if (!definitionId || !region) throw new HttpError(400, 'pipeline_id and region are required');

    const providerName = String(body.provider ?? 'azure');
    const allowed = executionRegions(providerName);
    if (allowed.length && !allowed.includes(region)) {
      return res.status(400).json({
        error: 'region_not_executable',
        message: `${region} has no agent capacity. Allowed: ${allowed.join(', ')}.`,
        execution_regions: allowed,
      });
    }

    const decision = String(body.decision ?? 'RUN_NOW').toUpperCase();
    const decisionId = String(body.decision_id ?? randomUUID());
    const branch = body.branch ? String(body.branch) : null;
    const criticality = String(body.criticality ?? 'normal');
    const runId = String(body.run_id ?? `run-${Date.now()}`);

    const conn = await getConnection(repo).catch(() => null);
    if (!conn) return res.status(409).json({ error: 'not_connected', message: 'Connect Azure DevOps first.' });

    const organization = parseOrgUrl(conn.org_url) || conn.organization;
    const project = String(body.project ?? conn.project ?? configuredProject()).trim();

    // targetRegion is only sent once the pipeline YAML declares it; ADO rejects undeclared parameters.
    const sendTargetRegion = envBool('GREENQA_SEND_TARGET_REGION');
    // A dashboard run sends NO queue-time variables (most pipelines don't mark them settable).
    const result = await runPipeline({
      organization, project, definitionId, decisionId, variables: null, branch, pat: conn.pat,
      includeResumeVars: false, templateParameters: sendTargetRegion ? { targetRegion: region } : null,
    });
    const triggered = result.success;
    const adoRunId = result.run_id ?? runId;
    const triggerError = triggered ? null : (result.error ?? null);

    // Carbon is unknown until the run finishes; /history?refresh=1 fills in duration, pool and emissions.
    const record = {
      id: `${definitionId}::${adoRunId}`,
      run_id: adoRunId,
      pipeline_id: definitionId,
      project,
      provider: providerName,
      region,
      duration_seconds: 0,
      status: triggered ? 'Queued' : 'Failed',
      failure_reason: triggered ? null : (triggerError || 'Pipeline trigger failed.'),
      decision,
      decision_id: decisionId,
      criticality,
      actual_carbon_g: 0,
      baseline_carbon_g: 0,
      carbon_estimated: true,
      requested_region: region,
      web_url: result.url ?? null,
      pool: null as string | null,
      stored_at: new Date().toISOString(),
    };
    let stored = false;
    try {
      await repo.upsertExecution(record);
      stored = true;
    } catch (err) {
      logger.error({ err }, 'ado_run: failed to log execution');
    }
    await audit(repo, req, 'ado.run', triggered ? 'success' : 'failure', { definitionId, region, decision });
    // Always 200: the trigger outcome is carried by `triggered`; failed attempts are still logged to history.
    res.json({
      triggered, stored, run_id: adoRunId, decision, decision_id: decisionId, region,
      url: result.url, target_region_sent: sendTargetRegion, error: triggerError, run: record,
    });
  }));

  // ---- AWS CodePipeline connection (access key pair; secret kept in Secrets Manager) ----
  r.post('/aws/connect', admin, wrap(async (req, res) => {
    const body = jsonBody(req);
    const region = String(body.region ?? '').trim();
    const accessKeyId = String(body.access_key_id ?? '').trim();
    const secretAccessKey = String(body.secret_access_key ?? '').trim();
    if (!AWS_REGION_RE.test(region)) return res.status(400).json({ connected: false, error: 'A valid AWS region is required (e.g. eu-west-2).' });
    if (!AWS_ACCESS_KEY_RE.test(accessKeyId) || secretAccessKey.length < 16) {
      return res.status(400).json({ connected: false, error: 'Access key ID and secret access key are required.' });
    }

    const target = { region, access_key_id: accessKeyId, secret_access_key: secretAccessKey };
    const result = await validateAwsConnection(target);
    if (!result.success) {
      await audit(repo, req, 'aws.connect', 'failure', { region });
      return res.status(result.error.includes('Authentication') ? 401 : 400).json({ connected: false, error: result.error });
    }
    const validatedAt = new Date().toISOString();
    try {
      await saveAwsConnection(repo, { ...target, account_id: result.account_id, validated_at: validatedAt });
    } catch (err) {
      logger.error({ err }, 'aws_connect: failed to persist connection');
      return res.status(500).json({ connected: false, error: 'Validated, but failed to persist the connection.' });
    }
    await audit(repo, req, 'aws.connect', 'success', { region, account_id: result.account_id });
    res.json({
      connected: true, region, account_id: result.account_id,
      pipelines: result.pipelines, validated_at: validatedAt, message: `Connected to AWS account ${result.account_id} (${region}).`,
    });
  }));

  r.get('/aws/status', read, wrap(async (_req, res) => {
    const rec = await repo.getConnection(AWS_CONNECTION_ID).catch(() => null);
    if (!rec) return res.json({ connected: false });
    // Never returns the secret key; only the last 4 characters of the key ID.
    res.json({
      connected: true, region: rec.region,
      account_id: rec.account_id, access_key_hint: rec.access_key_hint, validated_at: rec.validated_at,
    });
  }));

  r.post('/aws/disconnect', admin, wrap(async (req, res) => {
    try {
      await deleteAwsConnection(repo);
    } catch (err) {
      logger.error({ err }, 'aws_disconnect failed');
    }
    await audit(repo, req, 'aws.disconnect', 'success');
    res.json({ connected: false });
  }));

  r.get('/aws/pipelines', read, wrap(async (_req, res) => {
    const conn = await getAwsConnection(repo);
    if (!conn) return res.status(409).json({ error: 'not_connected', message: 'Connect AWS first.' });
    try {
      const pipelines = await listAwsPipelines(conn);
      res.json({ region: conn.region, total: pipelines.length, pipelines });
    } catch (err) {
      logger.error({ err }, 'aws_pipelines failed');
      res.status(502).json({ error: `Failed to list pipelines: ${(err as Error).message}` });
    }
  }));

  // ---- /dev/seed ------------------------------------------------------------
  r.all('/dev/seed', admin, wrap(async (req, res) => {
    if (!['GET', 'POST'].includes(req.method)) throw new HttpError(405, 'method not allowed');
    if (!envBool('DEV_SEED_ENABLED')) throw new HttpError(403, 'dev seeder disabled — set DEV_SEED_ENABLED=true');
    const body = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<string, unknown>;
    const arg = (name: string, def: unknown) => body[name] ?? req.query[name] ?? def;
    const clamp = (v: unknown, lo: number, hi: number, def: number) => {
      const n = Number.parseInt(String(v), 10);
      return Number.isFinite(n) ? Math.max(lo, Math.min(hi, n)) : def;
    };
    const days = clamp(arg('days', 30), 1, 90, 30);
    const perDay = clamp(arg('per_day', 4), 1, 20, 4);
    const provider = String(arg('provider', 'azure'));
    try {
      getProvider(provider);
    } catch (err) {
      throw new HttpError(400, (err as Error).message);
    }
    const { seededRuns, seededCarbon } = await seedDemoData(repo, { days, perDay, provider });
    await audit(repo, req, 'dev.seed', 'success', { days, perDay, provider });
    res.json({
      seeded: true, days, per_day_per_pipeline: perDay, executions_inserted: seededRuns,
      carbon_samples_inserted: seededCarbon, provider,
    });
  }));

  return r;
}

/** Routes with their own (non-JWT) protection, mounted before authentication. */
export function publicRoutes(repo: Repository, mode: AuthMode, version: string): Router {
  const r = Router();

  r.get('/health', wrap(async (req, res) => {
    if (query(req, 'deep') === '1') {
      try {
        await repo.ping();
      } catch (err) {
        logger.error({ err }, 'health: repository unreachable');
        return res.status(503).json({ status: 'degraded', checks: { repository: 'fail' } });
      }
      return res.json({ status: 'ok', version, checks: { repository: 'ok' } });
    }
    res.json({ status: 'ok', version });
  }));

  // ADO Service Hook sink; authenticated by shared secret instead of a user token.
  r.post('/ingest-ado-event', wrap(async (req, res) => {
    if (!(await verifyWebhook(req, mode))) throw new HttpError(401, 'unauthorized');
    const body = (req.body && typeof req.body === 'object' ? req.body : {}) as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
    const eventType = String(body.eventType ?? '');
    // Still 200 — ADO's webhook health checks look for this.
    if (!eventType.startsWith('ms.vss-pipelines')) return res.json({ accepted: false, reason: 'not_a_pipeline_event' });

    const resource = body.resource ?? {};
    const run = resource.run ?? resource;
    const pipeline = resource.pipeline ?? {};
    try {
      await repo.upsertExecution({
        id: `ado-event::${randomUUID()}`,
        event_type: eventType,
        pipeline_id: `azdo://${pipeline.organization ?? ''}/${pipeline.project ?? ''}/${pipeline.id ?? ''}`,
        run_id: String(run.id ?? ''),
        state: run.state ?? '',
        result: run.result ?? '',
        raw: body,
        stored_at: new Date().toISOString(),
        provider: 'azure',
      });
    } catch (err) {
      logger.error({ err }, 'ingest_ado_event upsert failed');
    }
    res.status(202).json({ accepted: true });
  }));

  return r;
}
