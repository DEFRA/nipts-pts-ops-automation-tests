import { CodePipelineClient, ListPipelinesCommand } from '@aws-sdk/client-codepipeline';
import { GetCallerIdentityCommand, STSClient } from '@aws-sdk/client-sts';

export const AWS_REGION_RE = /^[a-z]{2}(-[a-z]+)+-\d$/;
export const AWS_ACCESS_KEY_RE = /^[A-Z0-9]{16,128}$/;

export interface AwsTarget {
  region: string;
  access_key_id: string;
  secret_access_key: string;
}

const clientConfig = (t: AwsTarget) => ({
  region: t.region,
  credentials: { accessKeyId: t.access_key_id, secretAccessKey: t.secret_access_key },
});

export type AwsValidation = { success: true; account_id: string; pipelines: number } | { success: false; error: string };

export async function validateAwsConnection(t: AwsTarget): Promise<AwsValidation> {
  try {
    const identity = await new STSClient(clientConfig(t)).send(new GetCallerIdentityCommand({}));
    const res = await new CodePipelineClient(clientConfig(t)).send(new ListPipelinesCommand({ maxResults: 100 }));
    return { success: true, account_id: identity.Account ?? '', pipelines: res.pipelines?.length ?? 0 };
  } catch (err) {
    const e = err as { name?: string; message?: string };
    const auth = /InvalidClientTokenId|SignatureDoesNotMatch|UnrecognizedClient|ExpiredToken/.test(e.name ?? '');
    return { success: false, error: auth ? 'Authentication failed. Check the access key ID and secret access key.' : `AWS validation failed (${e.name ?? 'Error'}): ${e.message ?? 'unknown error'}` };
  }
}

export interface AwsPipeline { name: string; region: string; updated_at: string | null }

export async function listAwsPipelines(t: AwsTarget): Promise<AwsPipeline[]> {
  const cp = new CodePipelineClient(clientConfig(t));
  const out: AwsPipeline[] = [];
  let token: string | undefined;
  do {
    const res = await cp.send(new ListPipelinesCommand({ nextToken: token, maxResults: 100 }));
    for (const p of res.pipelines ?? []) {
      if (p.name) out.push({ name: p.name, region: t.region, updated_at: p.updated?.toISOString() ?? null });
    }
    token = res.nextToken;
  } while (token);
  return out;
}
