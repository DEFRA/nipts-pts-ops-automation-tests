# Self-hosted regional agent pools — setup & wiring

This guide explains how to make a carbon-aware decision **actually move compute
to a greener region**, instead of only logging the recommendation.

## Why this is needed

Microsoft-hosted agents (`pool: { vmImage: ubuntu-latest }`) always run in the
**hosted-pool region for your organization's geography** — for `vibecode` that's
UK South / UK West. They **cannot be relocated**. So when the gate decides
`RELOCATE → swedencentral`, the job still physically runs in uksouth and the
relocate step only prints:

```
Would re-queue the workload onto pool 'agents-swedencentral'.
(In a self-hosted multi-region setup … For this demo we just log.)
```

To honour the decision, the workload must run on a **self-hosted agent that
lives in the target region**. You create one agent pool per region, named
`agents-<region>` (e.g. `agents-swedencentral`), put at least one agent in each,
and the pipeline picks the pool from a `targetRegion` parameter the dashboard
sends at queue time.

```
Dashboard (region) ─▶ POST /api/ado/run (templateParameters.targetRegion)
                    ─▶ pipeline job  pool: { name: agents-<region> }
                    ─▶ self-hosted agent running in <region>
```

---

## 1. Decide the regions and naming convention

Pick the regions you want to be able to run in. The pool name **must** be
`agents-<azure-region-code>` to match the pipeline YAML, e.g.:

| Azure region        | Agent pool name         |
|---------------------|-------------------------|
| uksouth             | `agents-uksouth`        |
| swedencentral       | `agents-swedencentral`  |
| norwayeast          | `agents-norwayeast`     |
| francecentral       | `agents-francecentral`  |

> The prefix `agents-` is set in `pipelines/_shared/gate-template.yml`
> (`name: agents-${{ parameters.targetRegion }}`). Keep them in sync.

---

## 2. Create the agent pools in Azure DevOps

For **each** region, in the ADO org (one-time, org-level):

1. **Organization settings → Pipelines → Agent pools → Add pool**
   - Pool type: **Self-hosted**
   - Name: `agents-<region>` (e.g. `agents-swedencentral`)
   - Tick **Grant access permission to all pipelines** (or grant per-pipeline in step 5).
2. Repeat for every region you listed in step 1.

CLI alternative (`az devops`):

```bash
az devops login   # paste a PAT with "Agent Pools (read, manage)" scope

for region in uksouth swedencentral norwayeast francecentral; do
  az pipelines pool create \
    --name "agents-$region" \
    --organization https://dev.azure.com/vibecode
done
```

---

## 3. Provision one machine **in each region** and install the agent

The agent must run on compute physically located in that Azure region, so the
carbon accounting is real. Cheapest reliable option: a small Azure VM per region.

### 3a. Create a VM in the region (example: swedencentral)

```bash
az group create -n rg-greenqa-agents-swedencentral -l swedencentral

az vm create \
  -g rg-greenqa-agents-swedencentral \
  -n agent-swedencentral-1 \
  -l swedencentral \
  --image Ubuntu2404 \
  --size Standard_B2s \
  --admin-username azureuser \
  --generate-ssh-keys
```

### 3b. Install + register the ADO agent on that VM

SSH in, then:

```bash
# 1. Create a PAT in ADO with scope: Agent Pools (Read & manage). Export it:
export AZP_TOKEN='<pat>'
export AZP_URL='https://dev.azure.com/vibecode'
export AZP_POOL='agents-swedencentral'        # MUST match the region pool

# 2. Download the Linux agent (version from ADO → Agent pools → New agent)
mkdir myagent && cd myagent
curl -LsS https://vstsagentpackage.azureedge.net/agent/4.255.0/vsts-agent-linux-x64-4.255.0.tar.gz \
  | tar -xz

# 3. Configure unattended, bound to the region pool
./config.sh --unattended \
  --url "$AZP_URL" \
  --auth pat --token "$AZP_TOKEN" \
  --pool "$AZP_POOL" \
  --agent "$(hostname)" \
  --acceptTeeEula

# 4. Run as a service so it survives reboot
sudo ./svc.sh install azureuser
sudo ./svc.sh start
```

Confirm in **ADO → Agent pools → agents-swedencentral → Agents**: the agent
shows **Online**.

> **Repeat 3a–3b for every region.** For elasticity instead of always-on VMs,
> use a **VM Scale Set agent pool** (ADO → Add pool → *Azure virtual machine
> scale set*) per region, or container agents on **Azure Container Apps** /
> **Container Instances** created in each region — same pool-naming rule applies.

---

## 4. Install the GreenQA dependencies on the agent (if your workload needs them)

Self-hosted agents are not pre-loaded like MS-hosted ones. Install whatever the
real workload needs (node, python, docker, etc.). For the demo `bash` steps,
nothing extra is required.

---

## 5. Grant the pipelines permission to use the pools

If you did **not** tick "grant to all pipelines" in step 2:

- **Agent pool → Security → +** add each pipeline (or the project's build
  identity) with **User** role.

---

## 5b. (Option B) One existing pool + `region` capability routing

Instead of one pool per region, you can keep **a single self-hosted pool** and
put every regional VM in it, telling the agents apart with a user capability
`region`. The pipeline then selects the in-region agent with a **demand**:

```yaml
pool:
  name: <your-existing-pool>      # e.g. the pool at poolId you already have
  demands:
    - region -equals <targetRegion>
```

This is the mode the backend uses when `GREENQA_AGENT_POOL_MODE=self_hosted`
(it sends `templateParameters: { targetRegion, agentPoolName }`).

**Set the `region` capability on each agent — two ways:**

1. **Env var before configuring** (the agent auto-publishes env vars as
   capabilities). On the Sweden VM, before `./config.sh`:
   ```bash
   export region=swedencentral
   ```
   On the West Europe VM:
   ```bash
   export region=westeurope
   ```
   Then run `./config.sh …` and start the service. (If the agent is already
   configured, set the env var and **restart** the service so it re-publishes:
   `sudo ./svc.sh stop && sudo ./svc.sh start`.)

2. **ADO UI:** Agent pools → *your pool* → Agents → pick the agent →
   **Capabilities** → *Add* user capability `region` = `swedencentral`
   (and `westeurope` on the other). No restart needed.

Verify under each agent's **Capabilities** that `region` shows the right value.
Both VMs register into the **same** pool (`./config.sh --pool "<your-pool>"`).

---

## 6. Turn on self-hosted routing in the backend

The dashboard already sends the selected region. The backend forwards it as the
`targetRegion` template parameter **only when self-hosted mode is on**, so your
current MS-hosted runs keep working until the pools exist.

In `backend/azure/functions/local.settings.json` (or the Function App settings):

```json
"GREENQA_AGENT_POOL_MODE": "self_hosted",
"GREENQA_AGENT_POOL_NAME": "<your-existing-pool-name>"
```

- `ms_hosted` (default) → sends no template parameters → `vmImage: ubuntu-latest` (today's behaviour).
- `self_hosted` → sends `targetRegion=<selected region>` + `agentPoolName` →
  the workload runs on `<pool>` on the agent whose `region` capability matches.

Restart the backend after changing settings.

---

## 7. How a run now flows end-to-end

1. In the dashboard, **Apply Recommendation** (or **Re-route**) sets the home/target region.
2. **Run Now** → `POST /api/ado/run { region: "swedencentral", … }`.
3. Backend (self-hosted mode) triggers the pipeline with
   `templateParameters: { targetRegion: "swedencentral" }`.
4. The pipeline's workload job resolves `pool: { name: agents-swedencentral }`
   and queues on the agent **running in Sweden**.
5. The run is logged to Run History and its status syncs from ADO.

If the pool has no online agent, ADO leaves the run **queued** until one comes
online — so make sure step 3 shows the agent **Online** before relying on it.

---

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Run stays **queued** forever | No online agent in `agents-<region>`. Start the agent (`sudo ./svc.sh status`). |
| `Pool not found` / 404 on queue | Pool name ≠ `agents-<region>`, or pipeline lacks pool permission (step 5). |
| Still runs in uksouth | `GREENQA_AGENT_POOL_MODE` not set to `self_hosted`, or pipeline YAML not updated/committed. |
| `HTTP 400 … Settable at queue time` | You're sending a *variable* not a *template parameter*. `targetRegion` is a pipeline **parameter** (declared in the YAML root) — the backend sends it as `templateParameters`, which is allowed without the queue-time toggle. |
