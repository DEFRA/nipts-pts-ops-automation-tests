import pino from 'pino';
import { envStr } from './config';

// Structured JSON to stdout: CloudWatch Logs Insights can query every field.
export const logger = pino({
  level: envStr('LOG_LEVEL', 'info'),
  base: { service: 'zerocarb-api', env: envStr('APP_ENV', 'local') },
  timestamp: pino.stdTimeFunctions.isoTime,
  // Never log credentials, even by accident.
  redact: {
    paths: ['req.headers.authorization', 'req.headers["x-greenqa-webhook-secret"]', '*.pat', '*.token', '*.password'],
    censor: '[redacted]',
  },
});

/** CloudWatch Embedded Metric Format line (no-op cost outside AWS: it is just a log line). */
export function emitMetric(
  name: string,
  value: number,
  unit: 'Count' | 'Milliseconds' | 'None' = 'Count',
  dimensions: Record<string, string> = {},
): void {
  const dimKeys = Object.keys(dimensions);
  process.stdout.write(
    JSON.stringify({
      _aws: {
        Timestamp: Date.now(),
        CloudWatchMetrics: [{
          Namespace: 'ZeroCarb',
          Dimensions: [dimKeys],
          Metrics: [{ Name: name, Unit: unit }],
        }],
      },
      ...dimensions,
      [name]: value,
    }) + '\n',
  );
}
