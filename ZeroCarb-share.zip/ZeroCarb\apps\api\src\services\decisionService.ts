// Decision service — wraps SchedulingEngine with the ADO-facing request/response contract.
//   * resumed runs short-circuit to RUN_NOW (breaks infinite DEFER loops)
//   * ms_hosted_single_region pools can never relocate
//   * DEFER/HYBRID intents are persisted for the resume_deferred scheduler
import { randomUUID } from 'node:crypto';
import { envStr } from '../config';
import { getRegionForecast, type ForecastPeriod } from '../domain/carbonApi';
import type { Criticality } from '../domain/constants';
import { executionRegions, getProvider } from '../domain/providers';
import { SchedulingEngine } from '../domain/schedulingEngine';
import { round } from '../domain/sci';
import { logger } from '../logger';
import type { Repository } from '../repo/types';
import { makeDecideResponse, type DecideRequest, type DecideResponse } from '../schemas';

const CRITICALITY: Record<string, Criticality> = { critical: 'critical', high: 'high', normal: 'normal', low: 'low' };

export async function liveIntensities(repo: Repository, provider: string): Promise<Record<string, number>> {
  try {
    const regions = getProvider(provider).listRegions().map((r) => r.code);
    const samples = await repo.latestCarbonByRegion(provider, regions);
    const out: Record<string, number> = {};
    for (const [region, s] of Object.entries(samples)) {
      const v = s.grid_intensity_gco2_kwh;
      if (typeof v === 'number' && v > 0) out[region] = v;
    }
    return out;
  } catch (err) {
    logger.error({ err }, 'liveIntensities: lookup failed');
    return {};
  }
}

async function regionForecasts(provider: string, regions: string[], intensities: Record<string, number>) {
  const out: Record<string, ForecastPeriod[]> = {};
  for (const region of regions.filter(Boolean)) {
    try {
      [out[region]] = await getRegionForecast(region, provider, intensities[region]);
    } catch (err) {
      logger.error({ err, region }, 'regionForecasts: forecast failed');
    }
  }
  return out;
}

async function buildEngine(provider: string, repo: Repository, forecastRegions: string[]): Promise<SchedulingEngine> {
  const intensities = await liveIntensities(repo, provider);
  return new SchedulingEngine({
    config: {
      MIN_SAVINGS_PERCENT: envStr('MIN_SAVINGS_PERCENT', '10'),
      ALLOW_HYBRID: envStr('ALLOW_HYBRID', 'true'),
      ALPHA_FAIRNESS: envStr('ALPHA_FAIRNESS', '0.5'),
      MAX_DEFER_HOURS: envStr('MAX_DEFER_HOURS', '12'),
    },
    provider,
    allowedRegions: executionRegions(provider),
    regionIntensities: intensities,
    regionForecasts: await regionForecasts(provider, forecastRegions, intensities),
  });
}

function poolFor(req: DecideRequest, region: string): string | null {
  if (req.pool_mode === 'ms_hosted_single_region') return null;
  if (req.candidate_pools) return req.candidate_pools[region] || `agents-${region}`;
  return `agents-${region}`;
}

function shortCircuitResumed(req: DecideRequest): DecideResponse {
  const region = req.current_region || getProvider(req.provider).defaultRegion();
  return makeDecideResponse({
    decision_id: req.resumed_decision_id || randomUUID(),
    decision: 'RUN_NOW',
    selected_region: region,
    selected_pool: poolFor(req, region),
    reasoning: 'Resumed from DEFER — short-circuiting to RUN_NOW to prevent loops.',
  });
}

export function labelForStrategy(strategy: string, targetRegion: string, currentRegion: string): DecideResponse['decision'] {
  if (strategy === 'space_shift' && targetRegion === currentRegion) return 'RUN_NOW';
  return ({ run_now: 'RUN_NOW', time_shift: 'DEFER', space_shift: 'RELOCATE', hybrid: 'HYBRID' } as const)[strategy as 'run_now'] ?? 'RUN_NOW';
}

/** 'azdo://{org}/{project}/{def_id}' -> parts. */
export function parseAdoParts(pipelineId: string): { organization?: string; project?: string; definition_id?: string } {
  if (!pipelineId?.startsWith('azdo://')) return {};
  const parts = pipelineId.slice('azdo://'.length).split('/');
  if (parts.length < 3) return {};
  return { organization: parts[0], project: parts[1], definition_id: parts[2] };
}

async function persistDeferIntent(repo: Repository, req: DecideRequest, resp: DecideResponse, decisionId: string): Promise<void> {
  try {
    await repo.upsertDeferred({
      id: decisionId,
      decision_id: decisionId,
      pipeline_id: req.pipeline_id,
      run_id: req.run_id,
      provider: req.provider,
      region: resp.selected_region,
      pool: resp.selected_pool,
      defer_until_iso: resp.defer_until_iso ?? undefined,
      status: 'pending',
      attempts: 0,
      created_at: resp.created_at,
      workload: { ...req.workload },
      ado_parts: parseAdoParts(req.pipeline_id),
      criticality: req.criticality,
    });
  } catch (err) {
    logger.error({ err, decisionId }, 'Failed to persist defer intent');
  }
}

export async function decide(req: DecideRequest, repo: Repository): Promise<DecideResponse> {
  if (req.resumed_decision_id) {
    logger.info({ decisionId: req.resumed_decision_id }, 'decide: resumed run, skipping scheduling');
    return shortCircuitResumed(req);
  }

  if (req.pool_mode === 'ms_hosted_single_region') {
    req.candidate_regions = req.current_region ? [req.current_region] : [];
  }

  const currentRegion = req.current_region || getProvider(req.provider).defaultRegion();
  const engine = await buildEngine(req.provider, repo, [currentRegion]);
  const criticality = CRITICALITY[req.criticality.toLowerCase()] ?? 'normal';

  let sd;
  try {
    sd = engine.getOptimalStrategy(req.pipeline_id, currentRegion, criticality);
  } catch (err) {
    logger.error({ err }, 'SchedulingEngine failed');
    return makeDecideResponse({
      decision: 'RUN_NOW',
      selected_region: currentRegion,
      selected_pool: poolFor(req, currentRegion),
      reasoning: `scheduling_engine_error: ${(err as Error).message}; defaulting to RUN_NOW`,
    });
  }

  const strategy = sd.recommended_strategy;
  const label = labelForStrategy(strategy, sd.target_region, currentRegion);
  const decisionId = randomUUID();

  // MS-hosted agents cannot change region: coerce any cross-region recommendation back to RUN_NOW.
  if (req.pool_mode === 'ms_hosted_single_region' && sd.target_region !== currentRegion && (label === 'RELOCATE' || label === 'HYBRID')) {
    logger.info({ label, target: sd.target_region, currentRegion }, 'decide: MS-hosted pool cannot relocate; forcing RUN_NOW');
    return makeDecideResponse({
      decision_id: decisionId,
      decision: 'RUN_NOW',
      selected_region: currentRegion,
      selected_pool: null,
      carbon: {
        current_gco2: round(sd.current_intensity, 3),
        selected_gco2: round(sd.current_intensity, 3),
        savings_g: 0,
        savings_percent: 0,
      },
      reasoning: `MS-hosted pool cannot relocate; engine recommended ${label} -> ${sd.target_region}. Running in ${currentRegion}.`,
    });
  }

  let deferIso: string | null = null;
  let deferMinutes: number | null = null;
  if ((strategy === 'time_shift' || strategy === 'hybrid') && sd.scheduled_time) {
    deferIso = sd.scheduled_time.toISOString();
    deferMinutes = sd.wait_hours * 60;
  }

  const resp = makeDecideResponse({
    decision_id: decisionId,
    decision: label,
    selected_region: sd.target_region,
    selected_pool: poolFor(req, sd.target_region),
    defer_until_iso: deferIso,
    defer_minutes: deferMinutes,
    carbon: {
      current_gco2: round(sd.current_intensity, 3),
      selected_gco2: round(sd.target_intensity, 3),
      savings_g: round(Math.max(0, sd.current_intensity - sd.target_intensity), 3),
      savings_percent: round(sd.carbon_savings_percent, 2),
    },
    reasoning: sd.decision_reason,
  });

  if ((label === 'DEFER' || label === 'HYBRID') && deferIso) await persistDeferIntent(repo, req, resp, decisionId);
  return resp;
}
