// Runtime config for the dashboard (template).
//
// AWS: the CDK deployment writes the real config.js into the site bucket
// (see infra/lib/app-stack.ts), so nothing here is baked into the build.
// Local: `npm run dev:web` serves a generated config.js pointing at the local API.
// config.js is gitignored; copy this file to config.js to test against a live stack.
//
// If GREEN_QA_API_URL is empty, apiClient.js short-circuits and the SPA renders from fixtures.

window.GREEN_QA_API_URL = '/api';   // same-origin behind CloudFront; 'http://localhost:7071/api' locally

// Cognito Hosted UI (PKCE). Omit entirely when the API runs with AUTH_MODE=disabled.
// window.GREEN_QA_AUTH = { region: 'eu-west-2', domain: 'zerocarb-dev-123456789012.auth.eu-west-2.amazoncognito.com', clientId: '<SpaClientId output>' };

// Pre-fills the Organization URL field in the Azure Configuration panel.
window.GREEN_QA_DEFAULT_ORG_URL = '';  // e.g. 'https://dev.azure.com/your-org'
