# Azure DevOps Integration & API-Driven Dashboard

Status: **complete — 19/19 E2E checks passing** · validated with Playwright (dev mode).

This document tracks the work that turns the Carbon Cost Dashboard from a
fixture-driven prototype into an **API-driven utility gated on a live Azure
DevOps (ADO) connection**. It is both the design note and the execution
checklist.

---

## 1. Decisions (locked)

| Decision | Choice |
|----------|--------|
| **PAT persistence** | **Backend-only.** PAT is sent once to `POST /api/ado/connect`, stored server-side (Azure Key Vault when configured, otherwise the backend DAL). The browser keeps only the Org URL + a `connected` flag — never the PAT. |
| **Clean slate** | **Lock the whole utility** until ADO is connected. Every tab shows a "Connect Azure DevOps to begin" empty state; only the Azure Configuration panel is usable until a successful connection. |
| **Testing connectivity** | **Dev/mock ADO mode.** With `ADO_DEV_MODE=true` the backend serves synthetic repos + pipelines and accepts any credentials, so the full happy path works offline and under automated E2E. Real Org URL + PAT hit live `dev.azure.com` in normal use. |

---

## 2. Architecture

```
Browser SPA (no-build, *.jsx)
  │  window.GREEN_QA_API_URL → http://localhost:7071/api
  ▼
local_server.py (WSGI shim)  ──imports──▶  function_app.py (Azure Functions)
                                              │
                                              ├─ /api/ado/connect    validate + persist
                                              ├─ /api/ado/status     connected? (no PAT)
                                              ├─ /api/ado/pipelines   repo-wise pipeline list
                                              ├─ /api/ado/disconnect  clear connection
                                              ├─ /api/carbon /overview /history /forecast …
                                              ▼
                                          ado_client.py  ──HTTPS──▶  dev.azure.com REST
                                          cosmos_dal.py  (ado_connections store; PAT here in dev)
```

### New backend surface

| Route | Method | Purpose |
|-------|--------|---------|
| `/api/ado/connect` | POST | Body `{org_url, pat}`. Validates against ADO, persists connection. Returns `{connected, organization, projects, repositories, pipelines}` or an error. |
| `/api/ado/status` | GET | Returns `{connected, organization, org_url, validated_at}`. Never returns the PAT. |
| `/api/ado/pipelines` | GET | Uses the stored PAT. Returns pipelines grouped by repository. |
| `/api/ado/disconnect` | POST | Clears the stored connection. |

### ADO REST calls used

- Projects: `GET https://dev.azure.com/{org}/_apis/projects?api-version=7.1`
- Build/YAML definitions (with repo): `GET https://dev.azure.com/{org}/{project}/_apis/build/definitions?api-version=7.1&includeAllProperties=true`
- A pipeline's `definition.id` is the same id `run_pipeline` already uses to trigger runs.

---

## 3. Execution checklist

### Backend
- [x] **B1** `ado_client.py`: `parse_org_url`, `validate_connection`, `list_projects`, `list_pipelines_grouped` (+ dev-mode synthetic data, 118 pipelines / 5 repos).
- [x] **B2** `cosmos_dal.py`: `ado_connections` store + `upsert_connection` / `get_connection` / `delete_connection` (in-memory fallback).
- [x] **B3** `function_app.py`: `/api/ado/{connect,status,pipelines,disconnect}` + `schemas.AdoConnectRequest`.
- [x] **B4** `local_server.py`: registered the four new routes.

### Frontend
- [x] **F1** `apiClient.js`: `adoConnect`, `adoStatus`, `adoPipelines`, `adoDisconnect`.
- [x] **F2** Azure Configuration panel (Org URL + PAT, Connect/Cancel, success/error). Entry beside Settings in the masthead.
- [x] **F3** `store.jsx`: real `azure` connection state driven by `/api/ado/status`; bootstraps on load.
- [x] **F4** Clean-slate gating: all tabs locked until connected; no preloaded data on first launch.
- [x] **F5** Pipelines tab API-driven: repo-wise grouping; real pipeline names; dropdown optimized for 100+ (search + grouping + lazy loading); history via `/api/history` with empty states.
- [x] **F6** Recommendation actions hidden when Home Region == Recommended Region; Apply Recommendation / Run Now / Re-route call `/api/decide` and show real-time status + raw API response.
- [x] **F7** Regions tab: column renamed to **"Intensity (gCO₂/kWh)"**, old separate intensity column merged in, **Clean %** removed; regions de-duplicated by code (duplicate-graph fix); Strategy Mix via `/api/overview`.
- [x] **F8** Glossary: item counts removed from section headers; search placeholder → **"Search"**.
- [x] **F9** Removed every `CCD_DATA` fixture fallback for operational data (ledger/regions/pipelines/overview). Static reference content (glossary copy) retained.
- [x] **F10** **Research** tab hidden via `CCD_FEATURES.research` flag; `research.jsx` retained and marked `PHASE-2`.

### Validation
- [x] **V1** Backend endpoint smoke tests (Invoke-RestMethod) in dev mode.
- [x] **V2** Playwright E2E (`scripts/e2e/e2e.mjs`): **19/19 passing** — clean slate → Azure Configuration → connect (dev) → 118 pipelines populate repo-wise → tabs unlock → dropdown search/grouping → real-time decide → regions/glossary changes → Research gone → no console errors.
- [x] **V3** Error path: an unparseable Org URL shows a clear error message.

### Transport fix (local dev)
`scripts/local_server.py` originally used `wsgiref`, which sent a wrong/zero
`Content-Length` to browsers (empty bodies) and, once set explicitly, a
**duplicate** `Content-Length` that strict HTTP/1.1 clients (browser fetch /
undici) rejected as "Failed to fetch". It was rewritten onto a hand-controlled
`http.server` handler (HTTP/1.1, single `Content-Length`, dual-stack IPv6+IPv4)
so GET and POST both frame correctly. This only affects the local dev shim; the
deployed Azure Functions host is unaffected.

### How to run the E2E suite
```powershell
# 1. Start servers in dev mode (synthetic ADO + seeded history)
$env:ADO_DEV_MODE = "true"; $env:DEV_SEED_ENABLED = "true"
.\scripts\run-local.ps1 -SkipInstall -StopFirst
# 2. In another shell, run the Playwright checks (uses installed Chromium)
node scripts\e2e\e2e.mjs    # screenshots land in scripts/e2e/shots/
```

---

## 4. Dev / run notes

```powershell
# Enable dev ADO mode + in-memory seeding, then launch both servers:
$env:ADO_DEV_MODE = "true"
.\scripts\run-local.ps1 -SkipInstall
```

In dev mode any Org URL + PAT "connects" and the backend returns a synthetic
multi-repo pipeline catalogue (100+ pipelines) so the dropdown optimisation and
repo-wise grouping are exercised.

---

## 5. Phase 2 (deferred)

- **Research tab** — hidden via feature flag (`window.CCD_FEATURES.research = false`),
  code retained in `research.jsx`, marked with `PHASE-2` banners. To re-enable,
  flip the flag and restore the TABS entry.
