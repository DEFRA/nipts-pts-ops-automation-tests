// Isolate tests from the developer's shell environment.
for (const key of Object.keys(process.env)) {
  if (/^(TABLE_|SECRET_ID_|COGNITO_|ADO_|AZURE_DEVOPS_|GREENQA_|ELECTRICITYMAPS|NESO_|ENERGY_CHARTS|DEV_SEED|AUTH_MODE|WEBHOOK_SECRET)/.test(key)) {
    delete process.env[key];
  }
}
process.env.APP_ENV = 'local';
process.env.LOG_LEVEL = 'silent';
