// Persistence port. Two adapters: DynamoDB (deployed) and in-memory (local dev / tests).

export type Item = Record<string, unknown>;

export interface CarbonSample extends Item {
  id: string;
  provider: string;
  region: string;
  sampled_at: string;
  grid_intensity_gco2_kwh: number;
  dc_intensity_gco2_kwh: number;
}

export interface ExecutionRecord extends Item {
  id: string;
  pipeline_id: string;
  provider: string;
  stored_at: string;
}

export interface DeferredRecord extends Item {
  id: string;
  status: string;
  defer_until_iso?: string;
}

export interface ConnectionRecord extends Item {
  organization?: string;
  org_url?: string;
  project?: string;
  validated_at?: string;
  source?: string;
  region?: string;
  access_key_hint?: string;
  account_id?: string;
}

export interface AuditEvent {
  actor: string;
  roles: string[];
  action: string;
  resource?: string;
  outcome: 'success' | 'failure';
  detail?: Item;
  request_id?: string;
  source_ip?: string;
}

export interface Repository {
  upsertCarbonSample(sample: CarbonSample): Promise<CarbonSample>;
  upsertExecution(execution: ExecutionRecord): Promise<ExecutionRecord>;
  upsertDeferred(deferred: DeferredRecord): Promise<DeferredRecord>;

  getDeferred(decisionId: string): Promise<DeferredRecord | null>;
  /** status=pending and defer_until_iso <= nowIso, oldest first. */
  listPendingDeferred(nowIso: string): Promise<DeferredRecord[]>;

  listExecutionsForPipeline(pipelineId: string, provider: string, limit: number): Promise<ExecutionRecord[]>;
  listAllExecutions(provider: string, limit: number): Promise<ExecutionRecord[]>;
  /** Executions with stored_at >= sinceIso (ISO date or timestamp), any order. */
  listExecutionsSince(provider: string, sinceIso: string): Promise<ExecutionRecord[]>;

  /** Most recent sample per region, for the given region codes. */
  latestCarbonByRegion(provider: string, regions: string[]): Promise<Record<string, CarbonSample>>;
  getLatestCarbon(provider: string, region: string): Promise<CarbonSample | null>;

  upsertConnection(connection: ConnectionRecord, id?: string): Promise<ConnectionRecord>;
  getConnection(id?: string): Promise<ConnectionRecord | null>;
  deleteConnection(id?: string): Promise<void>;

  putAudit(event: AuditEvent): Promise<void>;
  /** Liveness probe for /health. */
  ping(): Promise<void>;
}

export const CONNECTION_ID = 'ado-connection::default';
export const AWS_CONNECTION_ID = 'aws-connection::default';
