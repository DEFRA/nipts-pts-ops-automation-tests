# Testing — How to Verify the Platform Works

Tests sit at four levels. Run them in this order on every change:

| Level | Tool | Cadence | What it catches |
|---|---|---|---|
| **Unit** | pytest | every commit (pre-commit hook + CI) | Pure-function regressions in `green_qa_lib/*` |
| **Integration** | pytest + Cosmos emulator | CI | Function App routes + DAL behaviour |
| **Smoke** | bash + curl | post-deploy gate | The deployed stack actually serves traffic |
| **Load** | k6 | pre-prod / weekly | API latency under realistic concurrency |

Plus two ongoing safety nets:

- **Synthetic carbon tests** — run continuously in production, alert on
  regressions (`green_qa_lib/runtime_monitor.py` + timer trigger)
- **Chaos drill** — manual, monthly, validates circuit breaker + fallback chain

---

## 1 · Unit tests

Located in `tests/unit/`. Pure-Python, no network, no Azure SDK. Fast
(<2 s total on a laptop).

```bash
make install-test     # one-time: pip install -r requirements-test.txt
make test-unit        # = pytest tests/unit/ -v
```

Covered modules (`tests/unit/test_*.py`):

| Test file | What it asserts |
|---|---|
| `test_carbon_budget.py` | Budget rule precedence, PASS/WARN/FAIL transitions, per-txn vs per-run |
| `test_forecaster.py` | Holt-Winters smoothing, conformal prediction interval width |
| `test_maizx_scorer.py` | Weight sum invariant, normalisation, paper-aligned scoring |
| `test_sci_calculator.py` | SCI = (E·I + M) / R formula, PUE applied once, embodied component |
| `test_teads_calculator.py` | Load-proportional TDP, idle floor (12 %), per-family TDP table |
| `test_test_reporter.py` | JUnit XML → carbon-annotated report round-trip |

### Coverage

```bash
make test-cov
# Generates coverage_html/ — open coverage_html/index.html
# Target: > 80 % line coverage on green_qa_lib/* and lambda/api/handler.py
```

### Adding a new unit test

1. New file in `tests/unit/test_<module>.py`
2. Use `freezegun` for time-dependent code, `responses` for HTTP mocks
3. Avoid touching the network — if you need a fixture response, drop a JSON
   under `tests/fixtures/` and load it
4. Don't import Azure SDKs in `green_qa_lib/*` — keep the core library
   cloud-agnostic

---

## 2 · Integration tests

Located in `tests/integration/`. These exercise the **Function App** end-to-end:
HTTP in → decision_service → cosmos_dal → response out. They use the
**Cosmos DB Linux emulator** running in Docker.

```bash
# Start the Cosmos emulator (one-time per session)
docker compose up -d cosmos

# Wait ~30 s for the emulator to boot
docker compose logs -f cosmos     # ctrl-C when you see "Started"

# Run integration tests
make test-integration
```

What's covered:

- `POST /api/decide` round-trip for each of the 4 gate outcomes
- `POST /api/calculate` produces SCI matching the reference Python in §1.4
- `POST /api/budget/check` PASS/WARN/FAIL with mocked actuals
- `GET /api/history` returns paginated rows after writes
- Timer trigger `ingest_carbon` writes one row per EU region
- Circuit breaker opens after N upstream failures and serves cached data

The fixture set in `tests/fixtures/` mocks the external APIs so integration
tests don't depend on UK Grid ESO availability.

---

## 3 · Smoke tests (post-deploy)

The script that **every deployment** must pass before being marked healthy.
Lives at `scripts/smoke-test.sh` (add this if absent — template below).

```bash
#!/usr/bin/env bash
# Usage: ./scripts/smoke-test.sh <env>
set -euo pipefail

ENV=${1:-prod}
RG=rg-greenqa-$ENV
FUNC=$(az deployment group show -g $RG -n main \
        --query 'properties.outputs.functionAppName.value' -o tsv)
KEY=$(az functionapp keys list -g $RG -n $FUNC \
        --query 'functionKeys.default' -o tsv)
URL="https://$FUNC.azurewebsites.net/api"

echo "→ Smoke testing $URL"

# 1. /api/carbon returns live data for all 7 EU regions
LIVE_COUNT=$(curl -fs "$URL/carbon?code=$KEY" \
              | jq '[.[] | select(.is_live == true)] | length')
[[ $LIVE_COUNT -ge 1 ]] || { echo "✗ no live carbon data"; exit 1; }
echo "✓ /api/carbon → $LIVE_COUNT live regions"

# 2. /api/decide returns a valid gate decision
DECISION=$(curl -fsX POST "$URL/decide?code=$KEY" \
  -H 'Content-Type: application/json' \
  -d '{"pipeline":"smoke","home_region":"eu-west-2","vcpu":2,
       "memory_gb":4,"duration_min":10,"criticality":"normal"}' \
  | jq -r '.action')
[[ "$DECISION" =~ ^(RUN_NOW_DEFAULT|RUN_NOW_OPTIMAL|WAIT_FOR_WINDOW|FALLBACK_DEFAULT)$ ]] \
  || { echo "✗ /api/decide returned $DECISION"; exit 1; }
echo "✓ /api/decide → $DECISION"

# 3. /api/calculate produces an SCI value
SCI=$(curl -fsX POST "$URL/calculate?code=$KEY" \
  -H 'Content-Type: application/json' \
  -d '{"region":"eu-west-2","vcpu":2,"memory_gb":4,"duration_min":10,"transaction_count":100}' \
  | jq -r '.sci_g_per_transaction')
[[ -n "$SCI" && "$SCI" != "null" ]] || { echo "✗ /api/calculate empty"; exit 1; }
echo "✓ /api/calculate → ${SCI} gCO₂/txn"

# 4. /api/budget/check returns PASS/WARN/FAIL
VERDICT=$(curl -fsX POST "$URL/budget/check?code=$KEY" \
  -H 'Content-Type: application/json' \
  -d '{"pipeline":"smoke","actual_gco2":5.0,"transaction_count":100,
       "budget_gco2_per_transaction":0.30,"warn_at_percent":80}' \
  | jq -r '.verdict')
[[ "$VERDICT" =~ ^(PASS|WARN|FAIL)$ ]] \
  || { echo "✗ /api/budget/check returned $VERDICT"; exit 1; }
echo "✓ /api/budget/check → $VERDICT"

echo "All smoke checks passed."
```

CI wires this into the deploy job:

```yaml
- name: Smoke
  run: ./scripts/smoke-test.sh ${{ matrix.env }}
  # If this fails, the previous slot stays live — no traffic is shifted.
```

---

## 4 · Load tests

Run before any new region rollout or major version bump. Tool: `k6`.

```bash
brew install k6        # or: choco install k6
k6 run loadtest/carbon-gate.js
```

Reference script (`loadtest/carbon-gate.js`, add to repo if missing):

```javascript
import http from 'k6/http';
import { check, sleep } from 'k6';

export const options = {
  scenarios: {
    sustained_200rps: {
      executor: 'constant-arrival-rate',
      rate: 200, timeUnit: '1s', duration: '5m',
      preAllocatedVUs: 50, maxVUs: 200,
    },
  },
  thresholds: {
    http_req_duration: ['p(95)<800', 'p(99)<1500'],
    http_req_failed:   ['rate<0.001'],
  },
};

const URL = __ENV.API_URL + '/decide?code=' + __ENV.API_KEY;
const PAYLOAD = JSON.stringify({
  pipeline: 'load-' + __VU,
  home_region: 'eu-west-2',
  vcpu: 4, memory_gb: 8, duration_min: 15,
  criticality: 'normal',
});

export default function () {
  const r = http.post(URL, PAYLOAD, { headers: { 'Content-Type': 'application/json' } });
  check(r, { '200': (x) => x.status === 200 });
  sleep(0.1);
}
```

Acceptance:

- p95 < 800 ms
- p99 < 1 500 ms
- error rate < 0.1 %

The Y1 Consumption plan should scale to ~5 instances at 200 RPS. If you
exceed 400 RPS sustained, move to EP1 (Elastic Premium).

---

## 5 · Synthetic carbon tests (production safety net)

Every consumer pipeline spawns one synthetic test per registered pipeline,
running every `polling.background_test_minutes` (default 5 min). See
`green_qa_lib/runtime_monitor.py`.

Each synthetic test asserts one of:

| Assertion | Catches |
|---|---|
| `region.intensity < 200 gCO₂/kWh` | Pipeline drifted into a dirty region |
| `budget.headroom > 15 %` | Pipeline trending toward budget breach |
| `recommendation == current_region` | MAIZX would now recommend rerouting |

A failed assertion **does not fail the consumer pipeline** — it raises an
alert and writes the delta to `pipeline_analytics`.

### Manually triggering a synthetic failure

Useful for demoing the alerting path:

```bash
curl -X POST "$URL/pipelines/auth-service-ci/inject?code=$KEY" \
  -H 'Content-Type: application/json' \
  -d '{"current_g": 99, "reason": "test-injection"}'
# Within 60 s, the dashboard's synthetic test flips FAIL and an alert fires.
```

---

## 6 · Chaos drill (monthly)

Schedule once a month, on-call drives. The aim is to confirm fallback
behaviour rather than break production — these tests are designed to be safe
to run during business hours.

### Drill 1 — ElectricityMaps unreachable

```bash
# Add a network restriction blocking the EM hostname for 5 minutes
az functionapp config access-restriction add \
  -g $RG -n $FUNC --rule-name block-em --action Deny \
  --priority 100 --service-tag Internet
# Wait 5 min; check /api/carbon. Expect: source = "live_eso" for GB,
# source = "live_ember" for other zones (Ember fallback active).
```

Pass criteria:

- No `5xx` responses on `/api/decide` during the outage
- `source` field flips to `live_ember` or `synthetic` (with `is_live=false`)
- App Insights logs the circuit-breaker open event
- Breaker closes within 10 min of restoring access

### Drill 2 — Cosmos DB throttled

Provision a 400 RU/s container (instead of serverless) for the drill and
saturate it. Confirm:

- Gate decisions continue (in-memory MAIZX still works)
- Writes are queued to Storage Queue
- Backlog drains automatically when throughput returns

### Drill 3 — Key Vault unavailable

Disable the KV firewall briefly. Confirm:

- Function App **keeps serving** for cache TTL (5 min) from the cached
  ElectricityMaps token
- After cache expires, `/api/carbon` returns `synthetic` source with
  `is_live=false`
- `KeyVaultSecretUnreadable` alert fires within 5 min

---

## 7 · CI configuration

Reference GitHub Actions job. Adapt to your CI of choice.

```yaml
name: green-qa CI

on: [push, pull_request]

jobs:
  lint-and-unit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.11' }
      - run: pip install -r requirements-test.txt
      - run: make lint
      - run: make test-unit
      - run: make test-cov
      - uses: actions/upload-artifact@v4
        with: { name: coverage, path: coverage_html/ }

  integration:
    runs-on: ubuntu-latest
    services:
      cosmos:
        image: mcr.microsoft.com/cosmosdb/linux/azure-cosmos-emulator:latest
        ports: [ "8081:8081", "10251:10251", "10252:10252", "10253:10253", "10254:10254" ]
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: '3.11' }
      - run: pip install -r requirements-test.txt azure-functions azure-cosmos
      - run: make test-integration
        env:
          COSMOS_ENDPOINT: https://localhost:8081
          COSMOS_KEY: C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==

  smoke:
    needs: [lint-and-unit, integration]
    if: github.ref == 'refs/heads/main'
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: azure/login@v2
        with: { creds: ${{ secrets.AZURE_CREDENTIALS }} }
      - run: ./scripts/smoke-test.sh staging
```

The matrix gates production deploys on green smoke against staging.

---

## 8 · Manual acceptance checklist (one-time, per environment)

Before declaring an environment "ready", walk through these by hand:

- [ ] `make test-unit` passes locally
- [ ] `make test-integration` passes against the Cosmos emulator
- [ ] `./scripts/smoke-test.sh <env>` returns all ✓
- [ ] Dashboard loads at SWA URL; **DEMO DATA** badge visible
- [ ] `/api/carbon` returns ≥ 1 region with `is_live=true`
- [ ] Force one synthetic test failure; alert lands within 60 s
- [ ] Force KV unreachable for 6 min; cached token still serves requests for 5 min, then falls to synthetic
- [ ] Rotate the function default key; smoke script still passes after updating CI secret
- [ ] Two consecutive deploys complete in < 5 min each (no schema drift)

When all 9 are green, file the env as **certified** in the operations
runbook.
