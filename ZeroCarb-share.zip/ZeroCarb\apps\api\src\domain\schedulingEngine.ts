import { REGION_INTENSITY_GCO2_KWH, type Criticality, type Strategy } from './constants';
import type { ForecastPeriod } from './carbonApi';
import { getProvider, type Provider } from './providers';
import { round } from './sci';

export interface SchedulingDecision {
  recommended_strategy: Strategy;
  target_region: string;
  current_intensity: number;
  target_intensity: number;
  carbon_savings_percent: number;
  scheduled_time: Date | null;
  wait_hours: number;
  decision_reason: string;
}

export interface EngineOptions {
  config?: Record<string, string>;
  provider?: string;
  allowedRegions?: string[] | null;
  regionIntensities?: Record<string, number>;
  regionForecasts?: Record<string, ForecastPeriod[]>;
}

const num = (v: string | undefined, fallback: number): number => {
  const n = Number.parseFloat(v ?? '');
  return Number.isFinite(n) ? n : fallback;
};

/**
 * Deterministic carbon-aware scheduling: hybrid > space shift > time shift > run now,
 * each gated by MIN_SAVINGS_PERCENT. Critical pipelines never shift.
 */
export class SchedulingEngine {
  private readonly provider: Provider;
  private readonly allowedRegions: string[] | null;
  private readonly regionIntensities: Record<string, number>;
  private readonly regionForecasts: Record<string, ForecastPeriod[]>;
  private readonly minSavingsPct: number;
  private readonly maxDeferHours: number;
  private readonly allowHybrid: boolean;

  constructor(opts: EngineOptions = {}) {
    const config = opts.config ?? {};
    this.provider = getProvider(opts.provider || 'azure');
    this.allowedRegions = opts.allowedRegions?.length ? [...opts.allowedRegions] : null;
    this.regionIntensities = { ...(opts.regionIntensities ?? {}) };
    this.regionForecasts = { ...(opts.regionForecasts ?? {}) };
    this.minSavingsPct = num(config.MIN_SAVINGS_PERCENT, 10);
    this.maxDeferHours = num(config.MAX_DEFER_HOURS, 12);
    this.allowHybrid = String(config.ALLOW_HYBRID ?? 'true').toLowerCase() === 'true';
  }

  getOptimalStrategy(pipelineName: string, currentRegion: string, criticality: Criticality = 'normal'): SchedulingDecision {
    void pipelineName;
    const currentIntensity = this.intensityFor(currentRegion);
    const [cleanestCode, cleanestIntensity] = this.cleanestRegion();

    if (criticality === 'critical') {
      return {
        recommended_strategy: 'run_now', target_region: currentRegion,
        current_intensity: currentIntensity, target_intensity: currentIntensity,
        carbon_savings_percent: 0, scheduled_time: null, wait_hours: 0,
        decision_reason: 'Criticality=CRITICAL — run immediately, no shifting allowed.',
      };
    }

    const savingsSpace = this.savingsPct(currentIntensity, cleanestIntensity);
    const [waitHours, forecastIntensity] = this.forecastWindow(currentRegion, currentIntensity);
    const savingsTime = this.savingsPct(currentIntensity, forecastIntensity);

    const canSpace = savingsSpace >= this.minSavingsPct && cleanestCode !== currentRegion;
    const canTime = savingsTime >= this.minSavingsPct && waitHours > 0;

    if (this.allowHybrid && canSpace && canTime && criticality === 'low') {
      const combined = round(Math.min(cleanestIntensity, forecastIntensity), 3);
      return {
        recommended_strategy: 'hybrid', target_region: cleanestCode,
        current_intensity: currentIntensity, target_intensity: combined,
        carbon_savings_percent: this.savingsPct(currentIntensity, combined),
        scheduled_time: new Date(Date.now() + waitHours * 3_600_000), wait_hours: waitHours,
        decision_reason: `HYBRID: shift to ${cleanestCode} AND wait ${waitHours.toFixed(1)}h for forecast minimum.`,
      };
    }

    if (canSpace && savingsSpace >= savingsTime) {
      return {
        recommended_strategy: 'space_shift', target_region: cleanestCode,
        current_intensity: currentIntensity, target_intensity: cleanestIntensity,
        carbon_savings_percent: savingsSpace, scheduled_time: null, wait_hours: 0,
        decision_reason: `SPACE_SHIFT: ${cleanestCode} is ${savingsSpace.toFixed(1)}% cleaner (${cleanestIntensity.toFixed(0)} vs ${currentIntensity.toFixed(0)} gCO2/kWh).`,
      };
    }

    if (canTime) {
      return {
        recommended_strategy: 'time_shift', target_region: currentRegion,
        current_intensity: currentIntensity, target_intensity: forecastIntensity,
        carbon_savings_percent: savingsTime,
        scheduled_time: new Date(Date.now() + waitHours * 3_600_000), wait_hours: waitHours,
        decision_reason: `TIME_SHIFT: forecast ${savingsTime.toFixed(1)}% drop in ${waitHours.toFixed(1)}h; defer in-region.`,
      };
    }

    return {
      recommended_strategy: 'run_now', target_region: currentRegion,
      current_intensity: currentIntensity, target_intensity: currentIntensity,
      carbon_savings_percent: 0, scheduled_time: null, wait_hours: 0,
      decision_reason: `RUN_NOW: no shift clears the ${this.minSavingsPct.toFixed(0)}% savings threshold (best space=${savingsSpace.toFixed(1)}%, best time=${savingsTime.toFixed(1)}%).`,
    };
  }

  private intensityFor(region: string): number {
    const live = this.regionIntensities[region];
    if (typeof live === 'number' && live > 0) return live;
    return REGION_INTENSITY_GCO2_KWH[region] ?? 300;
  }

  /** Cleanest region the workload may actually be scheduled onto. */
  private cleanestRegion(): [string, number] {
    let candidates = this.provider.listRegions().map((r) => r.code);
    if (this.allowedRegions) candidates = candidates.filter((c) => this.allowedRegions!.includes(c));
    if (!candidates.length) return ['', 300];
    // Array.sort is stable, matching the catalogue-order tie-break of the original.
    const best = [...candidates].sort((a, b) => this.intensityFor(a) - this.intensityFor(b))[0];
    return [best, this.intensityFor(best)];
  }

  private savingsPct(base: number, candidate: number): number {
    if (base <= 0) return 0;
    return round(Math.max(0, ((base - candidate) / base) * 100), 2);
  }

  /** Cheapest hour inside the defer window; (0, current) when no forecast exists. */
  private forecastWindow(region: string, currentIntensity: number): [number, number] {
    let bestWait = 0;
    let bestIntensity = currentIntensity;
    for (const p of this.regionForecasts[region] ?? []) {
      const { hour, intensity_gco2_kwh: value } = p;
      if (typeof hour !== 'number' || typeof value !== 'number') continue;
      if (hour <= 0 || hour > this.maxDeferHours) continue;
      if (value < bestIntensity) {
        bestWait = hour;
        bestIntensity = value;
      }
    }
    return [bestWait, bestIntensity];
  }
}
