# External APIs — Full Inventory

Every third-party HTTP endpoint the platform calls, what it's used for, how
it authenticates, what its rate limits and failure modes are, and what we do
when it's down.

If you add a new external dependency, **add a row here in the same PR.**

---

## 1 · Carbon-intensity sources

### 1.1 UK Grid ESO (National Grid) — primary for GB

| Property | Value |
|---|---|
| **Vendor** | National Grid Electricity System Operator |
| **Base URL** | `https://api.carbonintensity.org.uk` |
| **Auth** | None (public) |
| **Rate limit** | None published; we throttle to 1 req / 5 min via in-process cache |
| **Update cadence** | Every 30 min |
| **Coverage** | Great Britain only |
| **Used by** | `green_qa_lib/eu_carbon_api.py::_fetch_uk_eso()` + `_fetch_uk_eso_forecast_48h()` |

**Endpoints we call**

```
GET /intensity                    → current carbon intensity (gCO₂/kWh)
GET /intensity/date               → 30-min forecast slots for today (48 rows)
GET /generation                   → current generation mix (used by excess_power.py)
```

**Sample response (`/intensity`)**

```json
{ "data": [ { "from": "2026-05-21T11:30Z", "to": "2026-05-21T12:00Z",
              "intensity": { "actual": 182, "forecast": 175, "index": "moderate" } } ] }
```

**Failure mode** — `urllib` timeout (8 s) → returns `None` → fallback to
ElectricityMaps.

---

### 1.2 ElectricityMaps — primary for non-GB EU zones

| Property | Value |
|---|---|
| **Vendor** | Tomorrow ApS (electricitymaps.com) |
| **Base URL** | `https://api.electricitymap.org/v3` |
| **Auth** | `auth-token: <token>` header. Get a free key at electricitymaps.com |
| **Env var** | `ELECTRICITYMAPS_TOKEN` (`ELECTRICITY_MAPS_TOKEN` also accepted) |
| **Rate limit** | Free tier ≈ 50 req/day per zone; paid tiers higher |
| **Update cadence** | Every few minutes |
| **Coverage** | Global (FR, DE, IE, IT-NO, ES, SE, NL, etc.) |
| **Used by** | `green_qa_lib/eu_carbon_api.py::_fetch_electricitymaps()` |

**Endpoints we call**

```
GET /carbon-intensity/latest?zone={zone}    → live gCO₂/kWh for a zone
```

**Failure mode** — if token is missing OR request fails, falls through to
Ember Climate.

---

### 1.3 Ember Climate — fallback for any country

| Property | Value |
|---|---|
| **Vendor** | Ember Climate (ember-climate.org) |
| **Base URL** | `https://api.ember-energy.org/v1` |
| **Auth** | None for `/latest` queries |
| **Rate limit** | None published; we hit once per cache miss |
| **Update cadence** | Hourly / monthly aggregates |
| **Used by** | `green_qa_lib/eu_carbon_api.py::_fetch_ember()` |

**Endpoints we call**

```
GET /carbon-intensity/latest?entity={country_code}&is_most_recent=true
```

**Failure mode** — returns `None` → fall through to synthetic baseline
(per-region constants in `EU_REGIONS`).

---

### 1.4 Synthetic baseline (always available)

Not an external API — a deterministic fallback built into `eu_carbon_api.py`.
Returns the `fallback` value per region with a sinusoidal diurnal pattern
(`_synthetic_forecast()`).

Responses carry `source: "synthetic"` and `is_live: false` so consumers can
flag them in the UI.

---

## 2 · Cloud provider APIs

### 2.1 Azure DevOps REST

| Property | Value |
|---|---|
| **Vendor** | Microsoft Azure DevOps Services |
| **Base URL** | `https://dev.azure.com/{org}/{project}/_apis` |
| **Auth** | PAT (Personal Access Token) → stored in Key Vault as `ado-pat` |
| **Env var** | `ADO_PAT` (only at deploy time; runtime fetches from KV) |
| **Used by** | `azure/functions/ado_client.py::run_pipeline()` |

**Endpoints we call**

```
POST  /pipelines/{pipelineId}/runs?api-version=7.1   → trigger a pipeline run
GET   /pipelines/{pipelineId}/runs/{runId}?…         → poll run status
POST  /git/repositories/{repoId}/pullrequests        → file `Apply recommendation` PR (planned)
```

**Failure mode** — circuit breaker after 5 consecutive 5xx → mark recommendation
as `MANUAL_INTERVENTION_REQUIRED` in the dashboard.

---

### 2.2 Azure DevOps Service Hooks (inbound)

Not strictly an API we call — ADO posts to **our** webhook:

```
POST /api/ingest-ado-event   ← function_app.py::ingest_ado_event
```

Signature validation via `ADO_WEBHOOK_SECRET` env var. Webhook receives
`build.complete`, `release.deployed`, etc.

---

### 2.3 AWS CodePipeline (legacy / dual-cloud)

Only used in the AWS deployment path (`lambda/api/handler.py`). Authenticated
via standard AWS SDK credential chain (env vars / IAM role / SSO).

| Action | API |
|---|---|
| List pipelines | `codepipeline:ListPipelines` |
| Trigger | `codepipeline:StartPipelineExecution` |
| Watch | EventBridge `aws.codepipeline` rule → `pipeline_monitor` Lambda |

---

## 3 · Internal REST API (this platform exposes)

These are our **own** endpoints — listed here so frontend and integration
engineers have one place to look.

Hosted by `azure/functions/function_app.py` (Linux Consumption Y1) and
mirrored by `lambda/api/handler.py` (AWS path).

| Method | Path | Purpose |
|---|---|---|
| POST | `/api/decide` | Pre-run gate: returns `RUN_NOW_DEFAULT` / `RUN_NOW_OPTIMAL` / `WAIT_FOR_WINDOW` / `FALLBACK_DEFAULT` |
| POST | `/api/store_result` | Persist actual carbon cost of a completed run |
| POST | `/api/calculate` | Compute SCI for a run spec without storing |
| POST | `/api/budget/check` | Carbon budget enforcement → `PASS` / `WARN` / `FAIL` |
| GET | `/api/history?limit=&pipeline=` | Paginated execution history |
| GET | `/api/carbon` | Latest carbon intensity for all configured regions |
| POST | `/api/ingest-ado-event` | ADO Service Hooks webhook sink |
| Timer | `ingest_carbon` (every 30 min) | Refresh carbon intensity from upstream APIs |
| Timer | `resume_deferred` (every 5 min) | Re-evaluate TIME_SHIFT runs whose window arrived |

Function-level auth is on by default (`AuthLevel.FUNCTION`). Call with
`?code={functionKey}` or the `x-functions-key` header. **For production
this should be replaced with Entra ID auth + per-team scopes** — see
`GAPS.md` §C.2.

Full request/response shapes are in the repo's `CLAUDE.md` under "REST API
Endpoints".

---

## 4 · Optional integrations (not enabled by default)

| Integration | Used for | Status |
|---|---|---|
| **WattTime** | US-region intensity | `.env.example` has the placeholder, not wired |
| **Slack Webhooks** | Carbon-aware delay messages | Slack scheduler builds the message, sending is up to the consumer |
| **PagerDuty** | Critical alerts | Mentioned in `OPERATIONS.md`; not in the Bicep yet |
| **MS Teams Connector** | Weekly digests | Modal supports it in UX; backend not implemented |

---

## 5 · Egress allow-list (for restricted Azure networks)

If your subscription forces all egress through a firewall, allow these FQDNs:

```
api.carbonintensity.org.uk            # UK Grid ESO
api.electricitymap.org                # ElectricityMaps
api.ember-energy.org                  # Ember Climate
dev.azure.com                         # Azure DevOps REST
{your-cosmos-account}.documents.azure.com
{your-kv-name}.vault.azure.net
dc.services.visualstudio.com          # App Insights ingestion
*.in.applicationinsights.azure.com    # App Insights ingestion (regional)
```

The fetcher uses Python's `urllib` with an 8-second timeout and disables
hostname verification (`ssl.CERT_NONE`) — review and tighten this for
zero-trust environments. See `eu_carbon_api.py::_http_get()`.
