/* eslint-env browser */
// =======================================================================
// auth — Amazon Cognito Hosted UI sign-in (OAuth 2.0 authorization code + PKCE).
//
// Enabled when the deployed config.js defines:
//   window.GREEN_QA_AUTH = { region, domain, clientId }
// When it is absent (local dev against AUTH_MODE=disabled) every call is a no-op.
//
// Tokens live in sessionStorage only (cleared when the tab closes). The SPA sends the
// ACCESS token as a Bearer credential; API roles come from its cognito:groups claim.
// =======================================================================
(function () {
  'use strict';

  const cfg = window.GREEN_QA_AUTH;
  const STORE = 'ccd.auth';
  const PKCE = 'ccd.auth.pkce';
  const enabled = !!(cfg && cfg.domain && cfg.clientId);

  const redirectUri = () => location.origin + '/';
  const endpoint = (p) => 'https://' + cfg.domain + p;

  function b64url(bytes) {
    let s = '';
    new Uint8Array(bytes).forEach((b) => { s += String.fromCharCode(b); });
    return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  function randomString(len) {
    const a = new Uint8Array(len);
    crypto.getRandomValues(a);
    return b64url(a);
  }

  function load() {
    try { return JSON.parse(sessionStorage.getItem(STORE) || 'null'); } catch (_) { return null; }
  }

  function save(tokens) {
    const prev = load() || {};
    const t = {
      access_token: tokens.access_token,
      // A refresh grant does not return a new refresh token.
      refresh_token: tokens.refresh_token || prev.refresh_token,
      expires_at: Date.now() + (tokens.expires_in || 3600) * 1000
    };
    sessionStorage.setItem(STORE, JSON.stringify(t));
    return t;
  }

  async function tokenRequest(params) {
    const resp = await fetch(endpoint('/oauth2/token'), {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(Object.assign({ client_id: cfg.clientId }, params)).toString()
    });
    if (!resp.ok) throw new Error('token_request_failed_' + resp.status);
    return resp.json();
  }

  async function login() {
    const verifier = randomString(48);
    const state = randomString(16);
    const challenge = b64url(await crypto.subtle.digest('SHA-256', new TextEncoder().encode(verifier)));
    sessionStorage.setItem(PKCE, JSON.stringify({ verifier, state, returnTo: location.hash || '' }));
    const q = new URLSearchParams({
      response_type: 'code',
      client_id: cfg.clientId,
      redirect_uri: redirectUri(),
      scope: 'openid email profile',
      code_challenge_method: 'S256',
      code_challenge: challenge,
      state
    });
    location.replace(endpoint('/oauth2/authorize?' + q.toString()));
  }

  async function handleRedirect() {
    const q = new URLSearchParams(location.search);
    if (!q.get('code')) return;
    const saved = JSON.parse(sessionStorage.getItem(PKCE) || 'null');
    sessionStorage.removeItem(PKCE);
    // Drop the one-time code from the address bar regardless of outcome.
    history.replaceState(null, '', location.pathname + (saved && saved.returnTo ? saved.returnTo : location.hash));
    if (!saved || saved.state !== q.get('state')) return;
    save(await tokenRequest({
      grant_type: 'authorization_code',
      code: q.get('code'),
      redirect_uri: redirectUri(),
      code_verifier: saved.verifier
    }));
  }

  async function getToken() {
    if (!enabled) return null;
    await ready;
    let t = load();
    if (t && t.expires_at - Date.now() > 60000) return t.access_token;
    if (t && t.refresh_token) {
      try {
        t = save(await tokenRequest({ grant_type: 'refresh_token', refresh_token: t.refresh_token }));
        return t.access_token;
      } catch (_) { sessionStorage.removeItem(STORE); }
    }
    login();
    return null;
  }

  function logout() {
    if (!enabled) return;
    sessionStorage.removeItem(STORE);
    const q = new URLSearchParams({ client_id: cfg.clientId, logout_uri: redirectUri() });
    location.replace(endpoint('/logout?' + q.toString()));
  }

  const ready = !enabled ? Promise.resolve() : handleRedirect().catch(function () { sessionStorage.removeItem(STORE); }).then(function () {
    if (!load()) return login();
  });

  window.greenQaAuth = { enabled, ready, getToken, login, logout };
})();
