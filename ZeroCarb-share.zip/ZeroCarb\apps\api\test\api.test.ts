import request from 'supertest';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { createApp } from '../src/app';
import type { TokenVerifier } from '../src/http/auth';
import { setSecretStore, MemorySecretStore } from '../src/lib/secrets';
import { MemoryRepository } from '../src/repo/memory';

let repo: MemoryRepository;
beforeEach(() => { repo = new MemoryRepository(); setSecretStore(new MemorySecretStore()); });
afterEach(() => { vi.unstubAllGlobals(); delete process.env.DEV_SEED_ENABLED; delete process.env.WEBHOOK_SECRET; });

const local = () => createApp({ repo, mode: 'disabled' });

describe('contract (auth disabled)', () => {
  it('serves health without auth', async () => {
    const res = await request(local()).get('/api/health?deep=1');
    expect(res.status).toBe(200);
    expect(res.body.checks.repository).toBe('ok');
  });

  it('POST /decide validates input', async () => {
    const app = local();
    expect((await request(app).post('/api/decide').send({})).body.error).toBe('pipeline_id is required');
    expect((await request(app).post('/api/decide').set('Content-Type', 'application/json').send('{bad')).status).toBe(400);
    const ok = await request(app).post('/api/decide').send({ pipeline_id: 'p', run_id: 'r', current_region: 'uksouth' });
    expect(ok.status).toBe(200);
    expect(ok.body).toMatchObject({ decision: expect.any(String), selected_region: expect.any(String) });
  });

  it('store_result then history round-trips', async () => {
    const app = local();
    const bad = await request(app).post('/api/store_result').send({ run_id: 'r' });
    expect(bad.status).toBe(400);
    const res = await request(app).post('/api/store_result').send({ pipeline_id: 'p1', run_id: 'r1', region: 'uksouth', status: 'Succeeded', duration_seconds: 60, vcpu_count: 2, memory_gb: 4, actual_carbon_g: 3 });
    expect(res.body).toEqual({ stored: true, id: 'p1::r1' });
    const hist = await request(app).get('/api/history?pipeline_id=p1');
    expect(hist.body.items).toHaveLength(1);
    expect((await request(app).get('/api/history')).status).toBe(400);
  });

  it('POST /calculate and /budget/check', async () => {
    const app = local();
    const calc = await request(app).post('/api/calculate').send({ region: 'uksouth', duration_seconds: 3600, vcpu_count: 2, memory_gb: 4 });
    expect(calc.status).toBe(200);
    expect(calc.body.carbon_emissions_g).toBeGreaterThan(0);
    expect((await request(app).post('/api/calculate').send({ duration_seconds: 0 })).status).toBe(400);
    const budget = await request(app).post('/api/budget/check').send({ actual_gco2: 120, budget_gco2_per_run: 100 });
    expect(budget.body).toMatchObject({ status: 'fail', passed: false });
  });

  it('GET /carbon returns the catalogue with baseline fallbacks', async () => {
    const res = await request(local()).get('/api/carbon?provider=azure');
    expect(res.body.regions.length).toBe(12);
    expect(res.body.execution_regions).toEqual(['uksouth', 'ukwest']);
    expect(res.body.regions[0].source).toBe('baseline');
    expect((await request(local()).get('/api/carbon?provider=nope')).status).toBe(400);
  });

  it('GET /forecast returns 24 hourly points', async () => {
    const res = await request(local()).get('/api/forecast?region=westeurope');
    expect(res.body.periods).toHaveLength(24);
    expect(res.body.source).toBe('modelled');
  });

  it('seeds data that /overview aggregates', async () => {
    const app = local();
    expect((await request(app).post('/api/dev/seed')).status).toBe(403);
    process.env.DEV_SEED_ENABLED = 'true';
    const seeded = await request(app).post('/api/dev/seed?days=3&per_day=2');
    expect(seeded.body.executions_inserted).toBe(30);
    const ov = await request(app).get('/api/overview?days=3');
    expect(ov.body.totals.runs).toBeGreaterThan(0);
    expect(ov.body.trend_30d).toHaveLength(3);
    expect(ov.body.strategy_mix).toHaveLength(4);
  });

  it('ado endpoints require a connection', async () => {
    const app = local();
    expect((await request(app).get('/api/ado/status')).body.connected).toBe(false);
    expect((await request(app).get('/api/ado/pipelines')).status).toBe(409);
    expect((await request(app).post('/api/ado/run').send({ pipeline_id: '1', region: 'uksouth' })).status).toBe(409);
    expect((await request(app).post('/api/ado/run').send({ pipeline_id: '1', region: 'northeurope' })).body.error).toBe('region_not_executable');
  });

  it('connects to ADO, stores the PAT outside the table and never echoes it', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({ count: 3, value: [] }))));
    const app = local();
    const res = await request(app).post('/api/ado/connect').send({ org_url: 'https://dev.azure.com/acme', pat: 'secret-pat' });
    expect(res.body).toMatchObject({ connected: true, organization: 'acme', projects: 3 });
    expect(JSON.stringify(res.body)).not.toContain('secret-pat');
    expect(JSON.stringify(await repo.getConnection())).not.toContain('secret-pat');
    const status = await request(app).get('/api/ado/status');
    expect(status.body).toMatchObject({ connected: true, organization: 'acme' });
    expect(JSON.stringify(status.body)).not.toContain('secret-pat');
    expect((await request(app).post('/api/ado/disconnect')).body.connected).toBe(false);
    expect((await request(app).get('/api/ado/status')).body.connected).toBe(false);
    expect(repo.audit.map((a) => a.action)).toEqual(['ado.connect', 'ado.disconnect']);
  });

  it('maps a rejected PAT to 401', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('', { status: 203 })));
    const res = await request(local()).post('/api/ado/connect').send({ org_url: 'acme', pat: 'bad' });
    expect(res.status).toBe(401);
    expect(res.body.connected).toBe(false);
  });
});

describe('authentication and RBAC', () => {
  const verifier: TokenVerifier = {
    async verify(token) {
      if (token === 'viewer') return { sub: 'u1', 'cognito:groups': ['viewer'] };
      if (token === 'operator') return { sub: 'u2', 'cognito:groups': ['operator'] };
      if (token === 'admin') return { sub: 'u3', 'cognito:groups': ['admin'] };
      if (token === 'machine') return { sub: 'c1', scope: 'greenqa/pipeline' };
      throw new Error('invalid');
    },
  };
  const app = () => createApp({ repo, mode: 'cognito', verifier });

  it('rejects missing or invalid tokens', async () => {
    expect((await request(app()).get('/api/carbon')).status).toBe(401);
    expect((await request(app()).get('/api/carbon').set('Authorization', 'Bearer nope')).status).toBe(401);
  });

  it('enforces the permission matrix', async () => {
    const a = app();
    const as = (t: string) => ({ Authorization: `Bearer ${t}` });
    expect((await request(a).get('/api/carbon').set(as('viewer'))).status).toBe(200);
    expect((await request(a).post('/api/decide').set(as('viewer')).send({ pipeline_id: 'p' })).status).toBe(403);
    expect((await request(a).post('/api/decide').set(as('machine')).send({ pipeline_id: 'p' })).status).toBe(200);
    expect((await request(a).get('/api/carbon').set(as('machine'))).status).toBe(200);
    expect((await request(a).post('/api/ado/run').set(as('machine')).send({})).status).toBe(403);
    expect((await request(a).post('/api/ado/run').set(as('operator')).send({})).status).toBe(400);
    expect((await request(a).post('/api/ado/connect').set(as('operator')).send({})).status).toBe(403);
    expect((await request(a).post('/api/ado/connect').set(as('admin')).send({})).status).toBe(400);
    expect((await request(a).get('/api/me').set(as('operator'))).body.roles).toEqual(['operator']);
  });

  it('refuses to start unauthenticated in prod', () => {
    process.env.APP_ENV = 'prod';
    process.env.AUTH_MODE = 'disabled';
    try {
      expect(() => createApp({ repo })).toThrow(/not permitted/);
    } finally {
      process.env.APP_ENV = 'local';
      delete process.env.AUTH_MODE;
    }
  });
});

describe('ADO webhook', () => {
  const event = { eventType: 'ms.vss-pipelines.run-state-changed-event', resource: { run: { id: 7, state: 'completed', result: 'succeeded' }, pipeline: { id: 3, project: 'P', organization: 'O' } } };

  it('requires the shared secret when configured', async () => {
    process.env.WEBHOOK_SECRET = 's3cret';
    const app = createApp({ repo, mode: 'cognito', verifier: { verify: async () => { throw new Error('x'); } } });
    expect((await request(app).post('/api/ingest-ado-event').send(event)).status).toBe(401);
    expect((await request(app).post('/api/ingest-ado-event').set('X-GreenQA-Webhook-Secret', 'wrong!').send(event)).status).toBe(401);
    const ok = await request(app).post('/api/ingest-ado-event').set('X-GreenQA-Webhook-Secret', 's3cret').send(event);
    expect(ok.status).toBe(202);
    const rows = await repo.listExecutionsSince('azure', '');
    expect(rows[0]).toMatchObject({ pipeline_id: 'azdo://O/P/3', run_id: '7' });
  });

  it('is closed in cognito mode when no secret is provisioned', async () => {
    const app = createApp({ repo, mode: 'cognito', verifier: { verify: async () => ({}) } });
    expect((await request(app).post('/api/ingest-ado-event').send(event)).status).toBe(401);
  });

  it('ignores non-pipeline events with 200', async () => {
    const res = await request(local()).post('/api/ingest-ado-event').send({ eventType: 'git.push' });
    expect(res.body).toEqual({ accepted: false, reason: 'not_a_pipeline_event' });
  });
});
