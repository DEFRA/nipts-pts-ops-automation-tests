/* global React, Atoms, useStore, CloudConfigModal */
// =======================================================================
// Overview tab — live KPIs + 7d / 30d trend charts. 100% API-driven.
//   - GET /api/overview?provider=...&days=N   -> totals + trend curves
//   - GET /api/carbon?provider=...            -> home-region live intensity
//   - pipeline count comes from the store (loaded from Azure DevOps)
// No fixtures: empty windows render as zero series / em-dash KPIs.
// =======================================================================

const { PageHeader } = Atoms;

function useOverview(provider, days, nonce) {
  const empty = React.useMemo(() => ({
    provider, window_days: days,
    totals: { co2_emitted_g: 0, co2_saved_g: 0, runs: 0, avg_per_run_g: 0 },
    trend_7d: [], trend_30d: [], strategy_mix: []
  }), [provider, days]);
  const [state, setState] = React.useState({ data: empty, loading: true, error: null });

  React.useEffect(() => {
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured()) {
      setState({ data: empty, loading: false, error: 'no_api_url' });
      return undefined;
    }
    let cancelled = false;
    setState(s => ({ ...s, loading: true }));
    api.overview({ provider, days }).then((res) => {
      if (cancelled) return;
      if (!res.ok || !res.data) {
        setState({ data: empty, loading: false, error: res.error || 'bad_payload' });
        return;
      }
      setState({ data: res.data, loading: false, error: null });
    });
    return () => { cancelled = true; };
  }, [provider, days, empty, nonce]);

  return state;
}

// Live carbon intensity for a single region (the home region KPI).
function useHomeIntensity(provider, regionId, nonce) {
  const [intensity, setIntensity] = React.useState(null);
  React.useEffect(() => {
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured() || !regionId) return undefined;
    let cancelled = false;
    api.carbon({ provider }).then((res) => {
      if (cancelled || !res.ok || !res.data || !Array.isArray(res.data.regions)) return;
      const r = res.data.regions.find(x => x.code === regionId);
      const v = r && (r.intensity_gco2_kwh ?? r.grid_intensity_gco2_kwh);
      setIntensity(typeof v === 'number' ? v : null);
    });
    return () => { cancelled = true; };
  }, [provider, regionId, nonce]);
  return intensity;
}

function LedgerMasthead({ tweaks, now, polling }) {
  const { pipelines, azure, aws, openModal, closeModal } = useStore();
  const provider = tweaks.provider || 'azure';
  const range = tweaks.range || '30d';
  const days = range === '24h' ? 1 : range === '7d' ? 7 : range === 'qtr' ? 90 : 30;
  const homeId = tweaks.home_region || 'uksouth';

  // Manual refresh: bump a nonce to re-run the data hooks, and stamp the
  // "last updated" time locally (the polling tick also drives `now`).
  const [refreshNonce, setRefreshNonce] = React.useState(0);
  const [refreshedAt, setRefreshedAt] = React.useState(() => new Date());

  const { data: overview, loading, error } = useOverview(provider, days, refreshNonce);
  const totals = overview.totals || { co2_emitted_g: 0, co2_saved_g: 0, runs: 0, avg_per_run_g: 0 };
  const homeIntensity = useHomeIntensity(provider, homeId, refreshNonce);

  const refreshedLabel = relativeFromNow(refreshedAt);
  const openCloudConfig = (initialTab) => openModal({
    element: <CloudConfigModal onClose={closeModal} initialTab={initialTab} />,
    onClose: closeModal
  });
  const onRefresh = () => {
    setRefreshNonce(n => n + 1);
    setRefreshedAt(new Date());
    if (polling && polling.forceRefresh) polling.forceRefresh();
  };

  // Keep the timestamp in step with the background polling tick too.
  React.useEffect(() => { if (now instanceof Date) setRefreshedAt(now); }, [now]);

  return (
    <section aria-label="Overview">
      <PageHeader
        title="Overview"
        subtitle="Carbon emissions and scheduling decisions across your connected clouds."
        actions={
          <button type="button" className="gov-btn-secondary" onClick={onRefresh}>
            <span aria-hidden="true" className="gov-btn-icon">⟳</span> Refresh
          </button>
        }
      />

      {error && error !== 'no_api_url' && (
        <p className="inline-notice error" role="alert">
          Could not load the overview feed ({error}).
        </p>
      )}
      {!loading && !error && totals.runs === 0 && (
        <p className="inline-notice" role="status">
          No pipeline runs recorded yet — KPIs populate as carbon-gated runs complete.
        </p>
      )}

      <section className="subsection" aria-label="Cloud connections">
        <div className="trend-grid">
          <ConnectionCard
            name="Azure DevOps" connected={azure.connected}
            detail={azure.connected
              ? azure.organization + ' · ' + pipelines.length + ' pipelines'
              : 'Not connected'}
            onConfigure={() => openCloudConfig('azure')} />
          <ConnectionCard
            name="AWS" connected={aws.connected}
            detail={aws.connected ? 'Account ' + aws.accountId + ' · ' + aws.region : 'Not connected'}
            onConfigure={() => openCloudConfig('aws')} />
        </div>
      </section>

      <div className="kpi-strip" role="list">
        <Kpi label={'Saved · ' + range}
             value={(totals.co2_saved_g / 1000).toFixed(2)} unit="kg CO₂"
             meta="vs baseline region" />
        <Kpi label={'Emitted · ' + range}
             value={(totals.co2_emitted_g / 1000).toFixed(2)} unit="kg CO₂"
             meta={'across ' + totals.runs.toLocaleString() + ' runs'} />
        <Kpi label={'Avg / Run · ' + range}
             value={totals.avg_per_run_g.toFixed(2)} unit="gCO₂"
             meta="per pipeline execution" />
        <Kpi label={'Live · ' + homeId}
             value={homeIntensity != null ? homeIntensity : '—'} unit="gCO₂/kWh"
             meta={homeIntensity != null ? labelHeat(homeIntensity) : 'awaiting sample'} />
      </div>

      {refreshedLabel && (
        <p className="kpi-strip-meta">Last updated {refreshedLabel}.</p>
      )}

      <section className="subsection" aria-label="Carbon trend">
        <h2 className="subsection-title">Daily emissions trend</h2>
        <p className="subsection-subtitle">
          gCO₂ per day across all pipelines. Compare the last 7 days against the 30-day window.
        </p>
        <div className="trend-grid">
          <TrendChart title="Past 7 days" points={overview.trend_7d || []} colour="var(--gov-link, #1d70b8)" />
          <TrendChart title="Past 30 days" points={overview.trend_30d || []} colour="var(--gov-green, #00703c)" />
        </div>
      </section>

      <section className="subsection" aria-label="Scheduling decisions">
        <h2 className="subsection-title">Scheduling decisions</h2>
        <p className="subsection-subtitle">How carbon-gated runs were scheduled in this window.</p>
        <StrategyMix items={overview.strategy_mix || []} />
      </section>
    </section>
  );
}

const STRATEGY_LABEL = { RUN_NOW: 'Run now', DEFER: 'Deferred', RELOCATE: 'Relocated', HYBRID: 'Hybrid' };

function StrategyMix({ items }) {
  if (!items.some(i => i.count > 0)) return <p className="muted">No decisions recorded yet.</p>;
  return (
    <ul role="list" style={{ listStyle: 'none', padding: 0, margin: 0 }}>
      {items.map(i => (
        <li key={i.id} style={{ display: 'grid', gridTemplateColumns: '8rem 1fr 6rem', gap: 'var(--s-2)', alignItems: 'center', marginBottom: 'var(--s-2)' }}>
          <span>{STRATEGY_LABEL[i.id] || i.id}</span>
          <span style={{ background: '#f3f2f1', height: 12 }}>
            <span style={{ display: 'block', height: '100%', width: (i.pct * 100) + '%', background: 'var(--gov-green, #00703c)' }} />
          </span>
          <span className="muted">{i.count} · {Math.round(i.pct * 100)}%</span>
        </li>
      ))}
    </ul>
  );
}

function ConnectionCard({ name, connected, detail, onConfigure }) {
  return (
    <div className="trend-card">
      <div className="trend-card-head">
        <h3 className="trend-card-title">{name}</h3>
        <span className={'ccd-tag ' + (connected ? 'green' : '')}>{connected ? 'CONNECTED' : 'NOT CONNECTED'}</span>
      </div>
      <p className="muted">{detail}</p>
      <button type="button" className="gov-btn-secondary" onClick={onConfigure}>
        {connected ? 'Manage' : 'Connect'}
      </button>
    </div>
  );
}

// -----------------------------------------------------------------------
// TrendChart — SVG line + area for a daily emissions series.
// -----------------------------------------------------------------------
function TrendChart({ title, points, colour }) {
  const W = 560;
  const H = 160;
  const PAD_L = 36;
  const PAD_R = 12;
  const PAD_T = 14;
  const PAD_B = 26;

  if (!points || points.length === 0) {
    return (
      <div className="trend-card">
        <h3 className="trend-card-title">{title}</h3>
        <div className="trend-empty muted">No data in window.</div>
      </div>
    );
  }

  const values = points.map(p => p.co2_g);
  const max = Math.max(...values, 1);
  const min = 0;
  const innerW = W - PAD_L - PAD_R;
  const innerH = H - PAD_T - PAD_B;
  const stepX = points.length > 1 ? innerW / (points.length - 1) : 0;
  const xy = points.map((p, i) => {
    const x = PAD_L + i * stepX;
    const y = PAD_T + innerH - ((p.co2_g - min) / (max - min || 1)) * innerH;
    return { x, y, p };
  });
  const pathD = xy.map((pt, i) => (i === 0 ? 'M' : 'L') + pt.x.toFixed(1) + ',' + pt.y.toFixed(1)).join(' ');
  const areaD = pathD + ' L' + xy[xy.length - 1].x.toFixed(1) + ',' + (PAD_T + innerH).toFixed(1)
              + ' L' + xy[0].x.toFixed(1) + ',' + (PAD_T + innerH).toFixed(1) + ' Z';

  const yTicks = 4;
  const tickValues = Array.from({ length: yTicks + 1 }, (_, i) => max * (i / yTicks));

  const total = values.reduce((a, b) => a + b, 0);
  const avg = total / values.length;
  const firstDate = points[0].date;
  const lastDate = points[points.length - 1].date;

  return (
    <div className="trend-card">
      <div className="trend-card-head">
        <h3 className="trend-card-title">{title}</h3>
        <div className="trend-card-meta muted">
          Total {total.toFixed(0)} g · Avg {avg.toFixed(1)} g/day
        </div>
      </div>
      <svg className="trend-chart" viewBox={'0 0 ' + W + ' ' + H} role="img"
           aria-label={title + ' carbon trend'}>
        {/* Y-axis grid + labels */}
        {tickValues.map((v, i) => {
          const y = PAD_T + innerH - (v / (max || 1)) * innerH;
          return (
            <g key={i}>
              <line x1={PAD_L} x2={W - PAD_R} y1={y} y2={y}
                    stroke="#dee0e2" strokeWidth="1" strokeDasharray={i === 0 ? '0' : '2 3'} />
              <text x={PAD_L - 6} y={y + 4} textAnchor="end"
                    fontSize="11" fill="#505a5f">{Math.round(v)}</text>
            </g>
          );
        })}
        {/* Area + line */}
        <path d={areaD} fill={colour} opacity="0.12" />
        <path d={pathD} fill="none" stroke={colour} strokeWidth="2" />
        {/* Points */}
        {xy.map((pt, i) => (
          <circle key={i} cx={pt.x} cy={pt.y} r="2.5" fill={colour}>
            <title>{pt.p.date}: {pt.p.co2_g.toFixed(1)} g</title>
          </circle>
        ))}
        {/* X-axis endpoints */}
        <text x={PAD_L} y={H - 6} fontSize="11" fill="#505a5f">{firstDate}</text>
        <text x={W - PAD_R} y={H - 6} fontSize="11" fill="#505a5f" textAnchor="end">{lastDate}</text>
      </svg>
    </div>
  );
}

function Kpi({ label, value, unit, meta }) {
  return (
    <div className="kpi-cell" role="listitem">
      <div className="kpi-label">{label}</div>
      <div className="kpi-value">
        <span className="kpi-num">{value}</span>
        {unit && <span className="kpi-unit">{unit}</span>}
      </div>
      {meta && <div className="kpi-meta">{meta}</div>}
    </div>
  );
}

function relativeFromNow(now) {
  if (!(now instanceof Date)) return '';
  const ago = Math.max(0, Math.floor((Date.now() - now.getTime()) / 1000));
  if (ago < 10) return 'just now';
  if (ago < 60) return ago + ' seconds ago';
  if (ago < 3600) return Math.floor(ago / 60) + ' minutes ago';
  return Math.floor(ago / 3600) + ' hours ago';
}

function labelHeat(v) {
  if (v <= 50)  return 'Excellent grid';
  if (v <= 150) return 'Low intensity';
  if (v <= 250) return 'Moderate intensity';
  if (v <= 400) return 'High intensity';
  return 'Severe intensity';
}

window.LedgerMasthead = LedgerMasthead;
