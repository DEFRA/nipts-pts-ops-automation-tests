# HANDOFF — Carbon Cost Dashboard / Green QA (ZeroCarb)

> **Purpose.** This file exists so a fresh Claude Code (or human) sitting on a
> different machine can pick up work on this repository without losing context.
> It is a **snapshot as of 2026-09-01** and will go stale. Trust the code and
> `git log` over anything written here when they disagree.
>
> **Owner:** saptamita.majumder@cognizant.com (Cognizant).
> **Tenant:** DEFRA (via PIM-Contributor role on `rg-greenqa-dashboard`).

---

## 0. TL;DR — what this repo is

Two loosely-coupled prototypes that share the "Carbon Cost Dashboard / Green
QA Platform" branding:

1. **No-build React SPA** at the repo root — `Carbon Cost Dashboard.html` plus
   sibling `*.jsx` files transpiled in-browser by Babel Standalone. Renders
   from `data.js` fixtures by default; flips to live data when
   `window.GREEN_QA_API_URL` is set (via `config.js`, gitignored, generated at
   deploy time).
2. **Azure Functions v2 backend** under `backend/azure/functions/` — Python
   3.11, HTTP routes `/api/decide`, `/api/calculate`, `/api/budget/check`,
   `/api/history`, `/api/carbon`, `/api/store_result`, `/api/ingest-ado-event`,
   plus two timer triggers (`ingest_carbon` every 30 min, `resume_deferred`
   every 5 min). Depends on `green_qa_lib/` (present locally as a stub — see
   §5) and Cosmos DB / Key Vault (Cosmos has an in-memory fallback when
   `COSMOS_ENDPOINT` is blank).

The SPA and the backend are wired together only via the deploy-time
`config.js`. In pure local development, the SPA and backend run
independently and the SPA falls back to `data.js` fixtures if the backend
isn't reachable.

---

## 1. How to move the code base to another machine

### Option A — clone from the git remote (preferred)

The repo is a git repository. If the new machine can reach the same remote
(Azure DevOps in Cognizant's tenant), that is the cleanest path:

```bash
git clone <same-remote-url> ZeroCarb
cd ZeroCarb
git fetch --all
git checkout fix/swa-cdn-jsdelivr    # current working branch as of 2026-09-01
```

You do NOT need to move `.venv/`, `__pycache__/`, `.pytest_cache/`,
`.ruff_cache/`, `node_modules/`, or `.deploy-stage/` — they are gitignored
and reproducible.

### Option B — offline zip transfer

If the new machine can't reach the remote (air-gap / VPN issue), zip and
transfer:

```powershell
# From the parent of ZeroCarb, on the old machine:
Compress-Archive -Path .\ZeroCarb `
  -DestinationPath .\ZeroCarb-handoff.zip `
  -Force
# By design this keeps .git/ so the new machine keeps history + branches.
```

Suggested exclusions before zipping (they bloat the archive and regenerate
locally):

- `backend/azure/functions/.venv/`
- `**/__pycache__/`
- `.pytest_cache/`, `.ruff_cache/`
- `scripts/e2e/node_modules/`
- `.deploy-stage/`
- `backend/azure/functions/local.settings.json` (may contain your local
  ElectricityMaps token — do **not** transfer via unencrypted channels)

### Option C — Claude Code memory also needs to travel

The accumulated feedback / project notes live at:

```
%USERPROFILE%\.claude\projects\C--green-qa-platform-UI-ZeroCarb\memory\
```

If you want the new agent to start with the same behavioural context (rules
about not touching source without approval, the DEFRA daily-shutdown rule,
the WattTime migration deadline, etc.), copy that directory onto the new
machine into the equivalent path. Otherwise the new agent starts cold and
re-learns everything from scratch. See §11 below for the current memory
inventory.

---

## 2. Current branch state (as of 2026-09-01)

- **Branch:** `fix/swa-cdn-jsdelivr`
- **Working tree:** clean (per shell start-of-conversation snapshot).
- **Recent commits (top 5):**
  ```
  c7789dc spa: switch React/Babel CDN from unpkg to jsdelivr
  cd5b70a Merged PR 12: ruff: fix I001 import-sort blocking CI Validate stage
  9c645fb ruff: fix I001 import-sort blocking CI Validate stage
  fc72282 Merged PR 11: ruff: clear 5 violations blocking CI Validate stage
  d8de456 ruff: clear 5 violations blocking CI Validate stage
  ```
- **What the current branch is doing:** replacing `unpkg.com` with
  `cdn.jsdelivr.net` for React 18 / ReactDOM / Babel Standalone in
  `Carbon Cost Dashboard.html`. Motivation: unpkg was intermittently blocked
  by the corporate proxy; jsdelivr is generally reachable and still supports
  SRI integrity hashes (already updated in the HTML). This has NOT yet been
  merged to `main` — verify status before starting new work on top of it.

Before you commit new work, run `git log main..HEAD` on the new machine to
confirm what's ahead of `main`.

---

## 3. Directory map (top level, as it exists today)

```
ZeroCarb/
├── Carbon Cost Dashboard.html    # SPA entry — open in browser or via
│                                 # http.server (Babel needs HTTP, not file://)
├── apiClient.js                  # Fetch wrappers; short-circuits to fixtures
│                                 # when config.js is missing/empty
├── config.example.js             # Template — copy to config.js (gitignored)
├── data.js                       # ALL SPA fixture data (regions, pipelines,
│                                 # teams, forecast curves, research fixtures)
├── styles.css                    # Hand-written, ~123 KB, theming via
│                                 # data-theme / data-density / data-provider
├── *.jsx                         # atoms, tweaks-panel, store, settings,
│                                 # modals, ledger, pipelines, regions,
│                                 # research, glossary, app  (load order
│                                 # matters — see the HTML)
├── data.js                       # (already listed)
├── staticwebapp.config.json      # Azure Static Web App routing
│
├── setup.bat / start.bat / stop.bat   # Windows one-command dev loop
│
├── backend/
│   ├── azure/functions/          # Python v2 Functions app
│   │   ├── function_app.py       # Routes + timers (single entry point)
│   │   ├── schemas.py            # Dataclass request/response contracts
│   │   ├── decision_service.py   # Wraps SchedulingEngine, handles
│   │   │                         # resume short-circuit + MS-hosted pool
│   │   ├── cosmos_dal.py         # Cosmos DB facade + in-memory fallback
│   │   ├── ado_client.py         # urllib-based ADO Pipelines REST client
│   │   ├── host.json             # routePrefix=api
│   │   ├── local.settings.json.example
│   │   ├── requirements.txt      # runtime deps (azure-functions, cosmos,
│   │   │                         # identity, keyvault-secrets — all ~= pinned)
│   │   └── requirements-dev.txt  # + pytest, ruff
│   └── infrastructure/azure/
│       ├── main.bicep            # Single-file IaC (resourceGroup scope)
│       └── main.parameters.{dev,staging,prod,example}.json
│
├── green_qa_lib/                 # LOCAL STUB of the upstream lib (see §5)
│   ├── carbon_api.py
│   ├── carbon_budget.py
│   ├── constants.py
│   ├── models.py
│   ├── providers.py
│   ├── scheduling_engine.py      # MAIZX 4-step decision tree
│   └── sci_calculator.py         # GSF SCI formula
│
├── tests/                        # pytest suite (~36 tests, ~0.5 s)
│   ├── test_cosmos_dal.py
│   ├── test_decision_service.py
│   ├── test_green_qa_lib_stub.py
│   └── test_schemas.py
│
├── scripts/
│   ├── local_server.py           # Pure-Python backend shim (no Functions
│   │                             # Core Tools needed) — used by start.bat
│   ├── static_server.py          # No-cache static web server (port 8080)
│   ├── deploy.sh / deploy.ps1    # Bicep what-if / apply wrappers
│   ├── run-local.ps1             # PowerShell equivalent of start.bat
│   ├── preview_pipeline.ps1
│   ├── sample-pipelines.sh
│   ├── validate_pipelines.py
│   └── e2e/                      # Playwright E2E suite (Node, ad-hoc)
│
├── pipelines/                    # Sample ADO pipeline YAMLs illustrating
│   ├── _shared/                  # gate-template.yml + decide.sh
│   └── 01..05-*.yml              # billing hotfix, nightly, api-tests, etc.
│
├── docs/                         # ARCHITECTURE.md (★ canonical), plus
│                                 # DATA_SOURCES, EXTERNAL_APIS, INFRASTRUCTURE,
│                                 # SETUP, DEPLOYMENT_AZURE, RESEARCH_FLOW,
│                                 # TESTING, USER_GUIDE, AZURE_DEVOPS_INTEGRATION,
│                                 # SELF_HOSTED_REGIONAL_AGENTS
│
├── to_be_deleted/                # Staged-for-delete artifacts (safe;
│                                 # each verified as unused). Review + `git rm -r`
│                                 # when you're satisfied.
│
├── azure-pipelines.yml           # CI/CD: Validate → DeployBackend + DeploySPA
├── CLAUDE.md                     # Repo orientation for Claude (partially
│                                 # stale — see §12 below)
├── README.md                     # Human-facing repo intro
├── DEPLOYMENT.md, OPERATIONS.md  # Describe a FUTURE /v1/* API — treat as
│                                 # aspirational, not the shipped contract
├── GAPS.md                       # Mocked vs. real inventory + prod roadmap
├── pyproject.toml, pyrightconfig.json
└── .gitignore, .green-qa.example.yaml
```

---

## 4. What has been done (major milestones)

### Frontend SPA
- All 8 tabs render: Ledger, Budgets, Pipelines, Regions, Forecast, Strategy,
  Teams, Equivalences, History, Synthetic Tests (see `GAPS.md` §A for the
  authoritative feature list).
- Tweaks panel (theme / density / range / provider / layout / show-money /
  home-region), with defaults declared inside the `/*EDITMODE-BEGIN*/…
  /*EDITMODE-END*/` markers in `app.jsx` — those markers are read by an
  external host tool; **do not remove them**.
- Config persisted to `localStorage` under `ccd-config`; research tab state
  persisted under `ccd.research.*` keys.
- WCAG 2.2 AA palette + focus states, GOV.UK Design System copy voice.
- Hash-routed navigation (`#/pipelines`, `#/regions`, …). Add new tabs to the
  `TABS` array in `app.jsx` and the `<main>` switch.

### Backend
- Python v2 Functions app fully wired: 7 HTTP routes + 2 timers.
- **`resume_deferred` timer** re-triggers ADO pipelines whose `defer_until_iso`
  has passed; the resumed run passes `GreenQA_Resumed=true` back to
  `/api/decide`, which short-circuits MAIZX and forces `RUN_NOW`. Prevents
  the infinite-DEFER loop when grid conditions never improve.
- **`ingest_carbon` timer** pulls ElectricityMaps for every region of every
  provider in `INGEST_PROVIDERS` (default `aws,azure`).
- **`cosmos_dal.py` in-memory fallback** when `COSMOS_ENDPOINT` is empty —
  every new query method MUST re-filter client-side (the in-memory
  `query_items` does NOT parse SQL).
- **Decision label mapping** (`decision_service.py`): `run_now → RUN_NOW`,
  `time_shift → DEFER` (+ persist to `deferred_runs`), `space_shift →
  RELOCATE` (same-region → `RUN_NOW`), `hybrid → HYBRID` (+ persist).
- **Pool-mode constraint:** `pool_mode == 'ms_hosted_single_region'` forces
  `selected_pool = None` and restricts candidates to the current region
  (MS-hosted agents cannot change region).
- **NESO live carbon** and **ElectricityMaps live** both opt-in via env
  toggles (`NESO_USE_LIVE`, `ELECTRICITYMAPS_USE_LIVE`) so tests stay
  deterministic.
- **Self-hosted regional agent routing:** `GREENQA_AGENT_POOL_MODE=self_hosted`
  routes Run Now / Relocate to the org pool `SF1` (poolId 10) matched by a
  `region` capability (`westeurope` / `swedencentral`). See
  `docs/SELF_HOSTED_REGIONAL_AGENTS.md`.

### Infrastructure
- `main.bicep` (single file, `resourceGroup` scope) provisions: Storage, Log
  Analytics, App Insights, Key Vault (RBAC mode), Cosmos DB Serverless with
  4 SQL-API containers, Linux Python 3.11 Consumption Function App, Free
  Static Web App.
- Function App system-assigned managed identity granted **Key Vault Secrets
  User** and **Cosmos DB Built-in Data Contributor** — connection-string-less
  by design. Preserve that when editing.
- Cosmos containers, all partition-keyed on `/pipeline_id` except
  `carbon_intensity_history` (`/region`).

### CI/CD
- `azure-pipelines.yml` runs on every PR to `main` (validate only) and every
  push to `main` (validate + deploy backend + deploy SPA):
  - **Validate:** `ruff check backend/ green_qa_lib/ tests/` + `pytest tests/ -v`
    + `az bicep lint`.
  - **DeployBackend:** vendors Linux manylinux wheels into a zip and posts
    to Kudu `/api/zipdeploy` (NOT run-from-package — those two modes are
    incompatible). Smoke-tests `/api/carbon?provider=azure` for up to ~90s
    of cold start.
  - **DeploySPA:** stages repo root, generates `config.js` (injects the
    Function key), rewrites `staticwebapp.config.json` navigationFallback
    to `/index.html`, runs `swa deploy`.
- Required pipeline secrets: `GREEN_QA_FN_KEY`, `SWA_DEPLOYMENT_TOKEN`,
  `FN_PUBLISH_USER`, `FN_PUBLISH_PASS`.
- Bicep `apply` is intentionally **NOT** in CI — infra changes are rare and
  high-blast-radius. Run `./scripts/deploy.sh dev apply` locally.

### Recently landed (see git log for details)
- Ruff violations cleared to unblock the Validate stage (PRs 11 & 12).
- Static Web App CDN switch: React/Babel now loaded from
  `cdn.jsdelivr.net` instead of `unpkg.com` (current branch, unmerged).

---

## 5. Blockers & known problems (READ THIS)

### 5.1 `green_qa_lib/` is a local STUB
CLAUDE.md still says "not in this directory" — **that is out of date**. The
files under `green_qa_lib/` exist locally and the pytest suite includes
`test_green_qa_lib_stub.py` which asserts stub behaviour. The upstream
production `green_qa_lib` (with the real `SchedulingEngine` implementation,
provider adapters, etc.) lives in the parent `green-qa-platform` repo. What
this means in practice:

- Local pytest and local `func start` will run against the stub.
- The stub is enough for schema/DAL/HTTP-shape work and light decision
  tests, but decisions returned from the stub are NOT representative of the
  production MAIZX behaviour.
- If a task requires exercising real scheduling logic, that must be done in
  the upstream repo, not here.

### 5.2 Azure subscription state (UPDATED 2026-09-22)

**Snapshot as of 2026-09-01 (kept for context):** old VS Enterprise sub was
CANCELLED; only PIM-Contributor on DEFRA `rg-greenqa-dashboard`; no UAA
meant Bicep RBAC blocks would fail.

**Current state (2026-09-22):**
- **New VS Enterprise E6 licence is active** on `my.visualstudio.com`,
  valid until **2026-09-30** (⚠️ 8 days away at time of writing). Cognizant
  needs to renew this or the Azure benefit lapses.
- **Azure DevTest $150 monthly credit has been activated** under Saptamita's
  DEFRA account. This spun up a new Azure subscription — exact ID / name /
  tenant to be captured in §14 Step 4.
- Because she activated it herself, she is **Owner** on this new sub, which
  **resolves the UAA/RBAC blocker** for deployments *into that sub*. Bicep
  role assignments will succeed.
- Caveats before deploying into it:
  1. It's a DevTest sub — Microsoft's terms restrict it to dev/test workloads
     (not production). Fine for the POC.
  2. When the VS licence expires (2026-09-30), the sub keeps existing but
     the $150/month credit stops. ~30 days later Azure disables the sub
     unless converted to pay-as-you-go with a card.
  3. Do NOT deploy this POC into DEFRA `rg-greenqa-dashboard` — use a
     resource group inside the new DevTest sub instead. Cleaner, and it
     also stops touching DEFRA's own billing.
- The DEFRA PIM-Contributor access on `rg-greenqa-dashboard` still exists
  but is no longer the deploy target for this stack.

### 5.3 DEFRA daily-shutdown rule
- Governance rule: the DEFRA POC Function App must be **stopped at end of
  day** and started next morning. Don't plan overnight work / long-running
  timers that assume 24×7 availability.

### 5.4 WattTime migration deadline (2026-09-01 → 2026-09-01+)
- The POC shipped with a **placeholder ElectricityMaps token**.
- Contract requires **WattTime to replace ElectricityMaps by 2026-09-01**.
- Deadline is TODAY. The WattTime adapter needs to land in `green_qa_lib`
  (upstream repo) before the demo window. Check current status —
  `green_qa_lib/providers.py` here is a stub; the real work happens
  upstream.

### 5.5 SPA local dev needs HTTP, not `file://`
- Opening `Carbon Cost Dashboard.html` via `file://` renders blank because
  Babel Standalone XHRs the `.jsx` files and the browser blocks cross-origin
  `file://` fetches.
- Correct local loop: `start.bat` (Windows) → serves via `scripts/static_server.py`
  on port 8080. Or manually: `python -m http.server 8000` from repo root.

### 5.6 SPA→backend wiring
- The SPA does not yet call `/api/decide`, `/api/calculate`, or
  `/api/history` from any button. Only the Regions tab fetches `/api/carbon`
  and flips the badge to `LIVE DATA`. Every other number on screen is from
  `data.js`. See `GAPS.md` §B for the full mock-vs-real table.

### 5.7 Documentation contradictions (don't blindly trust)
- `docs/SETUP.md` references `make test-unit`, `python local_server.py`,
  `dashboard/public/` — those describe the **upstream mono-repo**, not this
  directory. Ignore for local ops.
- `DEPLOYMENT.md` and `OPERATIONS.md` describe a richer `/v1/*` API (`/v1/gate`,
  `/v1/regions`, `/v1/health`, idempotency keys, Front Door, PagerDuty) that
  is **not** what `function_app.py` implements. Real shipped routes are the
  `/api/*` set. If a user asks about `/v1/gate`, clarify which API before
  changing code.
- `backend/infrastructure/azure/README.md` mentions publishing from
  `dashboard/public` — this repo publishes from the repo root instead
  (`azure-pipelines.yml` stages repo-root `*.jsx` + HTML into a temp
  directory). The infra README is aspirational for a future layout.

### 5.8 CLAUDE.md is partially stale
- Claims `green_qa_lib` is missing (see 5.1 — it's a stub).
- Otherwise the architecture / conventions sections are still accurate as
  of 2026-09-01.

---

## 6. Environment / secrets required on the new machine

### For local dev only (SPA + backend against in-memory DAL)
- Python 3.11 (or later 3.x compatible with `azure-functions~=1.21`).
- Nothing else — `setup.bat` creates the venv, installs deps, copies
  `local.settings.json.example` → `local.settings.json`, writes a local
  `config.js` pointing the SPA at `http://localhost:7071/api`.

### For running against real Azure resources
- `ELECTRICITYMAPS_TOKEN` — currently a placeholder; needs a real value
  from Key Vault (or from the WattTime replacement, see §5.4).
- `COSMOS_ENDPOINT` (+ database + 4 container names) — leave blank to use
  the in-memory DAL.
- `KEY_VAULT_URI` + `KV_SECRET_ADO_PAT` — for the ADO PAT lookup done by
  `resume_deferred`.
- Fallback: `AZURE_DEVOPS_PAT` env var if KV isn't wired.
- `GREENQA_AGENT_POOL_MODE`, `GREENQA_AGENT_POOL_NAME` — for regional
  routing. `local.settings.json.example` defaults to `self_hosted` / `SF1`.

### For CI/CD (Azure DevOps pipeline secrets)
- `GREEN_QA_FN_KEY` (secret) — baked into `config.js` at SPA build time.
- `SWA_DEPLOYMENT_TOKEN` (secret) — from `az staticwebapp secrets list`.
- `FN_PUBLISH_USER` (secret) — starts with `$<appname>`.
- `FN_PUBLISH_PASS` (secret).

### Deployed Function App environment (Azure Portal → Configuration)
See `local.settings.json.example` for the full list; the important ones the
runtime code reads directly:
- `GREEN_QA_PROVIDER_DEFAULT`, `INGEST_PROVIDERS`
- `MIN_SAVINGS_PERCENT`, `ALLOW_HYBRID`, `DYNAMIC_SLACK`, `ALPHA_FAIRNESS`
- `DEFAULT_CARBON_INTENSITY_GCO2_KWH`, `DEFAULT_PUE`, `DEFAULT_FUNCTIONAL_UNIT`
- `HISTORY_DEFAULT_LIMIT`, `HISTORY_MAX_LIMIT`
- `DEFER_MAX_ATTEMPTS` (default 3), `DEFER_GUARD_MINUTES` (default 15)
- `NESO_USE_LIVE`, `NESO_TIMEOUT`, `ELECTRICITYMAPS_USE_LIVE`, `ELECTRICITYMAPS_TIMEOUT`
- `ADO_DEFAULT_BRANCH`

---

## 7. How to bootstrap on the new machine

### 7.1 Frontend + backend against in-memory data (fastest smoke test)
```powershell
# Windows
setup.bat            # one-time
start.bat            # every session — opens two windows + browser
# → http://localhost:8080/Carbon%20Cost%20Dashboard.html
# → http://localhost:7071/api
stop.bat             # when done
```

Or the equivalent PowerShell path via `scripts/run-local.ps1`.

### 7.2 Backend against real Functions runtime
```bash
cd backend/azure/functions
cp local.settings.json.example local.settings.json
# Edit local.settings.json — leave COSMOS_ENDPOINT blank for the in-memory DAL.

python -m venv .venv
.venv/Scripts/activate       # PowerShell: .venv/Scripts/Activate.ps1
pip install -r requirements.txt -r requirements-dev.txt
pytest -q                    # ~36 tests, ~0.5 s — expect all green
func start                   # requires Azure Functions Core Tools v4
# → http://localhost:7071/api/{decide,calculate,carbon,history,budget/check,...}
```

### 7.3 Deploy to Azure (rare — high blast radius)
Only run this after confirming §5.2. As of 2026-09-22 the deploy target is
the new DevTest sub, and Saptamita is Owner on it so RBAC blocks will
succeed. Full procedure in `docs/DEPLOYMENT_AZURE.md`. Rough shape:
```bash
# Point Az CLI at the DevTest sub
az account set --subscription "<DevTest sub ID from §14 Step 4>"

# Create a fresh RG inside the DevTest sub (NOT rg-greenqa-dashboard)
az group create --name rg-greenqa-poc --location uksouth

az deployment group create \
  --resource-group rg-greenqa-poc \
  --template-file backend/infrastructure/azure/main.bicep \
  --parameters main.parameters.dev.json \
               electricityMapsToken=$TOKEN adoPat=$PAT \
               adminObjectId=$(az ad signed-in-user show --query id -o tsv)
```

### 7.4 Importing into VS Code on the DEFRA laptop

Once the git bundle / zip has been transferred (see §1), open the project
and set up the toolchain:

1. **Unpack** into a working directory. If you received a `.bundle` file:
   ```powershell
   mkdir C:\greenqa
   cd C:\greenqa
   git clone <path-to>\ZeroCarb.bundle ZeroCarb
   cd ZeroCarb
   git branch -a           # you should see main + fix/swa-cdn-jsdelivr
   git checkout fix/swa-cdn-jsdelivr
   ```
   If you received a zip: `Expand-Archive .\ZeroCarb-handoff.zip -DestinationPath C:\greenqa\`.

2. **Open in VS Code**:
   ```powershell
   code .
   ```

3. **Install VS Code extensions** (VS Code will offer some via the
   `.vscode/extensions.json` recommendations if present; otherwise install
   manually via Ctrl+Shift+X):
   - Azure Functions — `ms-azuretools.vscode-azurefunctions`
   - Azure Static Web Apps — `ms-azuretools.vscode-azurestaticwebapps`
   - Azure Resources — `ms-azuretools.vscode-azureresourcegroups`
   - Bicep — `ms-azuretools.vscode-bicep`
   - Python + Pylance — `ms-python.python`, `ms-python.vscode-pylance`
   - Ruff — `charliermarsh.ruff`
   - GitLens (optional) — `eamodio.gitlens`

4. **Sign in to Azure inside VS Code**: Ctrl+Shift+P → `Azure: Sign In` →
   pick the DEFRA account (the same one you used to activate the DevTest
   credit). The Azure Functions / SWA extensions publish through this
   session.

5. **Install prerequisite CLIs** (open a VS Code terminal):
   ```powershell
   python --version         # need 3.11.x
   az --version             # any recent Azure CLI
   func --version           # Azure Functions Core Tools v4
   node --version           # LTS, optional for SWA CLI + Playwright
   git --version
   ```
   If any are missing, install via `winget` (if DEFRA permits) or the
   corporate software portal:
   ```powershell
   winget install --id Python.Python.3.11
   winget install --id Microsoft.AzureCLI
   winget install --id Microsoft.AzureFunctionsCoreTools
   winget install --id OpenJS.NodeJS.LTS
   winget install --id Git.Git
   ```
   If `winget` is blocked, request these via DEFRA's software catalogue.

6. **Smoke test the local loop** (no Azure needed, uses the in-memory DAL):
   ```powershell
   .\setup.bat
   .\start.bat
   ```
   SPA at `http://localhost:8080/Carbon%20Cost%20Dashboard.html`,
   backend at `http://localhost:7071/api`. Stop with `.\stop.bat`.

7. **Copy Claude Code memory** (optional but recommended so the next
   Claude session on the DEFRA laptop starts with all the accumulated
   preferences and project constraints):
   - On the current machine, zip:
     ```powershell
     Compress-Archive `
       -Path "$env:USERPROFILE\.claude\projects\C--green-qa-platform-UI-ZeroCarb\memory" `
       -DestinationPath .\claude-memory.zip
     ```
   - On DEFRA laptop, unpack into the same path — VS Code / Claude Code
     will read from there automatically.

8. **Copy `HANDOFF.md` and `local.settings.json` separately** if they are
   not already inside the bundle:
   - `HANDOFF.md` is currently **untracked** in git — it will NOT be inside
     `ZeroCarb.bundle`. Copy this file manually.
   - `backend/azure/functions/local.settings.json` is gitignored (may
     contain a stale ElectricityMaps token). If you rely on it, transfer
     via an encrypted channel — do NOT put the token in email or unencrypted
     file-share.

---

## 8. Features by tab / route (quick reference)

### SPA tabs (all defined in `app.jsx`'s `TABS` array)
| Tab | Purpose | Source of numbers |
|---|---|---|
| Ledger | Per-transaction carbon breakdown | `data.js` fixtures |
| Pipelines | Pipeline runs + gate status | `data.js` fixtures |
| Regions | Regional intensity + map | `/api/carbon` when config.js is set, else `data.js` |
| Forecast | 24h carbon curve | `data.js` static curve |
| Strategy | MAIZX mix (RUN_NOW / TIME_SHIFT / SPACE_SHIFT / HYBRID) | `data.js` |
| Research | Persisted research findings | `localStorage` under `ccd.research.*` |
| Settings | Polling cadence, retry, alert threshold, generated YAML preview | `localStorage` under `ccd-config` |
| Glossary | Term definitions | Static in `glossary.jsx` |

### Backend routes
| Method + route | Purpose |
|---|---|
| POST `/api/decide` | Carbon-aware scheduling decision |
| POST `/api/calculate` | SCI footprint for a workload |
| POST `/api/budget/check` | Compare actual gCO2 to a budget |
| POST `/api/store_result` | Persist actual carbon cost of a run |
| GET  `/api/history` | Paginated execution history |
| GET  `/api/carbon` | Region catalogue + latest intensity |
| POST `/api/ingest-ado-event` | ADO Service Hook receiver |
| Timer `ingest_carbon` (30 min) | Pull ElectricityMaps → Cosmos |
| Timer `resume_deferred` (5 min) | Re-trigger deferred ADO runs |

---

## 9. Pending items / roadmap (from GAPS.md + recent work)

### Immediate (unblock the pilot)
- [ ] **WattTime provider adapter** to replace ElectricityMaps by
      2026-09-01. Lands in the upstream `green_qa_lib`, not this repo's
      stub. Reference: `project_watttime_migration` memory.
- [ ] **Merge / rebase `fix/swa-cdn-jsdelivr`** into `main` once verified in
      DEFRA network. Confirms the jsdelivr CDN works from the corporate
      egress.
- [ ] **Verify SPA→backend wiring** in the deployed environment: set
      `GREEN_QA_API_URL` + `GREEN_QA_FUNCTION_KEY` via SWA appsettings and
      confirm the Regions tab flips to `LIVE DATA`.
- [ ] **Sort out Bicep RBAC blocks** in light of no-UAA constraint (see
      §5.2). Either split the template or coordinate a UAA-holder for the
      deploy.

### Before customer GA (from GAPS.md §C)
- [ ] **Workload Identity Federation** (OIDC federated creds, no SP secret).
- [ ] **Zero-trust API auth** on `/api/*`: mTLS + per-pipeline JWT scopes +
      rate limiting at Front Door WAF.
- [ ] **Carbon data lineage** on every emitted gCO₂ figure (source, method,
      PUE, embodied).
- [ ] **α-fairness constraint** in scheduling (prevent all workloads piling
      onto Sweden Central).
- [ ] **Data residency enforcement** (regions allow-list per pipeline).
- [ ] **Cost ceiling** on `SPACE_SHIFT` decisions.
- [ ] **Forecast confidence intervals** — refuse `TIME_SHIFT` if confidence
      < `FORECAST_CONFIDENCE_THRESHOLD` (default 0.7).
- [ ] **eBPF/psutil sidecar** for compile-time carbon measurement.
- [ ] **Chaos test** for the carbon API circuit breaker.
- [ ] **Golden-path canary** every 10 min across 3 regions.
- [ ] **PII redaction** on pipeline names / commit messages / author names
      + 90-day retention policy.
- [ ] **Cryptographic signing** of emitted carbon figures for ESG audit.

### Post-GA roadmap (GAPS.md §D — nice-to-haves)
- Multi-tenant dashboard, Slack/Teams bot, recommendation explainability,
  carbon SLOs, forecast-aware autoscaling, K8s admission controller,
  federated learning for MAIZX weights. See GAPS.md §D for the per-quarter
  breakdown.

### Cleanup
- [ ] `to_be_deleted/` — review and `git rm -r` when satisfied (see
      `to_be_deleted/README.md` for the reference-check evidence).
- [ ] Reconcile CLAUDE.md with reality (see §5.8) — currently states
      `green_qa_lib` is missing.
- [ ] Decide whether `DEPLOYMENT.md` and `OPERATIONS.md` (describing the
      aspirational `/v1/*` API) should be trimmed to the shipped surface
      area or kept as roadmap.

---

## 10. Conventions worth preserving (do not break these)

1. **No bundler in the SPA, ever.** New frontend files stay as `*.jsx`
   loaded via `<script type="text/babel">`, expose to `window.*` like the
   existing files, and are added to `Carbon Cost Dashboard.html` in
   dependency order. Every `.jsx` file declares its expected globals in a
   leading `/* global … */` comment — keep that honest.

2. **Load order in `Carbon Cost Dashboard.html` is real.** Each file
   attaches its exports to `window` and depends on prior ones:
   `data.js → atoms → tweaks-panel → store → settings → modals → ledger →
   pipelines → regions → research → glossary → app`.

3. **`config.js` is gitignored.** It's generated per environment at deploy
   time; `config.example.js` is the committed template. The SPA falls back
   to fixtures when config.js is missing or both values are empty.

4. **`/*EDITMODE-BEGIN*/ … /*EDITMODE-END*/` markers in `app.jsx`** are
   read by an external host tool — do not remove or rename them.

5. **`data.js` IDs are stable** (`uksouth`, `auth-service-ci`, `identity`,
   …). Many UI components index by ID — don't rename without a global
   grep.

6. **Backend dataclasses in `schemas.py` are the API v1 contract.** If you
   change a field, update both the `from_dict` parser and every dashboard
   fetch site.

7. **`cosmos_dal.py` in-memory branch must stay in sync** with every new
   query method. The in-memory `query_items` does NOT parse SQL — you MUST
   re-filter client-side after `query_items`.

8. **GOV.UK Design System voice** in copy. Tags `green | amber | red`.
   WCAG 2.2 AA palette already encoded in `styles.css`.

9. **Connection-string-less by design.** The Function App uses managed
   identity for both Key Vault and Cosmos. Preserve that when editing
   Bicep.

10. **CI does not run `bicep apply`.** Infra changes are rare + high blast
    radius — they run locally via `./scripts/deploy.sh dev apply`.

---

## 11. Behavioural context for the next agent

These are accumulated preferences and project constraints stored in the
user's Claude memory folder. Copy that folder (see §1 Option C) so the new
agent picks them up automatically. Summarised here for reference:

### Feedback rules (how to work with saptamita.majumder@cognizant.com)
- **No source edits without explicit per-task approval.** For ops/deploy
  asks, treat "no functionality changes" as "no source edits, period."
- **Ask before extracting cached git/cloud credentials.** Name the account
  and the single API call before consuming a stored PAT/token.
- **Multi-step ops guides: one step at a time.** For portal/deploy
  walkthroughs, give one action, wait for confirmation, then the next.
- **Don't run git commands against her local repo.** Even read-only
  `git status` / `log` / `diff` should be handed to her to paste. Reading
  files with Read/Grep is still fine.

### Project constraints
- **User's Azure environment** — old VS Enterprise sub CANCELLED; now
  PIM-Contributor on `rg-greenqa-dashboard` in the DEFRA tenant (no UAA,
  Bicep RBAC blocks will fail).
- **WattTime must replace ElectricityMaps by 2026-09-01** — POC shipped
  with a placeholder EM token; WattTime adapter needs to land in
  `green_qa_lib` before the demo window.
- **Daily FA shutdown rule (DEFRA POC)** — stop Function App at EOD, start
  next morning; DEFRA governance rule, do not plan overnight work.
- **SPA local dev loop needs HTTP, not `file://`** — `python -m
  http.server 8000` from repo root; opening via `file://` renders blank
  (Babel XHRs `.jsx` files).

---

## 12. Files to read first when picking up (in order)

1. **This file** — you're already here.
2. **`README.md`** — 100-line human-facing intro.
3. **`GAPS.md`** — mocked vs. real, prod roadmap.
4. **`docs/ARCHITECTURE.md`** — canonical component diagram + data flows
   (§2.1–2.4 spell out the four critical paths).
5. **`CLAUDE.md`** — repo orientation. Note the `green_qa_lib` line is
   stale (see §5.1 above).
6. **`backend/azure/functions/function_app.py`** — single entry point for
   all HTTP routes and timers.
7. **`backend/azure/functions/decision_service.py`** — the resume
   short-circuit + MS-hosted pool constraint (both easy to break).
8. **`backend/azure/functions/cosmos_dal.py`** — mind the in-memory branch.
9. **`azure-pipelines.yml`** — CI/CD shape (Validate + DeployBackend +
   DeploySPA), Kudu zipdeploy specifics, secret list.
10. **`backend/infrastructure/azure/main.bicep`** — single-file IaC; note
    the RBAC blocks that will fail without UAA (see §5.2).

---

## 13. Change log for this HANDOFF file

Update this section when you edit the file so the next agent knows how
fresh it is.

| Date | Author | Change |
|---|---|---|
| 2026-09-01 | Claude (initial) | Created during migration to new machine. Snapshot of `fix/swa-cdn-jsdelivr` @ c7789dc. |
| 2026-09-22 | Claude | Refreshed §5.2 (new DevTest sub activated, Owner role → RBAC blocker resolved). Added §7.4 (VS Code import on DEFRA laptop). Added §14 (where the live-deploy walkthrough left off). Added §15 (PAT creation — GitHub + ADO variants). |
| 2026-09-22 | Claude | Added §16 (onboarding GitHub Copilot on the DEFRA laptop). Created `.github/copilot-instructions.md` as auto-loaded Copilot context. |

---

## 14. Where we left off — live-deploy walkthrough (2026-09-22)

Working through a "make it live in Azure" plan with Saptamita. Current
progress:

- ✅ **Step 1** — Confirmed VS entitlements on my.visualstudio.com:
  VS Enterprise **E6 active till 2026-09-30**, VS Dev Essentials perpetual.
- ✅ **Step 2** — Checked Benefits tab: Azure $150 monthly credit had an
  Activate button.
- ✅ **Step 3** — User activated the credit **under her DEFRA account**.
  New Azure sub created.
- ⏳ **Step 4** — Confirm the new sub in Azure portal (subscription ID,
  name, tenant, role). Interrupted so we could migrate the codebase to the
  DEFRA laptop. **Resume here after import.**

**Remaining plan (resume after §7.4 is complete on the DEFRA laptop):**

- **Step 4 (in-progress)** — In `portal.azure.com` (signed in as DEFRA
  account) → Subscriptions blade → click the new sub → capture:
  - Subscription ID (GUID)
  - Subscription name (usually "Visual Studio Enterprise Subscription")
  - Parent tenant (should be `defra.onmicrosoft.com` or equivalent)
  - Confirm your role is **Owner** via Access control (IAM) →
    Role assignments filtered by your name.
- **Step 5** — Decide PAT(s). Two different kinds may be needed — see §15.
  Recommendation for the **first "just make it visible" cut: skip both**.
  Wire them in after Step 9.
- **Step 6** — Create resource group inside the DevTest sub:
  ```powershell
  az account set --subscription "<sub-id-from-step-4>"
  az group create --name rg-greenqa-poc --location uksouth
  ```
  Do NOT reuse `rg-greenqa-dashboard` (that's the DEFRA-tenant RG; keep it
  clean).
- **Step 7** — Prep parameters for Bicep:
  - Copy `backend/infrastructure/azure/main.parameters.example.json` →
    `main.parameters.dev.json`, fill in.
  - You'll need an `adminObjectId` — get it via
    `az ad signed-in-user show --query id -o tsv`.
  - `electricityMapsToken` — the placeholder value is acceptable for
    first deploy; the Function App will fall back to fixture intensities.
    Replace when the WattTime adapter lands (see §5.4).
  - `adoPat` — pass empty for now; the `resume_deferred` timer will noop
    without it. Add later (§15).
- **Step 8** — Deploy Bicep:
  ```powershell
  cd backend\infrastructure\azure
  az deployment group create `
    --resource-group rg-greenqa-poc `
    --template-file main.bicep `
    --parameters @main.parameters.dev.json
  ```
  Watch for role assignment success — you have Owner so this should work.
- **Step 9** — Deploy code:
  - **Function App**: right-click `backend/azure/functions/function_app.py`
    in VS Code → "Deploy to Function App" (Azure Functions extension) →
    pick the FA the Bicep created. Or use `func azure functionapp publish
    <fa-name>` from that folder.
  - **Static Web App**: `swa deploy --deployment-token <token from
    az staticwebapp secrets list>`, or right-click deploy via the SWA
    extension. Before deploy, generate `config.js` from
    `config.example.js` and populate with the FA URL and function key.
- **Step 10** — Smoke test:
  - Hit `https://<fa-name>.azurewebsites.net/api/carbon?provider=azure` —
    expect JSON response.
  - Open the Static Web App URL — SPA should load, Regions tab should
    flip to `LIVE DATA` badge once `config.js` is deployed.
- **Step 11** — Post-deploy hygiene:
  - Register the DEFRA daily-shutdown schedule (FA stop at EOD, start
    next morning) — Azure Automation runbook or Function Apps → Start/Stop
    schedule.
  - Chase Cognizant admin for VS Enterprise licence renewal **before
    2026-09-30**, or the sub gets disabled ~30 days later.

---

## 15. Creating PATs (Personal Access Tokens)

Two PATs exist in this system. **Only create the one you actually need.**

### 15.1 Azure DevOps PAT — for `resume_deferred` timer

Purpose: lets the Function App re-trigger ADO pipelines whose
`defer_until_iso` has passed. Consumed by `backend/azure/functions/ado_client.py`
via the `AZURE_DEVOPS_PAT` env var or Key Vault secret `KV_SECRET_ADO_PAT`.

Skip this for a first deploy — everything else still works; the deferred-
runs timer just noops when no PAT is present.

Steps:
1. Go to **https://dev.azure.com/<your-org>** and sign in with the same
   identity that owns the pipelines you want to trigger.
2. Top-right → click your avatar → **Personal access tokens**.
3. Click **+ New Token**.
4. Fill in:
   - **Name**: `green-qa-resume-deferred`
   - **Organization**: pick the org that owns the pipelines
   - **Expiration**: 90 days (or the max allowed by org policy)
   - **Scopes**: click **Custom defined** and tick ONLY:
     - **Build** → *Read & execute*
     - (Optional) **Release** → *Read, write, execute* if release triggers
       are needed.
5. Click **Create**. **Copy the token now** — it is shown once and never
   again.
6. Store it:
   - **Preferred** (Bicep already wires this): put in Key Vault:
     ```powershell
     az keyvault secret set `
       --vault-name <kv-name-from-bicep-outputs> `
       --name ado-pat `
       --value <token>
     ```
     The Function App's managed identity has *Key Vault Secrets User* and
     will read it via `KEY_VAULT_URI` + `KV_SECRET_ADO_PAT` env vars.
   - **Local-only fallback**: put under `AZURE_DEVOPS_PAT` in
     `backend/azure/functions/local.settings.json` — do NOT commit.

### 15.2 GitHub PAT — only if you add a GitHub CI path

Purpose: only relevant if you decide to auto-deploy the SPA from a GitHub
repo (Azure SWA supports GitHub Actions integration). The current pipeline
is Azure DevOps (`azure-pipelines.yml`), so this PAT is **not needed** for
the shipped setup.

If you do want it:
1. **https://github.com** → avatar → **Settings** → **Developer settings**
   → **Personal access tokens** → **Fine-grained tokens** → **Generate
   new token**.
2. Fill in:
   - **Token name**: `green-qa-swa-deploy`
   - **Expiration**: 90 days
   - **Repository access**: **Only select repositories** → the GitHub
     mirror of this repo
   - **Repository permissions**:
     - Contents: *Read*
     - Metadata: *Read*
     - Actions: *Read & Write*
     - Deployments: *Read & Write*
3. **Generate token** → copy immediately.
4. In Azure portal → the SWA resource → **Manage deployment token** →
   paste the GitHub token as the source-control credential (this only
   applies if you switched the SWA to GitHub-triggered deployment).

### 15.3 GitHub Enterprise E6 note

Your VS Enterprise E6 includes GitHub Enterprise Cloud. You can create a
PAT there against your Cognizant GHE org if that's where a mirror of this
repo lives — same steps as 15.2, but the URL is your GHE tenant, not
github.com.

---

## 16. Onboarding GitHub Copilot on the DEFRA laptop

On the DEFRA laptop you'll switch from Claude Code to **GitHub Copilot** in
VS Code. Copilot works differently:

- **No persistent per-project memory folder** like `~/.claude/projects/…/memory/`.
- **`.github/copilot-instructions.md`** is the closest equivalent — Copilot
  Chat auto-loads it as system context for every chat in the workspace.
  **This file has been pre-created** with the essential rules and pointers.
  You do not need to draft it.
- **File references** in chat: use `#file:HANDOFF.md` or the `@workspace`
  agent to include repo context. Copilot does not "see" the whole repo
  unless indexing has caught up — pinning files explicitly is more reliable.
- **Model choice**: click the model picker inside the Copilot Chat input
  and select **Claude Sonnet 4.5** (or newer) if available. Better than
  GPT-4o on this Python + React + Bicep mix.

### 16.1 First Copilot Chat prompt after import

Open the workspace in VS Code, open Copilot Chat (Ctrl+Alt+I), and paste
this **verbatim** as the very first message:

> Please read `HANDOFF.md` in full, paying special attention to §14 (where
> we left off) and §5 (blockers). Then read `.github/copilot-instructions.md`
> for the behavioural rules we agreed on. Finally, skim `CLAUDE.md` for
> repo orientation — noting that §5.1 of HANDOFF.md corrects a stale claim
> in CLAUDE.md about `green_qa_lib`.
>
> After reading, do NOT start any work. Reply with:
> (a) a one-line summary of what the current live-deploy step is,
> (b) the three constraints most likely to block the next step, and
> (c) confirmation you understand the "one step at a time" and "no source
>     edits without approval" rules.
>
> I will then tell you to proceed with Step 4.

### 16.2 Resume prompt for Step 4

Once Copilot confirms the read, follow up with:

> Resume the live-deploy walkthrough from §14 Step 4 of `HANDOFF.md`. I am
> signed in to `portal.azure.com` with my DEFRA account. Walk me through
> Step 4 only — do not proceed to Step 5 until I paste back the four items
> you asked for.

### 16.3 Copilot features worth knowing

- **`@workspace`** — asks Copilot to reason about the whole indexed
  workspace. Slower but broader.
- **`@terminal`** — proposes terminal commands. On DEFRA-managed machines
  some `winget`/`az` operations may need admin — Copilot will suggest but
  you run.
- **Copilot Edits** (a.k.a. multi-file edits, Ctrl+Shift+I) — for
  cross-file refactors. Prefer for anything touching >1 file.
- **Copilot Agent mode** (if available in your VS Code build) — runs
  tools autonomously. Enable with caution given the "no source edits
  without approval" rule; keep it in chat-only mode until you trust its
  suggestions on this codebase.

### 16.4 If Copilot drifts from the rules

The behavioural rules in `.github/copilot-instructions.md` are auto-loaded
but Copilot can still forget them mid-session (especially with model
switches). If it starts editing source without asking, or dumping a long
recipe instead of walking step by step, reply:

> Reread `.github/copilot-instructions.md`. Apply rules 1 and 2
> specifically — one step at a time, no source edits without approval.

### 16.5 Files to make sure travel to the DEFRA laptop

Because these are either untracked or gitignored, they will NOT be in
`ZeroCarb.bundle` — copy them separately:

- `HANDOFF.md` (untracked)
- `.github/copilot-instructions.md` (untracked — just created 2026-09-22)
- `backend/azure/functions/local.settings.json` (gitignored; only via
  encrypted channel, or recreate from `.example`)
- Optionally: the Claude memory folder (see §7.4 step 7) — only useful if
  you'll also use Claude Code on the DEFRA laptop; Copilot ignores it.
