import { CognitoJwtVerifier } from 'aws-jwt-verify';
import { timingSafeEqual } from 'node:crypto';
import type { NextFunction, Request, Response } from 'express';
import { appEnv, envList, envStr } from '../config';
import { getSecretStore } from '../lib/secrets';
import { HttpError } from './errors';

export type Role = 'viewer' | 'operator' | 'admin' | 'pipeline';

/**
 * RBAC matrix.
 *  read      dashboards, history, forecast, pure calculators
 *  pipeline  gate calls from CI (decide, store_result)
 *  operate   trigger runs / ingestion
 *  admin     connection management, seeding
 * `pipeline` is a machine role (Cognito client-credentials scope), not a human group.
 */
export type Permission = 'read' | 'pipeline' | 'operate' | 'admin';

const MATRIX: Record<Permission, Role[]> = {
  read: ['viewer', 'operator', 'admin', 'pipeline'],
  pipeline: ['pipeline', 'operator', 'admin'],
  operate: ['operator', 'admin'],
  admin: ['admin'],
};

export interface Principal {
  sub: string;
  username?: string;
  roles: Role[];
}

export interface TokenVerifier {
  verify(token: string): Promise<Record<string, unknown>>;
}

const HUMAN_ROLES: Role[] = ['viewer', 'operator', 'admin'];

export function rolesFromClaims(claims: Record<string, unknown>): Role[] {
  const roles = new Set<Role>();
  const groups = Array.isArray(claims['cognito:groups']) ? (claims['cognito:groups'] as string[]) : [];
  for (const g of groups) if (HUMAN_ROLES.includes(g as Role)) roles.add(g as Role);
  const scopes = String(claims.scope ?? '').split(' ');
  const resource = envStr('RESOURCE_SERVER_ID', 'greenqa');
  if (scopes.includes(`${resource}/pipeline`)) roles.add('pipeline');
  return [...roles];
}

export function cognitoVerifier(): TokenVerifier {
  const userPoolId = envStr('COGNITO_USER_POOL_ID');
  const clientIds = envList('COGNITO_CLIENT_IDS', []);
  if (!userPoolId) throw new Error('COGNITO_USER_POOL_ID is required when AUTH_MODE=cognito');
  // The API Gateway JWT authorizer pins the audience (client ids); here we pin pool + token use, and clients when configured.
  const verifier = CognitoJwtVerifier.create({ userPoolId, tokenUse: 'access', clientId: clientIds.length ? clientIds : null });
  return { verify: async (token) => (await verifier.verify(token)) as unknown as Record<string, unknown> };
}

export type AuthMode = 'cognito' | 'disabled';

export function authMode(): AuthMode {
  const configured = envStr('AUTH_MODE', appEnv() === 'local' ? 'disabled' : 'cognito').toLowerCase();
  const mode: AuthMode = configured === 'disabled' ? 'disabled' : 'cognito';
  if (mode === 'disabled' && (appEnv() === 'uat' || appEnv() === 'prod')) {
    throw new Error(`AUTH_MODE=disabled is not permitted when APP_ENV=${appEnv()}`);
  }
  return mode;
}

export function authenticate(mode: AuthMode, verifier?: TokenVerifier) {
  const tv = mode === 'cognito' ? (verifier ?? cognitoVerifier()) : undefined;
  return async (req: Request, _res: Response, next: NextFunction) => {
    try {
      if (!tv) {
        req.principal = { sub: 'local-dev', username: 'local-dev', roles: ['admin'] };
        return next();
      }
      const header = req.header('authorization') ?? '';
      const [scheme, token] = header.split(' ');
      if (scheme?.toLowerCase() !== 'bearer' || !token) throw new HttpError(401, 'unauthorized');
      let claims: Record<string, unknown>;
      try {
        claims = await tv.verify(token);
      } catch {
        throw new HttpError(401, 'unauthorized');
      }
      req.principal = {
        sub: String(claims.sub ?? claims.client_id ?? 'unknown'),
        username: claims.username ? String(claims.username) : undefined,
        roles: rolesFromClaims(claims),
      };
      next();
    } catch (err) {
      next(err);
    }
  };
}

export const requirePermission = (permission: Permission) => (req: Request, _res: Response, next: NextFunction) => {
  const roles = req.principal?.roles ?? [];
  if (!roles.some((r) => MATRIX[permission].includes(r))) return next(new HttpError(403, 'forbidden', { required: permission }));
  next();
};

/** Constant-time check of the ADO Service Hook shared secret (header or Basic-auth password). */
export async function verifyWebhook(req: Request, mode: AuthMode): Promise<boolean> {
  const secret = await getSecretStore().get('webhook_secret');
  if (!secret) return mode === 'disabled';
  let presented = req.header('x-greenqa-webhook-secret') ?? '';
  const basic = /^Basic (.+)$/i.exec(req.header('authorization') ?? '');
  if (!presented && basic) presented = Buffer.from(basic[1], 'base64').toString().split(':').slice(1).join(':');
  const a = Buffer.from(presented);
  const b = Buffer.from(secret);
  return a.length === b.length && timingSafeEqual(a, b);
}
