import { createHash } from 'node:crypto';
import { envBool, envFloat } from '../config';
import { httpGetJson } from '../lib/http';
import { logger } from '../logger';
import { DEFAULT_CARBON_INTENSITY_GCO2_KWH, PUE_VALUES, REGION_INTENSITY_GCO2_KWH } from './constants';
import { getProvider, type Provider } from './providers';
import { round } from './sci';

export interface IntensityReading {
  grid_intensity: number; // raw grid g/kWh (before PUE)
  carbon_intensity: number; // datacenter g/kWh (grid * PUE)
  renewable_percentage: number; // 0..1
  zone: string;
  aws_pue: number; // provider PUE (name kept for contract parity)
}

export type ReadingResult = [IntensityReading | null, string];

export interface IntensityClient {
  getRegionIntensity(regionCode: string): Promise<ReadingResult>;
}

export interface ForecastPeriod {
  hour: number;
  intensity_gco2_kwh: number;
  from?: string | null;
  is_optimal?: boolean;
}

// Region code -> NESO regionid. Only GB regions are covered; the rest use ElectricityMaps.
export const NESO_REGION_MAP: Record<string, number> = {
  uksouth: 13, // London
  ukwest: 7, // South Wales
  'eu-west-2': 13, // AWS London
};

function safeProvider(name: string): Provider {
  try {
    return getProvider(name || 'azure');
  } catch {
    return getProvider('azure');
  }
}

export class ElectricityMapsClient implements IntensityClient {
  static readonly BASE_URL = 'https://api.electricitymap.org/v3/carbon-intensity/latest';
  private readonly token: string;
  private readonly provider: Provider;
  private readonly pue: number;

  constructor(token?: string | null, providerName = 'azure') {
    this.token = (token ?? '').trim();
    this.provider = safeProvider(providerName);
    this.pue = PUE_VALUES[this.provider.name] ?? 1.185;
  }

  private zoneAndRenewable(regionCode: string): [string, number] {
    const region = this.provider.listRegions().find((r) => r.code === regionCode);
    return region ? [region.electricitymaps_zone, region.dc_metrics.renewable_pct] : [regionCode, 0.4];
  }

  private async liveIntensity(zone: string): Promise<number | null> {
    // Live calls are opt-in so tests with placeholder tokens stay deterministic.
    if (!this.token || !envBool('ELECTRICITYMAPS_USE_LIVE')) return null;
    const data = await httpGetJson<{ carbonIntensity?: number }>(
      `${ElectricityMapsClient.BASE_URL}?zone=${encodeURIComponent(zone)}`,
      envFloat('ELECTRICITYMAPS_TIMEOUT', 5) * 1000,
      { 'auth-token': this.token },
    );
    const v = Number(data?.carbonIntensity);
    return data && Number.isFinite(v) ? v : null;
  }

  async getRegionIntensity(regionCode: string): Promise<ReadingResult> {
    const [zone, renewable] = this.zoneAndRenewable(regionCode);
    const live = await this.liveIntensity(zone);
    const grid = live ?? (REGION_INTENSITY_GCO2_KWH[regionCode] ?? DEFAULT_CARBON_INTENSITY_GCO2_KWH);
    return [
      {
        grid_intensity: grid,
        carbon_intensity: round(grid * this.pue, 3),
        renewable_percentage: renewable,
        zone,
        aws_pue: this.pue,
      },
      live !== null ? 'electricitymaps' : 'baseline',
    ];
  }
}

interface NesoPeriod {
  from?: string;
  to?: string;
  intensity?: { forecast?: number; actual?: number };
  generationmix?: { fuel?: string; perc?: number }[];
}

export class NesoClient implements IntensityClient {
  static readonly BASE_URL = 'https://api.carbonintensity.org.uk/regional/regionid';
  private readonly provider: Provider;
  private readonly pue: number;

  constructor(providerName = 'azure') {
    this.provider = safeProvider(providerName);
    this.pue = PUE_VALUES[this.provider.name] ?? 1.185;
  }

  private renewableFor(regionCode: string): number {
    return this.provider.listRegions().find((r) => r.code === regionCode)?.dc_metrics.renewable_pct ?? 0.5;
  }

  async getRegionIntensity(regionCode: string): Promise<ReadingResult> {
    const regionId = NESO_REGION_MAP[regionCode];
    if (regionId === undefined) return [null, 'neso_unsupported_region'];

    const data = envBool('NESO_USE_LIVE')
      ? await httpGetJson<{ data?: { shortname?: string; data?: NesoPeriod[] }[] }>(
        `${NesoClient.BASE_URL}/${regionId}`, envFloat('NESO_TIMEOUT', 5) * 1000)
      : null;

    let renewable = this.renewableFor(regionCode);
    let grid: number | null = null;
    let zone = `GB-region-${regionId}`;

    const first = Array.isArray(data?.data) ? data.data[0] : undefined;
    if (first && typeof first === 'object') {
      const periods = Array.isArray(first.data) ? first.data : [];
      const latest = periods[periods.length - 1];
      if (latest) {
        const val = latest.intensity?.forecast ?? latest.intensity?.actual;
        if (val !== undefined && val !== null && Number.isFinite(Number(val))) grid = Number(val);
        const renewables = (latest.generationmix ?? [])
          .filter((m) => ['wind', 'solar', 'hydro', 'biomass', 'nuclear'].includes(m.fuel ?? ''))
          .reduce((s, m) => s + Number(m.perc ?? 0), 0);
        if (renewables > 0) renewable = renewables / 100;
      }
      zone = first.shortname || zone;
    }

    const source = grid === null ? 'baseline' : 'neso';
    const g = grid ?? (REGION_INTENSITY_GCO2_KWH[regionCode] ?? DEFAULT_CARBON_INTENSITY_GCO2_KWH);
    return [
      { grid_intensity: g, carbon_intensity: round(g * this.pue, 3), renewable_percentage: renewable, zone, aws_pue: this.pue },
      source,
    ];
  }

  /** 48 half-hour forecast slots (empty when NESO is unavailable or live calls are off). */
  async getRegionForecast24h(regionCode: string): Promise<{ slot: number; intensity_gco2_kwh: number; from?: string; to?: string; is_optimal?: boolean }[]> {
    const regionId = NESO_REGION_MAP[regionCode];
    if (regionId === undefined || !envBool('NESO_USE_LIVE')) return [];

    const fromIso = new Date().toISOString().slice(0, 16) + 'Z';
    const data = await httpGetJson<{ data?: { data?: NesoPeriod[] } }>(
      `https://api.carbonintensity.org.uk/regional/intensity/${fromIso}/fw24h/regionid/${regionId}`,
      envFloat('NESO_TIMEOUT', 5) * 1000,
    );
    const periods = data?.data && !Array.isArray(data.data) ? data.data.data : undefined;
    if (!Array.isArray(periods)) return [];

    const out: { slot: number; intensity_gco2_kwh: number; from?: string; to?: string; is_optimal?: boolean }[] = [];
    periods.slice(0, 48).forEach((p, i) => {
      const v = Number(p?.intensity?.forecast);
      if (Number.isFinite(v)) out.push({ slot: i, intensity_gco2_kwh: v, from: p.from, to: p.to });
    });
    if (out.length) {
      const min = Math.min(...out.map((p) => p.intensity_gco2_kwh));
      for (const p of out) p.is_optimal = p.intensity_gco2_kwh <= min * 1.05;
    }
    return out;
  }
}

/** UK regions -> NESO, everything else -> ElectricityMaps. */
export function getRegionIntensityClient(regionCode: string, opts: { token?: string | null; provider?: string } = {}): IntensityClient {
  if (regionCode in NESO_REGION_MAP) return new NesoClient(opts.provider ?? 'azure');
  return new ElectricityMapsClient(opts.token, opts.provider ?? 'azure');
}

function markOptimal(periods: ForecastPeriod[]): void {
  if (!periods.length) return;
  const min = Math.min(...periods.map((p) => p.intensity_gco2_kwh));
  for (const p of periods) p.is_optimal = p.intensity_gco2_kwh <= min * 1.05;
}

/** Collapse NESO's 48 half-hour slots into 24 hourly averages. */
export function aggregateHourly(raw: { intensity_gco2_kwh?: number; from?: string }[]): ForecastPeriod[] {
  const hours: ForecastPeriod[] = [];
  for (let h = 0; h < 24; h++) {
    const pair = [raw[2 * h], raw[2 * h + 1]].filter((p) => p !== undefined);
    const vals = pair.map((p) => p.intensity_gco2_kwh).filter((v): v is number => typeof v === 'number');
    if (!vals.length) continue;
    hours.push({
      hour: h,
      intensity_gco2_kwh: round(vals.reduce((a, b) => a + b, 0) / vals.length, 1),
      from: pair[0].from ?? null,
    });
  }
  markOptimal(hours);
  return hours;
}

/** Deterministic two-peak diurnal curve, phase/amplitude hashed from the region code. */
export function synthForecast(region: string, base: number): ForecastPeriod[] {
  const seed = Number.parseInt(createHash('sha1').update(region).digest('hex').slice(0, 8), 16);
  const phase = ((seed % 24) / 24) * 2 * Math.PI;
  const amp = 0.35 + (seed % 7) / 40;
  const periods: ForecastPeriod[] = [];
  for (let h = 0; h < 24; h++) {
    const diurnal = Math.sin((h / 24) * 2 * Math.PI - phase);
    const evening = 0.4 * Math.sin((h / 24) * 4 * Math.PI - phase);
    const factor = 1 + (amp * (diurnal + evening)) / 1.4;
    periods.push({ hour: h, intensity_gco2_kwh: round(Math.max(5, base * factor), 1) });
  }
  markOptimal(periods);
  return periods;
}

/** [periods, source] — NESO where covered, otherwise a modelled curve scaled to the latest intensity. */
export async function getRegionForecast(
  region: string,
  provider = 'azure',
  baseIntensity?: number | null,
): Promise<[ForecastPeriod[], string]> {
  if (region in NESO_REGION_MAP) {
    let raw: Awaited<ReturnType<NesoClient['getRegionForecast24h']>> = [];
    try {
      raw = await new NesoClient(provider).getRegionForecast24h(region);
    } catch (err) {
      logger.error({ err, region }, 'get_region_forecast: NESO call failed');
    }
    if (raw.length) return [aggregateHourly(raw), 'neso'];
  }
  const base = typeof baseIntensity === 'number' && baseIntensity > 0
    ? baseIntensity
    : (REGION_INTENSITY_GCO2_KWH[region] ?? DEFAULT_CARBON_INTENSITY_GCO2_KWH);
  return [synthForecast(region, base), 'modelled'];
}
