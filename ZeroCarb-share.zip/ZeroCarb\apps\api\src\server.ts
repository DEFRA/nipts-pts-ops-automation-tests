import { createApp } from './app';
import { appEnv, envInt } from './config';
import { logger } from './logger';
import { getRepository } from './repo';
import { ingestCarbonOnce } from './services/ingestService';
import { resumeDeferred } from './services/adoSync';

// Long-running entrypoint for local development and container deployments (ECS/EKS).
const port = envInt('PORT', 7071);
const app = createApp();
const server = app.listen(port, () => logger.info({ port, env: appEnv() }, 'zerocarb-api listening'));

// Local stand-in for the EventBridge schedules used in AWS (set RUN_TIMERS=false to disable).
if (process.env.RUN_TIMERS !== 'false' && appEnv() === 'local') {
  const repo = getRepository();
  const safe = (name: string, fn: () => Promise<unknown>) => () => fn().catch((err) => logger.error({ err }, `${name} failed`));
  safe('ingest_carbon', () => ingestCarbonOnce(repo))();
  setInterval(safe('ingest_carbon', () => ingestCarbonOnce(repo)), 30 * 60_000).unref();
  setInterval(safe('resume_deferred', () => resumeDeferred(repo)), 5 * 60_000).unref();
}

const shutdown = (signal: string) => {
  logger.info({ signal }, 'shutting down');
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(1), 10_000).unref();
};
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
