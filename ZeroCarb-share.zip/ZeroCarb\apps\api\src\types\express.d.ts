import type { Principal } from '../http/auth';

declare global {
  namespace Express {
    interface Request {
      principal?: Principal;
      requestId?: string;
    }
  }
}

export {};
