export type DeployEnv = 'dev' | 'uat' | 'prod';

export interface EnvConfig {
  name: DeployEnv;
  /** Primary region for the application stacks. */
  region: string;
  /** Keep stateful resources (tables, user pool, secrets) when the stack is deleted. */
  retainData: boolean;
  logRetentionDays: number;
  mfa: 'OFF' | 'OPTIONAL' | 'REQUIRED';
  /** Alarm notifications; omit to create the topic without a subscriber. */
  alarmEmail?: string;
  api: { throttleRate: number; throttleBurst: number; lambdaMemoryMb: number; reservedConcurrency?: number };
  /** Requests per 5 minutes per client IP before WAF blocks. */
  wafRateLimit: number;
  /** DynamoDB global-table replicas for regional disaster recovery. */
  replicaRegions: string[];
  /** Optional custom domain (certificate is issued in us-east-1 for CloudFront). */
  domain?: { name: string; hostedZoneId: string; hostedZoneName: string };
  /** Extra Cognito callback origins (e.g. http://localhost:8080 for local SPA against a dev stack). */
  extraCallbackOrigins: string[];
  app: {
    adoOrgUrl: string;
    adoProject: string;
    adoPipelineIds: string;
    executionRegions: string;
    devSeedEnabled: boolean;
    liveCarbonSources: boolean;
  };
}

const base = {
  region: 'eu-west-2',
  replicaRegions: [] as string[],
  extraCallbackOrigins: [] as string[],
  app: {
    adoOrgUrl: 'https://dev.azure.com/defragovuk',
    adoProject: 'CCTS QAT',
    adoPipelineIds: '12323,12324',
    executionRegions: 'uksouth,ukwest',
    devSeedEnabled: false,
    liveCarbonSources: true,
  },
};

export const ENVIRONMENTS: Record<DeployEnv, EnvConfig> = {
  dev: {
    ...base,
    name: 'dev',
    retainData: false,
    logRetentionDays: 14,
    mfa: 'OFF',
    api: { throttleRate: 50, throttleBurst: 100, lambdaMemoryMb: 512 },
    wafRateLimit: 2000,
    extraCallbackOrigins: ['http://localhost:8080'],
    app: { ...base.app, devSeedEnabled: true },
  },
  uat: {
    ...base,
    name: 'uat',
    retainData: true,
    logRetentionDays: 30,
    mfa: 'OPTIONAL',
    api: { throttleRate: 100, throttleBurst: 200, lambdaMemoryMb: 512 },
    wafRateLimit: 2000,
  },
  prod: {
    ...base,
    name: 'prod',
    retainData: true,
    logRetentionDays: 400,
    mfa: 'REQUIRED',
    api: { throttleRate: 500, throttleBurst: 1000, lambdaMemoryMb: 1024 },
    wafRateLimit: 1000,
    // Global tables give a warm standby for the data tier (see docs/AWS_ARCHITECTURE.md, DR).
    replicaRegions: ['eu-west-1'],
  },
};

export function resolveEnv(name: string | undefined): EnvConfig {
  const key = (name ?? 'dev') as DeployEnv;
  const cfg = ENVIRONMENTS[key];
  if (!cfg) throw new Error(`Unknown environment "${name}". Expected one of: ${Object.keys(ENVIRONMENTS).join(', ')}`);
  return cfg;
}
