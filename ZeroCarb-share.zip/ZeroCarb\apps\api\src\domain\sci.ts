import { EMBODIED_GCO2_PER_VCPU_HOUR, MEMORY_KWH_PER_GB_HOUR, VCPU_KWH_PER_HOUR } from './constants';

export function round(value: number, digits: number): number {
  const f = 10 ** digits;
  return Math.round((value + Number.EPSILON) * f) / f;
}

/** Energy (kWh) = vCPU-hours * kWh/vCPU-h + GB-hours * kWh/GB-h. */
export function calculateEnergyKwh(durationSeconds: number, vcpuCount: number, memoryGb: number): number {
  if (durationSeconds <= 0) return 0;
  const hours = durationSeconds / 3600;
  return vcpuCount * hours * VCPU_KWH_PER_HOUR + memoryGb * hours * MEMORY_KWH_PER_GB_HOUR;
}

/** Amortised embodied carbon (gCO2) for the vCPUs used during the run. */
export function calculateEmbodiedCarbon(vcpuCount: number, durationHours: number, _provider = 'azure'): number {
  if (durationHours <= 0 || vcpuCount <= 0) return 0;
  return vcpuCount * durationHours * EMBODIED_GCO2_PER_VCPU_HOUR;
}

export interface SciBreakdown {
  operational_emissions_g: number;
  embodied_emissions_g: number;
  total_emissions_g: number;
  functional_unit: number;
  method: string;
}

/** SCI = ((E * I) + M) / R  (GSF Software Carbon Intensity). */
export function calculateSci(
  energyKwh: number,
  carbonIntensity: number,
  embodiedCarbonG: number,
  functionalUnit = 1,
): [number, SciBreakdown] {
  const operational = Math.max(0, energyKwh * carbonIntensity);
  const embodied = Math.max(0, embodiedCarbonG);
  const total = operational + embodied;
  const unit = Math.max(1, Math.trunc(functionalUnit));
  return [
    total / unit,
    {
      operational_emissions_g: round(operational, 6),
      embodied_emissions_g: round(embodied, 6),
      total_emissions_g: round(total, 6),
      functional_unit: unit,
      method: 'SCI-v1.0',
    },
  ];
}
