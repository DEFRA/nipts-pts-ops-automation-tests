import { afterEach, describe, expect, it, vi } from 'vitest';
import { checkBudget } from '../src/domain/budget';
import { aggregateHourly, synthForecast } from '../src/domain/carbonApi';
import { executionRegions, getProvider } from '../src/domain/providers';
import { calculateEmbodiedCarbon, calculateEnergyKwh, calculateSci } from '../src/domain/sci';
import { SchedulingEngine } from '../src/domain/schedulingEngine';
import * as energyCharts from '../src/domain/energyCharts';

afterEach(() => { vi.unstubAllGlobals(); delete process.env.GREENQA_EXECUTION_REGIONS; });

describe('sci', () => {
  it('computes energy from vCPU-hours and GB-hours', () => {
    // 2*0.05 + 4*0.0004 = 0.1016 kWh
    expect(calculateEnergyKwh(3600, 2, 4)).toBeCloseTo(0.1016, 6);
    // 4 vCPU, 8 GB, 20 min => ~0.0677 kWh
    expect(calculateEnergyKwh(1200, 4, 8)).toBeCloseTo(0.06773, 5);
    expect(calculateEnergyKwh(0, 2, 4)).toBe(0);
  });

  it('amortises embodied carbon and returns an SCI breakdown', () => {
    const embodied = calculateEmbodiedCarbon(2, 1);
    expect(embodied).toBe(1);
    const [sci, b] = calculateSci(0.0216, 100, embodied, 1);
    expect(b.operational_emissions_g).toBeCloseTo(2.16, 6);
    expect(sci).toBeCloseTo(3.16, 6);
    expect(calculateSci(1, 1, 0, 0)[1].functional_unit).toBe(1);
  });
});

describe('budget', () => {
  const budget = { name: 'b', budget_gco2_per_run: 100, budget_gco2_per_transaction: 2, warn_at_percent: 80 };
  it('passes, warns and fails by usage', () => {
    expect(checkBudget(50, 0, budget).status).toBe('pass');
    expect(checkBudget(85, 0, budget).status).toBe('warn');
    const fail = checkBudget(100, 0, budget);
    expect(fail.status).toBe('fail');
    expect(fail.passed).toBe(false);
  });
  it('uses the per-transaction limit when a transaction count is given', () => {
    const r = checkBudget(10, 5, budget); // limit 10g
    expect(r.budget_gco2).toBe(10);
    expect(r.status).toBe('fail');
  });
  it('reports no_budget without a limit', () => {
    expect(checkBudget(10).status).toBe('no_budget');
    expect(checkBudget(10, 0, { name: 'x', warn_at_percent: 80 }).status).toBe('no_budget');
  });
});

describe('providers', () => {
  it('rejects unknown providers', () => expect(() => getProvider('gcp')).toThrow(/Unknown provider/));
  it('defaults execution regions and honours the override', () => {
    expect(executionRegions('azure')).toEqual(['uksouth', 'ukwest']);
    process.env.GREENQA_EXECUTION_REGIONS = 'uksouth,bogus';
    expect(executionRegions('azure')).toEqual(['uksouth']);
  });
});

describe('forecast', () => {
  it('synthesises 24 deterministic hourly points per region', () => {
    const a = synthForecast('uksouth', 160);
    expect(a).toHaveLength(24);
    expect(synthForecast('uksouth', 160)).toEqual(a);
    expect(synthForecast('ukwest', 160)).not.toEqual(a);
    expect(a.some((p) => p.is_optimal)).toBe(true);
  });
  it('aggregates half-hour slots to hourly means', () => {
    const raw = Array.from({ length: 48 }, (_, i) => ({ intensity_gco2_kwh: i % 2 === 0 ? 100 : 200, from: `t${i}` }));
    const hourly = aggregateHourly(raw);
    expect(hourly).toHaveLength(24);
    expect(hourly[0].intensity_gco2_kwh).toBe(150);
  });
});

describe('SchedulingEngine', () => {
  const forecast = [{ hour: 3, intensity_gco2_kwh: 80 }, { hour: 20, intensity_gco2_kwh: 10 }];

  it('never shifts critical workloads', () => {
    const d = new SchedulingEngine({ provider: 'azure' }).getOptimalStrategy('p', 'ukwest', 'critical');
    expect(d.recommended_strategy).toBe('run_now');
  });

  it('time-shifts within the defer window using the forecast', () => {
    const engine = new SchedulingEngine({ provider: 'azure', allowedRegions: ['uksouth'], regionForecasts: { uksouth: forecast } });
    const d = engine.getOptimalStrategy('p', 'uksouth', 'normal');
    expect(d.recommended_strategy).toBe('time_shift');
    expect(d.wait_hours).toBe(3); // hour 20 is outside MAX_DEFER_HOURS=12
    expect(d.scheduled_time).toBeInstanceOf(Date);
  });

  it('space-shifts to the cleanest allowed region', () => {
    const engine = new SchedulingEngine({
      provider: 'azure', allowedRegions: ['uksouth', 'ukwest'], regionIntensities: { uksouth: 400, ukwest: 100 },
    });
    const d = engine.getOptimalStrategy('p', 'uksouth', 'normal');
    expect(d.recommended_strategy).toBe('space_shift');
    expect(d.target_region).toBe('ukwest');
    expect(d.carbon_savings_percent).toBe(75);
  });

  it('goes hybrid only for LOW criticality', () => {
    const opts = { provider: 'azure', allowedRegions: ['uksouth', 'ukwest'], regionIntensities: { uksouth: 400, ukwest: 100 }, regionForecasts: { uksouth: [{ hour: 2, intensity_gco2_kwh: 50 }] } };
    expect(new SchedulingEngine(opts).getOptimalStrategy('p', 'uksouth', 'low').recommended_strategy).toBe('hybrid');
    // Non-LOW workloads pick the single deeper saving (here the 87.5% forecast dip beats the 75% region gap).
    expect(new SchedulingEngine(opts).getOptimalStrategy('p', 'uksouth', 'normal').recommended_strategy).toBe('time_shift');
  });

  it('runs now when nothing clears the savings threshold', () => {
    const d = new SchedulingEngine({ provider: 'azure', allowedRegions: ['uksouth'] }).getOptimalStrategy('p', 'uksouth');
    expect(d.recommended_strategy).toBe('run_now');
  });
});

describe('energy-charts', () => {
  const series = (name: string, data: (number | null)[]) => ({ name, data });
  it('derives a generation-weighted intensity and ignores trailing nulls', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response(JSON.stringify({
      production_types: [
        series('Nuclear', [100, 100, null]),
        series('Fossil gas', [100, 100, null]),
        series('Load', [999, 999, null]),
        series('Renewable share of generation', [40, 50, null]),
      ],
    }))));
    const [reading, source] = await energyCharts.getRegionIntensity('francecentral');
    expect(source).toBe('energy_charts');
    expect(reading?.grid_intensity).toBe(251); // (12 + 490) / 2
    expect(reading?.renewable_percentage).toBe(0.5);
  });

  it('reports a reason on failure', async () => {
    vi.stubGlobal('fetch', vi.fn(async () => new Response('nope', { status: 429 })));
    expect((await energyCharts.getRegionIntensity('francecentral'))[1]).toBe('energy_charts_unavailable');
    expect((await energyCharts.getRegionIntensity('uksouth'))[1]).toBe('energy_charts_unsupported_region');
  });
});
