/* global React */
// =======================================================================
// Atoms & helpers
// =======================================================================

const heatClass = (v) => {
  if (v <= 50)   return 'heat-0';
  if (v <= 150)  return 'heat-1';
  if (v <= 250)  return 'heat-2';
  if (v <= 400)  return 'heat-3';
  return 'heat-4';
};

const fmtNum = (n, opts) => {
  const { dp = 0, suffix = '' } = opts || {};
  if (n == null || isNaN(n)) return '—';
  if (Math.abs(n) >= 1e6) return (n / 1e6).toFixed(1) + 'M' + suffix;
  if (Math.abs(n) >= 1e3) return (n / 1e3).toFixed(dp || 1) + 'k' + suffix;
  return n.toFixed(dp) + suffix;
};

const fmtG = (g) => {
  if (g == null) return '—';
  if (Math.abs(g) >= 1000) return (g / 1000).toFixed(2) + ' kg';
  return g.toFixed(1) + ' g';
};

const fmtMoney = (n) => '$' + n.toLocaleString('en-GB', { maximumFractionDigits: 0 });

// Sparkline as SVG polyline
function Sparkline({ data, width = 90, height = 24, stroke = '#0b0c0c', fill = false }) {
  if (!data || !data.length) return null;
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const stepX = width / (data.length - 1);
  const points = data.map((v, i) => {
    const x = i * stepX;
    const y = height - ((v - min) / range) * (height - 2) - 1;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  });
  const last = data[data.length - 1];
  const lastX = (data.length - 1) * stepX;
  const lastY = height - ((last - min) / range) * (height - 2) - 1;
  return (
    <svg className="sparkline" width={width} height={height} viewBox={`0 0 ${width} ${height}`} aria-hidden="true">
      {fill && (
        <polygon points={`0,${height} ${points.join(' ')} ${width},${height}`} fill={stroke} opacity="0.08" />
      )}
      <polyline points={points.join(' ')} fill="none" stroke={stroke} strokeWidth="1.5" />
      <circle cx={lastX} cy={lastY} r="2.5" fill={stroke} />
    </svg>
  );
}

// GOV.UK crown SVG (simplified)
function GovCrown() {
  return (
    <svg className="ccd-brand-crown" viewBox="0 0 132 97" fill="none" aria-hidden="true">
      <g fill="#ffffff">
        <circle cx="20" cy="17" r="8"/>
        <circle cx="66" cy="9"  r="8"/>
        <circle cx="112" cy="17" r="8"/>
        <circle cx="44" cy="30" r="5"/>
        <circle cx="88" cy="30" r="5"/>
        <path d="M14 38 L118 38 L112 58 L20 58 Z"/>
        <path d="M10 60 L122 60 L116 88 L16 88 Z"/>
        <rect x="62" y="44" width="8" height="10"/>
      </g>
    </svg>
  );
}

// Trend arrow
function Trend({ value, invert }) {
  // invert = true means a negative is good (e.g. emissions going down)
  const up = value > 0;
  const good = invert ? !up : up;
  const sym = up ? '▲' : '▼';
  return (
    <span style={{ color: good ? 'var(--gov-green)' : 'var(--gov-red)', fontWeight: 700 }}>
      {sym} {Math.abs(value).toFixed(1)}%
    </span>
  );
}

// Tag
function Tag({ children, color = 'default' }) {
  return <span className={'ccd-tag ' + (color === 'default' ? '' : color)}>{children}</span>;
}

// Build dot
function BuildDot({ status }) {
  return <span className={'build-dot ' + status} aria-label={status} />;
}

// Page header — one bold title + concise subtitle + optional right-side actions.
// Used at the top of every primary tab so visual hierarchy is consistent.
function PageHeader({ title, subtitle, actions }) {
  return (
    <header className="page-header">
      <div className="page-header-text">
        <h1 className="page-header-title">{title}</h1>
        {subtitle && <p className="page-header-subtitle">{subtitle}</p>}
      </div>
      {actions && <div className="page-header-actions">{actions}</div>}
    </header>
  );
}

window.Atoms = {
  heatClass, fmtNum, fmtG, fmtMoney,
  Sparkline, GovCrown, Trend, Tag, BuildDot, PageHeader
};
