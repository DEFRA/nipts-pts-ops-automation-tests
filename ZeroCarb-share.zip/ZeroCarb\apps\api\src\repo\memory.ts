import {
  CONNECTION_ID,
  type AuditEvent, type CarbonSample, type ConnectionRecord, type DeferredRecord, type ExecutionRecord, type Repository,
} from './types';

const byStoredAtDesc = (a: ExecutionRecord, b: ExecutionRecord) => (b.stored_at ?? '').localeCompare(a.stored_at ?? '');

/** Map-backed repository for local development and tests. Not durable. */
export class MemoryRepository implements Repository {
  private carbon = new Map<string, CarbonSample>();
  private executions = new Map<string, ExecutionRecord>();
  private deferred = new Map<string, DeferredRecord>();
  private connections = new Map<string, ConnectionRecord>();
  readonly audit: AuditEvent[] = [];

  async upsertCarbonSample(s: CarbonSample) { this.carbon.set(s.id, { ...s }); return { ...s }; }
  async upsertExecution(e: ExecutionRecord) { this.executions.set(`${e.pipeline_id}|${e.id}`, { ...e }); return { ...e }; }
  async upsertDeferred(d: DeferredRecord) { this.deferred.set(d.id, { ...d }); return { ...d }; }

  async getDeferred(id: string) { const d = this.deferred.get(id); return d ? { ...d } : null; }

  async listPendingDeferred(nowIso: string) {
    return [...this.deferred.values()]
      .filter((r) => r.status === 'pending' && (r.defer_until_iso ?? '') !== '' && (r.defer_until_iso as string) <= nowIso)
      .sort((a, b) => (a.defer_until_iso as string).localeCompare(b.defer_until_iso as string))
      .map((r) => ({ ...r }));
  }

  async listExecutionsForPipeline(pipelineId: string, provider: string, limit: number) {
    return [...this.executions.values()]
      .filter((r) => r.pipeline_id === pipelineId && r.provider === provider)
      .sort(byStoredAtDesc).slice(0, limit).map((r) => ({ ...r }));
  }

  async listAllExecutions(provider: string, limit: number) {
    return [...this.executions.values()].filter((r) => r.provider === provider)
      .sort(byStoredAtDesc).slice(0, limit).map((r) => ({ ...r }));
  }

  async listExecutionsSince(provider: string, sinceIso: string) {
    return [...this.executions.values()]
      .filter((r) => r.provider === provider && (r.stored_at ?? '') >= sinceIso).map((r) => ({ ...r }));
  }

  async getLatestCarbon(provider: string, region: string) {
    let best: CarbonSample | null = null;
    for (const s of this.carbon.values()) {
      if (s.provider === provider && s.region === region && (!best || s.sampled_at > best.sampled_at)) best = s;
    }
    return best ? { ...best } : null;
  }

  async latestCarbonByRegion(provider: string, regions: string[]) {
    const out: Record<string, CarbonSample> = {};
    for (const region of regions) {
      const s = await this.getLatestCarbon(provider, region);
      if (s) out[region] = s;
    }
    return out;
  }

  async upsertConnection(c: ConnectionRecord, id: string = CONNECTION_ID) { const rec = { ...c, id }; this.connections.set(id, rec); return { ...rec }; }
  async getConnection(id: string = CONNECTION_ID) { const c = this.connections.get(id); return c ? { ...c } : null; }
  async deleteConnection(id: string = CONNECTION_ID) { this.connections.delete(id); }

  async putAudit(event: AuditEvent) { this.audit.push(event); }
  async ping() { /* always healthy */ }
}
