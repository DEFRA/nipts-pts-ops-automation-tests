/* global React, ReactDOM, CCD_DATA, Atoms,
   LedgerMasthead, PipelinesTable, RegionsAndForecast,
   ResearchWatcherPanel, GlossaryPanel,
   SettingsModal, ConfigProvider, useConfig, usePolling,
   StoreProvider, useStore, AzureConfigModal, ConnectAzureModal, CloudConfigModal,
   TweaksPanel, useTweaks, TweakSection, TweakRadio, TweakToggle */

const { GovCrown } = Atoms;

// Feature flags — overridable via config.js (window.CCD_FEATURES).
// research: PHASE-2, hidden for now. Code retained in research.jsx.
const CCD_FEATURES = Object.assign({ research: false }, (window.CCD_FEATURES || {}));

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "govuk",
  "density": "comfortable",
  "range": "30d",
  "provider": "azure",
  "layout": "manager",
  "show_money": true,
  "home_region": "uksouth"
}/*EDITMODE-END*/;

// -----------------------------------------------------------------------
// Tab definitions — single source of truth.
// Research is PHASE-2: only included when the feature flag is enabled.
// -----------------------------------------------------------------------
const TABS = [
  { id: 'overview',   label: 'Overview',   group: 'main' },
  { id: 'pipelines',  label: 'Pipelines',  group: 'main' },
  { id: 'regions',    label: 'Regions',    group: 'main' },
  ...(CCD_FEATURES.research ? [{ id: 'research', label: 'Research', group: 'main' }] : []),
  { id: 'glossary',   label: 'Glossary',   group: 'main' }
];

function App() {
  const [tweaks, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    document.documentElement.setAttribute('data-theme', tweaks.theme);
    document.documentElement.setAttribute('data-density', tweaks.density);
    document.documentElement.setAttribute('data-provider', tweaks.provider);
  }, [tweaks.theme, tweaks.density, tweaks.provider]);

  return (
    <ConfigProvider>
      <StoreProvider tweaks={tweaks} setTweak={setTweak}>
        <AppShell tweaks={tweaks} setTweak={setTweak} />
      </StoreProvider>
    </ConfigProvider>
  );
}

// -----------------------------------------------------------------------
// Hash-routed tabs (e.g. #/pipelines, #/azure). Falls back to "overview".
// -----------------------------------------------------------------------
function useTabRoute() {
  const parse = () => {
    const h = (window.location.hash || '').replace(/^#\/?/, '').split('?')[0];
    return TABS.find(t => t.id === h) ? h : 'overview';
  };
  const [tab, setTab] = React.useState(parse);
  React.useEffect(() => {
    const onHash = () => setTab(parse());
    window.addEventListener('hashchange', onHash);
    return () => window.removeEventListener('hashchange', onHash);
  }, []);
  const navigate = (id) => {
    if (id === tab) return;
    window.location.hash = '/' + id;
    // hashchange fires async — set immediately so the UI doesn't lag
    setTab(id);
    // Scroll to top so the new tab starts at the top of the viewport
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' });
  };
  return [tab, navigate];
}

function AppShell({ tweaks, setTweak }) {
  const [config] = useConfig();
  const { toast, azure, aws, loadPipelines } = useStore();
  const [tab, navigate] = useTabRoute();

  // Polling — every config.pollingMinutes refresh the live pipeline catalogue.
  const polling = usePolling(config.pollingMinutes, () => {
    if (azure.connected && loadPipelines) loadPipelines();
  });

  const connected = azure.connected || aws.connected;

  return (
    <div className="ccd-app">
      <Masthead tweaks={tweaks} navigate={navigate} />
      <PhaseBanner />

      <div className="ccd-layout">
        <ServiceMenu tab={tab} navigate={navigate} />
        <main className="ccd-main" id="main-content" tabIndex={-1}>
          <div className="ccd-container-fluid">
            {tab === 'overview'  && <OverviewTab tweaks={tweaks} polling={polling} />}
            {tab === 'pipelines' && (connected
              ? <PipelinesTable tweaks={tweaks} />
              : <ConnectGate bootstrapping={azure.bootstrapping || aws.bootstrapping} />)}
            {tab === 'regions'   && <RegionsAndForecast tweaks={tweaks} />}
            {CCD_FEATURES.research && tab === 'research' && <ResearchWatcherPanel now={polling.lastTickAt} />}
            {tab === 'glossary'  && <GlossaryPanel />}
          </div>
        </main>
      </div>

      <Colophon navigate={navigate} />

      <TweaksPanel title="Tweaks">
        <TweakSection label="Theme">
          <TweakRadio
            label="Theme"
            value={tweaks.theme}
            options={[
              { value: 'govuk', label: 'GOV.UK' },
              { value: 'contrast', label: 'Hi-contrast' },
              { value: 'azure-tinted', label: 'Azure tint' }
            ]}
            onChange={(v) => setTweak('theme', v)}
          />
          <TweakRadio
            label="Density"
            value={tweaks.density}
            options={[
              { value: 'comfortable', label: 'Comfortable' },
              { value: 'compact', label: 'Compact' }
            ]}
            onChange={(v) => setTweak('density', v)}
          />
        </TweakSection>

        <TweakSection label="Data">
          <TweakRadio
            label="Time range"
            value={tweaks.range}
            options={[
              { value: '24h', label: '24h' },
              { value: '7d',  label: '7d' },
              { value: '30d', label: '30d' },
              { value: 'qtr', label: 'Quarter' }
            ]}
            onChange={(v) => setTweak('range', v)}
          />
          <TweakRadio
            label="Cloud"
            value={tweaks.provider}
            options={[
              { value: 'azure', label: 'Azure' },
              { value: 'aws',   label: 'AWS' },
              { value: 'multi', label: 'Multi' }
            ]}
            onChange={(v) => setTweak('provider', v)}
          />
        </TweakSection>

        <TweakSection label="Layout">
          <TweakRadio
            label="View"
            value={tweaks.layout}
            options={[
              { value: 'manager',  label: 'Eng-mgr' },
              { value: 'operator', label: 'Operator' }
            ]}
            onChange={(v) => setTweak('layout', v)}
          />
          <TweakToggle
            label="Show $ cost"
            value={tweaks.show_money}
            onChange={(v) => setTweak('show_money', v)}
          />
        </TweakSection>
      </TweaksPanel>
    </div>
  );
}

// -----------------------------------------------------------------------
// Overview tab — Ledger masthead only. Navigation moved to the sidebar,
// so quick-link tiles would just duplicate it.
// -----------------------------------------------------------------------
function OverviewTab({ tweaks, polling }) {
  return <LedgerMasthead tweaks={tweaks} now={polling.lastTickAt} polling={polling} />;
}

// -----------------------------------------------------------------------
// Masthead — single line, GOV.UK pattern: brand left, primary action +
// settings right. Live status and environment chip moved into Settings to
// keep the bar uncluttered.
// -----------------------------------------------------------------------
function Masthead({ tweaks, navigate }) {
  const { openModal, closeModal, azure } = useStore();
  const onSettings = () => openModal({
    element: <SettingsModal onClose={closeModal} />,
    onClose: closeModal
  });
  const onAzureConfig = () => openModal({
    element: <CloudConfigModal onClose={closeModal} />,
    onClose: closeModal
  });
  return (
    <header className="ccd-masthead" role="banner">
      <a href="#main-content" className="ccd-skip-link">Skip to main content</a>
      <div className="ccd-container ccd-masthead-inner">
        <a href="#/overview" className="ccd-brand" onClick={(e) => { e.preventDefault(); navigate('overview'); }}>
          <span className="ccd-brand-name">Carbon Cost Dashboard</span>
        </a>

        <div className="ccd-mast-meta">
          <button
            className={'ccd-mast-action' + (azure.connected ? '' : ' primary')}
            onClick={onAzureConfig}
            aria-label="Cloud Configuration"
          >
            {'Cloud Configuration'}
          </button>
          <button className="ccd-mast-action" onClick={onSettings} aria-label="Settings">
            Settings
          </button>
          {window.greenQaAuth && window.greenQaAuth.enabled && (
            <button className="ccd-mast-action" onClick={() => window.greenQaAuth.logout()} aria-label="Sign out">
              Sign out
            </button>
          )}
        </div>
      </div>
    </header>
  );
}

// -----------------------------------------------------------------------
// Service menu — left sidebar, primary navigation (replaces TabBar).
// GOV.UK service-manual pattern: yellow active border-left, vertical list.
// -----------------------------------------------------------------------
function ServiceMenu({ tab, navigate }) {
  return (
    <aside className="ccd-service-menu" aria-label="Primary navigation">
      <div className="service-menu-label">Service Menu</div>
      <nav>
        <ul role="list">
          {TABS.map(t => (
            <li key={t.id}>
              <a
                href={'#/' + t.id}
                className={'service-menu-link' + (tab === t.id ? ' active' : '')}
                aria-current={tab === t.id ? 'page' : undefined}
                onClick={(e) => { e.preventDefault(); navigate(t.id); }}
              >
                {t.label}
              </a>
            </li>
          ))}
        </ul>
      </nav>
    </aside>
  );
}

// -----------------------------------------------------------------------
// ConnectGate — shown on the Pipelines tab until at least one cloud (Azure
// DevOps or AWS) is connected. Other tabs are always reachable.
// -----------------------------------------------------------------------
function ConnectGate({ bootstrapping }) {
  const { openModal, closeModal } = useStore();
  const openConfig = (initialTab) => openModal({
    element: <CloudConfigModal onClose={closeModal} initialTab={initialTab} />,
    onClose: closeModal
  });

  if (bootstrapping) {
    return (
      <section className="connect-gate" aria-label="Loading">
        <div className="connect-gate-card">
          <p className="muted">Checking connection…</p>
        </div>
      </section>
    );
  }

  return (
    <section className="connect-gate" aria-label="Get started">
      <div className="connect-gate-card">
        <div className="connect-gate-eyebrow">NO PIPELINES YET</div>
        <h1 className="connect-gate-title">Connect a cloud account</h1>
        <p className="connect-gate-lead">
          Connect Azure DevOps, AWS, or both to load your pipelines and start tracking
          the carbon cost of every run.
        </p>
        <div style={{ display: 'flex', gap: 'var(--s-2)' }}>
          <button className="btn" onClick={() => openConfig('azure')}>Connect Azure DevOps</button>
          <button className="btn" onClick={() => openConfig('aws')}>Connect AWS</button>
        </div>
      </div>
    </section>
  );
}

function PhaseBanner() {
  const { azure, aws } = useStore();
  const live = [];
  if (azure.connected) live.push('Azure DevOps (' + azure.organization + ')');
  if (aws.connected) live.push('AWS (' + aws.region + ')');
  const dataMessage = live.length
    ? 'Connected: ' + live.join(' and ') + '.'
    : 'No cloud connected — use Cloud Configuration to connect Azure DevOps or AWS.';
  return (
    <div className="ccd-phase" role="region" aria-label="Service phase">
      <div className="ccd-container ccd-phase-row">
        <span className={'ccd-tag ' + (live.length ? 'green' : '')}>{live.length ? 'LIVE' : 'SETUP'}</span>
        <span className="ccd-phase-message">{dataMessage}</span>
      </div>
    </div>
  );
}

function Colophon({ navigate }) {
  const year = new Date().getFullYear();
  return (
    <footer className="ccd-colophon" role="contentinfo">
      <div className="ccd-container ccd-colophon-row">
        <ul className="ccd-colophon-links" aria-label="Footer">
          <li><strong>GOV.UK</strong></li>
          <li><a href="#/glossary" onClick={(e) => { e.preventDefault(); navigate && navigate('glossary'); }}>Glossary</a></li>
          <li><a href="https://www.gov.uk/help/accessibility-statement" target="_blank" rel="noopener noreferrer">Accessibility</a></li>
          <li><a href="https://www.gov.uk/help/privacy-notice" target="_blank" rel="noopener noreferrer">Privacy</a></li>
          <li><a href="https://www.gov.uk/help/cookies" target="_blank" rel="noopener noreferrer">Cookies</a></li>
        </ul>
        <span className="ccd-colophon-copyright">© Crown copyright {year}</span>
      </div>
    </footer>
  );
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<App />);
