// Local static server for the SPA (no-cache, so edits show on reload).
//   node scripts/static-server.mjs [port]          (default 8080; also PORT env)
// Serves web/ at "/", falling back to the dashboard HTML. config.js defaults to the local API.
import { createServer } from 'node:http';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { dirname, extname, join, normalize, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..', 'web');
const port = Number(process.argv[2] ?? process.env.PORT ?? 8080);
const entry = 'Carbon Cost Dashboard.html';

const TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.jsx': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
};

const DEFAULT_CONFIG = `window.GREEN_QA_API_URL = '${process.env.API_URL ?? 'http://localhost:7071/api'}';\n`;

createServer((req, res) => {
  const { pathname } = new URL(req.url ?? '/', 'http://localhost');
  let rel = decodeURIComponent(pathname).replace(/^\/+/, '') || entry;
  if (rel === 'index.html') rel = entry;

  const file = normalize(join(root, rel));
  // Reject path traversal out of web/.
  if (file !== root && !file.startsWith(root + sep)) { res.writeHead(403).end('Forbidden'); return; }

  const headers = { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' };
  if (rel === 'config.js' && (process.env.API_URL || !existsSync(file))) {
    res.writeHead(200, { ...headers, 'Content-Type': TYPES['.js'] }).end(DEFAULT_CONFIG);
    return;
  }
  if (!existsSync(file) || !statSync(file).isFile()) { res.writeHead(404, headers).end('Not found'); return; }
  res.writeHead(200, { ...headers, 'Content-Type': TYPES[extname(file)] ?? 'application/octet-stream' }).end(readFileSync(file));
}).listen(port, () => console.log(`Dashboard: http://localhost:${port}/   (API expected at http://localhost:7071/api)`));
