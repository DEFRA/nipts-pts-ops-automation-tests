import { createHash } from 'node:crypto';
import { getRegionIntensityClient } from '../domain/carbonApi';
import { getProvider } from '../domain/providers';
import { logger } from '../logger';
import { getSecretStore } from '../lib/secrets';
import type { Repository } from '../repo/types';

// Deterministic PRNG (mulberry32) so seeded demo data is reproducible.
function rng(seed: number) {
  let a = seed;
  return () => {
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const PIPELINES = [
  { id: 'billing-prod-hotfix', ado_uri: 'azdo://vibecode/GreenQA Pipelines/16', base: 8.4, duration_s: 720, vcpu: 4, mem: 8, crit: 'CRITICAL' },
  { id: 'nightly-ci-azure-fn', ado_uri: 'azdo://vibecode/GreenQA Pipelines/17', base: 16.9, duration_s: 1500, vcpu: 2, mem: 4, crit: 'NORMAL' },
  { id: 'api-tests-smoke', ado_uri: 'azdo://vibecode/GreenQA Pipelines/18', base: 6.4, duration_s: 360, vcpu: 2, mem: 4, crit: 'NORMAL' },
  { id: 'ml-train-fraud-detection', ado_uri: 'azdo://vibecode/GreenQA Pipelines/19', base: 218.0, duration_s: 10800, vcpu: 16, mem: 64, crit: 'LOW' },
  { id: 'e2e-tests-ms-hosted', ado_uri: 'azdo://vibecode/GreenQA Pipelines/20', base: 11.6, duration_s: 1200, vcpu: 2, mem: 4, crit: 'NORMAL' },
];

const DECISIONS = ['RUN_NOW', 'DEFER', 'RELOCATE', 'HYBRID'];
const DECISION_WEIGHTS = [3, 2, 2, 1];
const STATUSES = ['Succeeded', 'Succeeded', 'Succeeded', 'Succeeded', 'Failed', 'Canceled'];
const AUTHORS = ['a.chen', 'r.patel', 'j.lindqvist', 'm.costa', 's.tanaka'];
const FAIL_REASONS = [
  'Test suite failed: 2 of 148 assertions failed',
  'Step "script" exited with code 1',
  'Timed out waiting for a dependent service',
  'Agent lost connection during the run',
  'Out of memory in the test container',
  'Lint check failed: eslint reported 3 errors',
];

/** Populate N days of synthetic runs plus a carbon snapshot so the SPA can be demoed immediately. */
export async function seedDemoData(repo: Repository, opts: { days: number; perDay: number; provider: string }) {
  const provider = getProvider(opts.provider);
  const now = Date.now();
  const rand = rng(42);
  const pick = <T>(xs: T[]) => xs[Math.floor(rand() * xs.length)];
  const int = (lo: number, hi: number) => lo + Math.floor(rand() * (hi - lo + 1));
  const regions = provider.listRegions().map((r) => r.code);

  let seededRuns = 0;
  for (let day = 0; day < opts.days; day++) {
    for (const p of PIPELINES) {
      for (let n = 0; n < opts.perDay; n++) {
        const ts = new Date(now - day * 86_400_000 - int(0, 23) * 3_600_000 - int(0, 59) * 60_000);
        const actual = Math.round(p.base * (0.7 + rand() * 0.6) * 100) / 100;
        const baseline = Math.round(actual * (1.2 + rand() * 0.6) * 100) / 100;
        const total = DECISION_WEIGHTS.reduce((a, b) => a + b, 0);
        let roll = rand() * total;
        let decision = DECISIONS[0];
        for (let i = 0; i < DECISIONS.length; i++) {
          roll -= DECISION_WEIGHTS[i];
          if (roll < 0) { decision = DECISIONS[i]; break; }
        }
        const status = pick(STATUSES);
        const runId = `seed-${String(day).padStart(2, '0')}-${p.id}-${n}`;
        await repo.upsertExecution({
          id: `${p.id}::${runId}`,
          run_id: runId,
          pipeline_id: p.id,
          ado_uri: p.ado_uri,
          provider: opts.provider,
          region: pick(regions),
          duration_seconds: p.duration_s + int(-120, 120),
          vcpu_count: p.vcpu,
          memory_gb: p.mem,
          status,
          decision,
          criticality: p.crit,
          actual_carbon_g: actual,
          baseline_carbon_g: baseline,
          commit_sha: createHash('sha1').update(runId).digest('hex').slice(0, 7),
          author: pick(AUTHORS),
          stored_at: ts.toISOString(),
          ...(status === 'Failed' ? { failure_reason: pick(FAIL_REASONS) } : {}),
        });
        seededRuns++;
      }
    }
  }

  const sampleTs = new Date().toISOString();
  const token = await getSecretStore().get('electricitymaps_token');
  let seededCarbon = 0;
  for (const region of provider.listRegions()) {
    try {
      const [data, source] = await getRegionIntensityClient(region.code, { token, provider: opts.provider }).getRegionIntensity(region.code);
      if (!data) continue;
      await repo.upsertCarbonSample({
        id: `${opts.provider}::${region.code}::${sampleTs}`,
        provider: opts.provider,
        region: region.code,
        grid_intensity_gco2_kwh: data.grid_intensity,
        dc_intensity_gco2_kwh: data.carbon_intensity,
        renewable_pct: data.renewable_percentage,
        zone: data.zone,
        pue: data.aws_pue,
        sampled_at: sampleTs,
        source,
      });
      seededCarbon++;
    } catch (err) {
      logger.error({ err, region: region.code }, 'dev/seed: carbon fetch failed');
    }
  }
  return { seededRuns, seededCarbon };
}
