# Infrastructure Requirements

Hardware-free spec for the Azure deployment. Everything here is declared in
`infrastructure/azure/main.bicep` — this page exists to make the resource
list, sizing, and cost reviewable **without reading 325 lines of Bicep**.

---

## 1 · Resource inventory

| # | Resource | SKU / tier | Why |
|---|---|---|---|
| 1 | **Resource Group** | n/a | One per environment (`rg-greenqa-{env}`) |
| 2 | **Storage Account** | `Standard_LRS`, StorageV2 | Required by the Functions runtime + Blob queues for deferred runs |
| 3 | **Log Analytics workspace** | PerGB2018, 30-day retention | Backing store for App Insights |
| 4 | **Application Insights** | Workspace-based | Request / dependency / log telemetry, custom carbon metrics |
| 5 | **Key Vault** | Standard, RBAC auth, soft-delete on (purge-protect in prod) | Holds `electricitymaps-token` and `ado-pat` |
| 6 | **Cosmos DB** | Serverless, SQL API, Session consistency | 4 containers (see §3) |
| 7 | **App Service plan** | `Y1` Linux Consumption | Functions runtime host |
| 8 | **Function App** | Python 3.11, system-assigned MI | All API routes + 2 timers |
| 9 | **Static Web App** | Free tier | Hosts the dashboard SPA + global CDN |

Optional (not yet in Bicep — add via PR as you adopt them):

| Resource | When to add | Notes |
|---|---|---|
| Azure Front Door | When you have > 1 region | Geo routing + WAF |
| Azure API Management | When you have > 3 consumer teams | Per-team quotas, JWT validation |
| Logic App | Weekly digest scheduler | Cheaper than a permanent Function plan for once-a-week jobs |
| Azure Monitor Workbook | After first month of telemetry | Custom carbon overview |

---

## 2 · Compute sizing

### Function App (Consumption Y1)

- **Cold start**: ~3-5 s for `/api/decide`, ~1 s for `/api/carbon` (warm)
- **Scale**: 0 → 200 instances, autoscale managed by Azure
- **Memory**: 1.5 GB per instance (fixed)
- **Timeout**: 5 min (default); 10 min available if extended (no change needed)
- **Free grant**: 1 M executions/month + 400 000 GB-s

At ~10 pipelines × ~3 gate calls/day × 30 days = 900 executions/month — you
will not exit the free grant in a pilot.

### Cosmos DB (Serverless)

- **Pricing**: RU/s consumed × $0.25 per 1 M RU
- **Storage**: $0.25/GB/month
- **Estimated load** (10 pipelines, 30-min ingestion):
  - Carbon intensity writes: ~ 480 writes/day × 5 RU = 2 400 RU/day
  - Pipeline execution writes: ~ 50 writes/day × 5 RU = 250 RU/day
  - Reads: ~ 5 000/day × 1 RU = 5 000 RU/day
  - **Total: ~7 650 RU/day × 30 = 230 000 RU/month → ~$0.06/month**
- **Storage**: ~ 100 MB after 12 months → $0.03/month

Even at 10× the pilot load, Cosmos stays well under $5/month.

### Static Web App (Free)

- 100 GB bandwidth/month
- 0.5 GB site size
- 2 staging environments
- Free TLS cert + auto-renewal
- Custom domain support

Production-grade for an internal dashboard. Upgrade to **Standard** ($9/mo)
only if you need authentication providers other than Entra ID, or > 0.5 GB
of static assets.

---

## 3 · Cosmos DB containers

All in database `green_qa`. Partition keys chosen for write-heavy paths.

| Container | Partition key | Default TTL | Purpose |
|---|---|---|---|
| `carbon_intensity_history` | `/region` | 30 days | Rolling raw + adjusted intensity per region |
| `pipeline_executions` | `/pipeline_id` | 1 year | One row per pipeline run with SCI + decision |
| `deferred_runs` | `/pipeline_id` | 7 days | TIME_SHIFT runs awaiting their window |
| `pipeline_analytics` | `/pipeline_id` | 1 year | Daily aggregates for the dashboard |

Indexing policy excludes `/raw/?` (noisy webhook payloads) to control RU
consumption on writes.

---

## 4 · Networking

The Bicep template is **public-network friendly** for ease of pilot
deployment:

- Function App: public ingress, function-key auth
- Static Web App: public, anonymous (the SPA is public; API key gates the
  Function)
- Cosmos DB: SQL API public endpoint, RBAC via Managed Identity
- Key Vault: RBAC, public endpoint, soft-delete on

### Locking down for prod

| Layer | Change |
|---|---|
| Function App | Add `vnetIntegration` + private endpoint; egress through a NAT gateway |
| Cosmos DB | Private endpoint only; disable public network access |
| Key Vault | Private endpoint; firewall allows trusted Azure services |
| Static Web App | Standard tier + linked-app private endpoint |
| Outbound | Allow only the [egress FQDN list](./EXTERNAL_APIS.md#5-egress-allow-list-for-restricted-azure-networks) |

These changes are PR-sized — `infrastructure/azure/main.bicep` is structured
so each resource block can be augmented without restructuring.

---

## 5 · Identity & RBAC

The Function App uses a **system-assigned managed identity** with two
roles assigned by `main.bicep`:

| Scope | Role | Why |
|---|---|---|
| Key Vault | **Key Vault Secrets User** | Read `electricitymaps-token` and `ado-pat` at runtime |
| Cosmos DB | **Cosmos DB Built-in Data Contributor** | Read/write all 4 containers |

No client secrets are required at runtime.

Admin / deployer (one-time):

| Scope | Role |
|---|---|
| Resource group | **Contributor** |
| Key Vault | **Key Vault Administrator** (to push initial secret values) |

---

## 6 · Cost summary

| Item | Quantity | Monthly cost (USD) |
|---|---|---|
| Storage Account | 1 (~1 GB) | < $1 |
| Log Analytics + App Insights | ~1 GB ingestion/mo | ~$2 |
| Key Vault | 2 secrets, ~5 K ops/mo | ~$1 |
| Cosmos DB Serverless | ~230 K RU + 100 MB | ~$0.10 |
| Function App | Within free grant | $0 |
| Static Web App | Free tier | $0 |
| **Total (pilot, 10 pipelines)** | | **~$3–5 / mo** |
| **Production (200 pipelines)** | | **~$30–50 / mo** |

Cost is dominated by App Insights ingestion. To reduce: lower the Log
Analytics retention to 7 days (default 30) and sample non-error traces at
10 %.

---

## 7 · Region selection

The default deploy region is **`uksouth`** because:

- Lowest carbon intensity among UK Azure regions in 2024-26
- Has the full SKU set (Cosmos Serverless, SWA Free, Functions Y1)
- Lowest network latency for our UK Grid ESO ingestion path

Acceptable alternatives, in order of preference:
`northeurope`, `francecentral`, `swedencentral`, `westeurope`.

**Avoid** `germanywestcentral`, `italynorth`, `polandcentral` for the
control plane — they have higher grid carbon and would undercut the
platform's own carbon story.

---

## 8 · Capacity planning

Designed for **up to 200 pipelines per subscription**. The bottleneck above
that point is App Insights ingestion volume (telemetry from per-run traces)
— not Cosmos or Functions.

Beyond 200 pipelines, options:

1. **Shard by team / BU**: deploy one stack per business unit; federate via
   a top-level dashboard
2. **Switch Functions plan**: from `Y1` Consumption to `EP1` Elastic Premium
   for pre-warmed instances (cost: ~$140/mo, eliminates cold start)
3. **Cosmos provisioned throughput**: switch from Serverless to autoscale
   at 4 000 RU/s shared (~$50/mo) when sustained writes exceed 200 RU/s

These are post-pilot decisions — start serverless.
