import { GetSecretValueCommand, PutSecretValueCommand, SecretsManagerClient } from '@aws-sdk/client-secrets-manager';
import { envStr } from '../config';
import { logger } from '../logger';

/** Values that mean "not provisioned yet" (the CDK stack seeds secrets with this). */
const PLACEHOLDER = 'CHANGE_ME';

export type SecretName = 'ado_pat' | 'aws_credentials' | 'electricitymaps_token' | 'webhook_secret';

export interface SecretStore {
  /** Returns null when the secret is unset or still the placeholder. */
  get(name: SecretName): Promise<string | null>;
  put(name: SecretName, value: string): Promise<void>;
  /** Reset to the unprovisioned state. */
  clear(name: SecretName): Promise<void>;
}

const ENV_ID: Record<SecretName, string> = {
  ado_pat: 'SECRET_ID_ADO_PAT',
  aws_credentials: 'SECRET_ID_AWS_CREDENTIALS',
  electricitymaps_token: 'SECRET_ID_ELECTRICITYMAPS',
  webhook_secret: 'SECRET_ID_WEBHOOK',
};

const ENV_FALLBACK: Record<SecretName, string> = {
  ado_pat: 'AZURE_DEVOPS_PAT',
  aws_credentials: 'AWS_PIPELINES_CREDENTIALS',
  electricitymaps_token: 'ELECTRICITYMAPS_TOKEN',
  webhook_secret: 'WEBHOOK_SECRET',
};

const CACHE_TTL_MS = 5 * 60_000;

/** Secrets Manager with a short in-process cache; falls back to env vars when no secret id is configured. */
export class AwsSecretStore implements SecretStore {
  private cache = new Map<SecretName, { value: string | null; at: number }>();
  private readonly client = new SecretsManagerClient({});

  async get(name: SecretName): Promise<string | null> {
    const secretId = envStr(ENV_ID[name]);
    if (!secretId) return envStr(ENV_FALLBACK[name]) || null;

    const hit = this.cache.get(name);
    if (hit && Date.now() - hit.at < CACHE_TTL_MS) return hit.value;

    let value: string | null = null;
    try {
      const res = await this.client.send(new GetSecretValueCommand({ SecretId: secretId }));
      const raw = (res.SecretString ?? '').trim();
      value = raw && raw !== PLACEHOLDER ? raw : null;
    } catch (err) {
      logger.error({ err: (err as Error).name, secret: name }, 'secrets_manager lookup failed; using env fallback');
    }
    value = value ?? (envStr(ENV_FALLBACK[name]) || null);
    this.cache.set(name, { value, at: Date.now() });
    return value;
  }

  async put(name: SecretName, value: string): Promise<void> {
    const secretId = envStr(ENV_ID[name]);
    if (!secretId) throw new Error(`No secret configured for ${name}`);
    await this.client.send(new PutSecretValueCommand({ SecretId: secretId, SecretString: value }));
    this.cache.set(name, { value, at: Date.now() });
  }

  async clear(name: SecretName): Promise<void> {
    if (!envStr(ENV_ID[name])) return;
    await this.put(name, PLACEHOLDER);
    this.cache.set(name, { value: envStr(ENV_FALLBACK[name]) || null, at: Date.now() });
  }
}

/** Process-memory secrets for local dev and tests. */
export class MemorySecretStore implements SecretStore {
  private values = new Map<SecretName, string>();

  async get(name: SecretName): Promise<string | null> {
    return this.values.get(name) ?? (envStr(ENV_FALLBACK[name]) || null);
  }

  async put(name: SecretName, value: string): Promise<void> {
    this.values.set(name, value);
  }

  async clear(name: SecretName): Promise<void> {
    this.values.delete(name);
  }
}

let instance: SecretStore | undefined;

export function getSecretStore(): SecretStore {
  if (!instance) {
    const hasAws = Object.values(ENV_ID).some((k) => envStr(k));
    instance = hasAws ? new AwsSecretStore() : new MemorySecretStore();
  }
  return instance;
}

export function setSecretStore(store: SecretStore | undefined): void {
  instance = store;
}
