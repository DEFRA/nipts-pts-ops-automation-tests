// Minimal Azure DevOps REST stub for e2e runs (point the API at it with ADO_BASE_URL).
// Accepts the PAT "devpat" for any organization.
import { createServer } from 'node:http';

const REPOS = ['payments-platform', 'identity-service', 'data-pipelines'];
const NAMES = ['payments-api-ci', 'payments-billing-release', 'identity-auth-ci', 'identity-profile-ci', 'data-nightly-etl', 'data-ml-train'];
const definitions = NAMES.map((name, i) => ({
  id: 100 + i,
  name,
  path: '\\',
  repository: { name: REPOS[Math.floor(i / 2)] },
  _links: { web: { href: `https://dev.azure.com/contoso/Demo/_build?definitionId=${100 + i}` } },
}));

export function startMockAdo(port = 7099) {
  const server = createServer((req, res) => {
    const json = (status, body) => { res.writeHead(status, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(body)); };
    const auth = Buffer.from((req.headers.authorization ?? '').replace(/^Basic /, ''), 'base64').toString();
    if (auth !== ':devpat') return json(401, { message: 'unauthorized' });

    const { pathname } = new URL(req.url, 'http://x');
    if (pathname.endsWith('/_apis/projects')) return json(200, { count: 1, value: [{ name: 'Demo' }] });
    if (pathname.endsWith('/_apis/build/definitions')) return json(200, { count: definitions.length, value: definitions });
    if (pathname.endsWith('/_apis/build/builds')) return json(200, { count: 0, value: [] });
    if (/\/_apis\/pipelines\/\d+\/runs$/.test(pathname) && req.method === 'POST') {
      return json(200, { id: Date.now(), _links: { web: { href: 'https://dev.azure.com/contoso/Demo/_build/results?buildId=1' } } });
    }
    json(404, { message: 'not found' });
  });
  return new Promise((resolve) => server.listen(port, () => resolve(server)));
}

if (import.meta.url === `file:///${process.argv[1].replace(/\\/g, '/')}`) {
  await startMockAdo(Number(process.env.PORT ?? 7099));
  console.log('mock ADO listening');
}
