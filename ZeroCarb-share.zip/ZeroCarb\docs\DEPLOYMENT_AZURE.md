# Azure Deployment — End-to-End Runbook

This guide walks a fresh operator from zero to a running Green QA Platform
on Azure, including the **pre-deployment**, **deployment**, and
**post-deployment** steps. It assumes the repository at hand is the
`green-qa-platform/` codebase referenced in `docs/README.md`.

Estimated time: ~45 minutes for the first deploy, ~5 minutes for subsequent
redeploys.

---

## 0 · Architecture in one picture

```
                ┌────────────────────────────────┐
                │   Static Web App (Free tier)   │  ← dashboard SPA
                │   dashboard/public/             │
                └──────────────┬─────────────────┘
                               │ XHR / fetch
                               ▼
┌──────────────────────────────────────────────────────────┐
│  Function App (Linux, Python 3.11, Consumption Y1)       │
│  azure/functions/function_app.py                          │
│  Routes: /api/decide /api/calculate /api/budget/check    │
│          /api/history /api/carbon /api/store_result …    │
│  Timers: ingest_carbon (30 m), resume_deferred (5 m)     │
└────┬──────────────┬─────────────────┬────────────────────┘
     │              │                 │
     │ Managed      │ Managed         │ Outbound HTTPS
     │ Identity     │ Identity        │ (timer trigger)
     ▼              ▼                 ▼
┌──────────┐  ┌──────────┐   ┌────────────────────────────┐
│ Cosmos   │  │ Key      │   │ UK Grid ESO                │
│ DB       │  │ Vault    │   │ ElectricityMaps            │
│ 4 cont's │  │ (RBAC)   │   │ Ember Climate              │
└──────────┘  └──────────┘   │ Azure DevOps REST          │
                              └────────────────────────────┘
                              │
                              ▼
                       ┌─────────────────┐
                       │ App Insights +  │
                       │ Log Analytics   │
                       └─────────────────┘
```

Infrastructure is declared in `infrastructure/azure/main.bicep` and is
**idempotent** — re-running the deployment will not duplicate resources.

---

## 1 · Pre-deployment

### 1.1 · Tools

Install these on the machine that will run the deploy:

| Tool | Min version | Install |
|---|---|---|
| Azure CLI | 2.60 | `brew install azure-cli` / `winget install Microsoft.AzureCLI` |
| Bicep CLI | 0.27 | bundled with `az`: `az bicep install` |
| Azure Functions Core Tools | v4 | `npm i -g azure-functions-core-tools@4 --unsafe-perm true` |
| Static Web Apps CLI | latest | `npm i -g @azure/static-web-apps-cli` |
| Python | 3.11 | python.org / pyenv |
| `jq` | 1.6 | `brew install jq` |
| Git | any | `git --version` |

### 1.2 · Azure permissions

The principal running the deploy needs **Contributor** on the target
subscription (or resource group) plus **Key Vault Administrator** to push
the initial secret values.

```bash
az login
az account set --subscription "<your-subscription-id>"
az account show --query '{name:name, id:id, tenantId:tenantId}'
```

### 1.3 · Secrets to gather

| Secret | Where to get it | Used as |
|---|---|---|
| **ElectricityMaps token** | electricitymaps.com → free account → API tokens | Bicep param `electricityMapsToken` → KV secret `electricitymaps-token` |
| **Azure DevOps PAT** | ADO → User Settings → Personal Access Tokens → scope `Build:Read & Execute`, `Code:Read` | Bicep param `adoPat` → KV secret `ado-pat` |
| **Admin object ID** (optional) | `az ad signed-in-user show --query id -o tsv` | Bicep param `adminObjectId` — grants you KV Secrets User |

Generate the PAT with the **minimum** scopes; rotate every 90 days.

### 1.4 · Repository checkout & verification

```bash
git clone <green-qa-platform-repo-url>
cd green-qa-platform

# Verify the code compiles before deploying
make lint                  # py_compile across the library
make test-unit             # ~80 unit tests should pass
```

If `make test-unit` fails, **stop and fix locally first** — the deployment
will succeed but the Functions runtime will fail at first request.

---

## 2 · Deployment

### 2.1 · Resource group

```bash
ENV=prod                            # or dev | staging
LOC=uksouth
RG=rg-greenqa-$ENV

az group create --name $RG --location $LOC
```

### 2.2 · Provision infrastructure (Bicep)

```bash
EM_TOKEN=<your-electricitymaps-token>
ADO_PAT=<your-ado-pat>
ADMIN_OID=$(az ad signed-in-user show --query id -o tsv)

az deployment group create \
  --resource-group $RG \
  --template-file infrastructure/azure/main.bicep \
  --parameters \
      environment=$ENV \
      location=$LOC \
      baseName=greenqa \
      electricityMapsToken="$EM_TOKEN" \
      adoPat="$ADO_PAT" \
      adminObjectId="$ADMIN_OID" \
  --query 'properties.outputs'
```

This creates:

- Storage account (required by Functions runtime)
- Log Analytics + Application Insights
- Key Vault with 2 secrets (`electricitymaps-token`, `ado-pat`), soft-delete on, purge protection in prod
- Cosmos DB Serverless with 4 containers: `carbon_intensity_history`, `pipeline_executions`, `deferred_runs`, `pipeline_analytics`
- Hosting plan (`Y1`, Linux Consumption)
- Function App with system-assigned Managed Identity + RBAC to Cosmos and KV
- Static Web App (Free tier)

The deployment is idempotent — re-running it is the right way to apply
config drift fixes.

**Capture the outputs.** You need `functionAppName` and `staticWebAppName`
for the next steps:

```bash
FUNC=$(az deployment group show -g $RG -n main \
        --query 'properties.outputs.functionAppName.value' -o tsv)
SWA=$(az deployment group show -g $RG -n main \
        --query 'properties.outputs.staticWebAppName.value' -o tsv)
```

### 2.3 · Publish the Functions code

```bash
cd azure/functions
func azure functionapp publish "$FUNC" --python --build remote
cd -
```

Wait ~60 s for the cold-start grace. Then verify:

```bash
FUNC_URL="https://$FUNC.azurewebsites.net"
curl -s "$FUNC_URL/api/carbon?code=$(az functionapp keys list \
  -g $RG -n $FUNC --query 'functionKeys.default' -o tsv)" | jq '. | keys'
# Expect: ["eu-central-1","eu-north-1","eu-south-1","eu-south-2","eu-west-1","eu-west-2","eu-west-3"]
```

### 2.4 · Publish the dashboard SPA

```bash
SWA_TOKEN=$(az staticwebapp secrets list -n $SWA -g $RG \
              --query 'properties.apiKey' -o tsv)

swa deploy dashboard/public \
  --deployment-token "$SWA_TOKEN" \
  --env production
```

The SWA URL is in the deployment output (`https://<random>.azurestaticapps.net`)
or in the Azure portal under the Static Web App.

### 2.5 · Wire the dashboard to the Function App

The SPA reads `window.API_URL` at boot. Configure it in the SWA app settings:

```bash
az staticwebapp appsettings set -n $SWA \
  --setting-names API_URL="$FUNC_URL/api" \
                  FUNCTION_KEY="$(az functionapp keys list -g $RG -n $FUNC \
                                    --query 'functionKeys.default' -o tsv)"
```

> **Note** — exposing the function key to the browser is fine for an
> *internal* pilot; for any external rollout, replace with Entra ID auth
> (see `GAPS.md` §C.2).

---

## 3 · Post-deployment

### 3.1 · Smoke test (run within 5 minutes of deploy)

```bash
# Health: API is up
curl -s "$FUNC_URL/api/carbon?code=…" | jq '.[].source' | sort | uniq -c
# Healthy output:
#    7 "live_eso" / "live_electricitymaps" / "live_ember"
# UNhealthy output:
#    7 "synthetic"   ← upstream APIs unreachable; check egress + KV secret

# Pre-run decision (no auth needed if using function key)
curl -X POST "$FUNC_URL/api/decide?code=…" \
  -H 'Content-Type: application/json' \
  -d '{"pipeline":"smoke","home_region":"eu-west-2","vcpu":2,"memory_gb":4,"duration_min":10,"criticality":"normal"}'
# Expect: {"action":"RUN_NOW_OPTIMAL"|"RUN_NOW_DEFAULT"|…,"region":…,"saving_pct":…}

# Dashboard reachable
curl -sI "https://$SWA.azurestaticapps.net/" | head -1
# Expect: HTTP/2 200
```

### 3.2 · Trigger the timer triggers manually (don't wait 30 min)

```bash
# Force a carbon ingest tick
az functionapp function invoke -g $RG -n $FUNC --function-name ingest_carbon

# Tail the logs to confirm rows landed in Cosmos
az functionapp log tail -g $RG -n $FUNC | grep ingestion
```

### 3.3 · Verify Cosmos is being written

```bash
COSMOS=$(az cosmosdb list -g $RG --query '[0].name' -o tsv)

az cosmosdb sql container show \
  -g $RG -a $COSMOS -d green_qa -n carbon_intensity_history \
  --query 'resource.statistics.documentCount'
# After one ingestion tick: should be >= 7 (one per EU region)
```

### 3.4 · Wire alerts

Alerts are **not** in `main.bicep` yet — create them post-deploy. Minimum
set we recommend:

| Alert | Condition | Severity | Action |
|---|---|---|---|
| `CarbonIngestionStale` | `customMetrics/carbon_freshness_s > 5400` | Sev1 | Email + PagerDuty |
| `FunctionErrors` | `requests/failed > 1%` over 15 min | Sev2 | Slack #green-qa-alerts |
| `KeyVaultSecretExpiringSoon` | `KeyVaultSecretNearExpiry < 7 days` | Sev2 | Email |
| `GateLatencyHigh` | `requests/duration p95 > 1500ms` over 10 min | Sev3 | Slack |

Use `infrastructure/azure/alerts.bicep` (template-based, ship as PR — see
roadmap in `GAPS.md`).

### 3.5 · Onboard a pipeline

Each consuming team adds the gate to their CI:

**Azure DevOps**

```yaml
# azure-pipelines.yml
resources:
  repositories:
    - repository: greenqa
      type: git
      name: shared/green-qa-platform

steps:
  - template: integration/azure-devops/carbon-gate.yml@greenqa
    parameters:
      apiUrl: $(GREEN_QA_API)         # = https://<func>.azurewebsites.net/api
      apiKey: $(GREEN_QA_KEY)         # function key from KV
      budgetGrams: 12
      criticality: normal
```

**GitHub Actions**

```yaml
- uses: ./integration/github-actions/green-qa-demo.yml
  with:
    api-url: ${{ secrets.GREEN_QA_API }}
    api-key: ${{ secrets.GREEN_QA_KEY }}
    budget-grams: 12
    criticality: normal
```

### 3.6 · Rotate secrets (mark in calendar)

| Secret | Cadence | How |
|---|---|---|
| ElectricityMaps token | yearly | electricitymaps.com → reissue → `az keyvault secret set` |
| ADO PAT | 90 days | ADO → reissue → `az keyvault secret set` |
| Function default key | on incident | `az functionapp keys renew --key-name default` |

---

## 4 · Rollback

Every deployment is immutable on a new slot (slot-swap is built into Bicep).

```bash
# Functions code rollback (last good build)
az functionapp deployment list-publishing-profiles -g $RG -n $FUNC
az functionapp deployment source sync -g $RG -n $FUNC --slot last-good

# Infra rollback (re-deploy a previous Bicep tag)
git checkout v2.1.0 -- infrastructure/azure/main.bicep
az deployment group create -g $RG --template-file infrastructure/azure/main.bicep ...
```

Cosmos schema changes are **forward-only**. Rolling back a schema requires
restoring from continuous backup (30-day retention by default).

---

## 5 · Teardown (dev / staging only)

```bash
az group delete --name $RG --yes
```

In prod, Key Vault soft-delete reserves the vault name for 90 days. If you
need to redeploy with the same name within that window, use
`az keyvault purge` (requires elevated permissions).

---

## 6 · Troubleshooting

| Symptom | Likely cause | Fix |
|---|---|---|
| `/api/carbon` returns all `source: "synthetic"` | KV secret unreadable | `az keyvault secret show -n electricitymaps-token --vault-name <kv>`; check Function App Managed Identity has **Key Vault Secrets User** role |
| Function App "Internal Server Error" on every call | `requirements.txt` failed to install | Tail logs; re-run `func azure functionapp publish --build remote` |
| Cosmos writes succeed but reads return empty | Wrong partition key in query | All containers use `pipeline_id` partition key (except `carbon_intensity_history` which uses `region`) |
| Dashboard loads but shows DEMO DATA forever | SPA still using `data.js` fixtures | Confirm `API_URL` app setting on SWA; rebuild SPA |
| `func azure functionapp publish` hangs >5 min | Cold remote build on first deploy | This is normal; subsequent deploys < 60 s |
| `az deployment group create` fails with name collision | Soft-deleted KV/Cosmos blocking name | Pick a different `baseName` parameter or purge with elevated permissions |
| ADO PAT expired | Service Hooks 401 | Reissue PAT, `az keyvault secret set --name ado-pat --value …` (no code redeploy needed; Function reads on cold start) |
