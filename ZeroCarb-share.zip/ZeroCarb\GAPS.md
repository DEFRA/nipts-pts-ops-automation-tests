# Carbon Cost Dashboard — Known Gaps & Industry Best-Practice Roadmap

A frank accounting of what this prototype **does**, what it **mocks**, and what
should ship before / after first production rollout.

---

## A · What's fully working in the prototype

✅ Dashboard SPA with all 8 sections — Ledger, Budgets, Pipelines, Regions,
  Forecast, Strategy, Teams, Equivalences, History, Synthetic Tests
✅ Configurable polling intervals (dashboard 10 min, tests 5 min — both
  tunable via Settings)
✅ Carbon-aware **4-step scheduler decision tree** (real logic — reusable as
  library)
✅ Per-pipeline carbon budgets with **pass / warn / fail at the gate**
✅ Per-transaction carbon breakdown ("login flow: 0.52 g CO₂") on every drill-down
✅ MAIZX strategy mix attribution (RUN_NOW / TIME_SHIFT / SPACE_SHIFT / HYBRID)
✅ Team leaderboard, equivalences strip, $ cost side-by-side with carbon
✅ Apply recommendation / Override budget / Run now workflows with live state
✅ Send weekly digest, Export CSV, Connect Azure (service-principal flow UX)
✅ Synthetic test framework with countdown timers, real interval ticking, status
✅ Settings modal with persisted localStorage + generated YAML preview
✅ Tweaks: theme / density / time range / cloud / layout / $-cost / home region
✅ WCAG 2.2 AA palette, focus states, keyboard nav

---

## B · What's mocked (and how to wire it up)

| Mocked | Currently | To productionise |
|---|---|---|
| **Azure pipeline data** | `data.js` static fixtures (10 pipelines) | Replace with Azure DevOps REST client. Endpoint: `https://dev.azure.com/{org}/{project}/_apis/pipelines?api-version=7.1`. Auth via service principal from §C.1 below. |
| **Carbon intensity feed** | Hard-coded gCO₂/kWh per region | Wire to ElectricityMaps (`/v3/carbon-intensity/latest`) + UK Grid ESO (`api.carbonintensity.org.uk`). Token in Key Vault. |
| **`Run now` execution** | Animates queued→running→complete locally | POST `https://dev.azure.com/{org}/{project}/_apis/pipelines/{id}/runs` and stream status via WebPubSub. |
| **`Apply recommendation`** | Mutates client state | Open PR against the repo's `azure-pipelines.yml` via Azure DevOps Git API. |
| **`Override budget`** | Mutates client state + toast | POST audit log to `audit_log` Cosmos collection; emit Slack DM to sustainability lead. |
| **`Send weekly digest`** | Schedules via toast | Persist a Logic App / Function timer trigger that composes from Cosmos at send-time. |
| **`Export CSV`** | Real download from local history | Replace data source with paginated Cosmos query. |
| **`Connect Azure`** | UX flow only | Implement OIDC federated identity (workload identity federation, no client secret). |
| **Synthetic tests** | Tick on `setInterval` in browser | Move to Azure Function timer trigger; persist results to `synthetic_results` collection. |
| **Forecast** | Static 24h curve | Replace with ElectricityMaps `/v3/carbon-intensity/forecast` or train a Prophet/ARIMA model on 90 days of history. |

---

## C · Industry best-practice — must-do before prod

### C.1 — Workload Identity Federation (replace client secrets entirely)
Even the current "service principal + client secret" flow in the Connect Azure
modal is **not modern best practice**. Implement **OIDC federated credentials**
(Workload Identity Federation): the dashboard exchanges its Entra ID token for
an Azure RBAC scope. No long-lived secret, no rotation burden.

### C.2 — Zero-trust API
Currently no auth modelled on `/v1/*`. Add:
- mTLS between pipeline runners and the API
- JWT bearer tokens with per-pipeline scopes (`pipeline:read`, `gate:invoke`)
- Rate limiting at Front Door WAF (default 1000 RPM/team)

### C.3 — Carbon data lineage
Each emitted `g CO₂` figure should carry its derivation:
```json
{ "value_g": 8.4, "source": "electricitymaps@2024-05-19T14:00Z",
  "method": "SCI-v1.0", "pue": 1.185, "embodied_g": 1.26 }
```
Required for audit trails and ESG reporting.

### C.4 — Carbon-aware scheduling — hardening
- **α-fairness constraint**: prevent every workload piling onto Sweden Central
  (would create grid pressure and starve regional latency SLOs)
- **Data residency enforcement**: regions allow-list per pipeline (GDPR / sector regs)
- **Cost ceiling**: cap dollar cost of a `SPACE_SHIFT` — sometimes the cleaner
  region is 3× more expensive
- **Confidence intervals on forecasts**: refuse `TIME_SHIFT` if forecast
  confidence < `FORECAST_CONFIDENCE_THRESHOLD` (default 0.7)

### C.5 — Embed the carbon calculator at compile time
Don't measure carbon **after** the build — measure it during, as a sidecar:
- Use eBPF (or `psutil` for cross-platform) to sample CPU/memory at 1 Hz
- Multiply by region's current intensity to attribute carbon to each
  transaction (currently a static value in mocked data)

### C.6 — SBOM + carbon-of-dependencies
We measure the carbon of *running* a pipeline. We don't measure the carbon of
*npm installing* its 1,400 dependencies. Adopt the GSF SCI-D spec when it
stabilises (expected Q3 2026).

### C.7 — Continuous verification
- Chaos test: kill the carbon API, assert circuit breaker opens and fallback
  fires within 30s
- Golden-path canary: every 10 min, run a synthetic pipeline end-to-end across
  3 regions, alert on regression

### C.8 — Privacy & compliance
- Pipeline names, commit messages, author names are PII. Either redact or
  store under a 90-day retention policy. (Currently retained forever in the
  mocked history.)
- Sign every emitted carbon figure cryptographically so external auditors
  (Big-4 ESG verifiers) can validate the chain.

---

## D · Nice-to-have — post-prod roadmap

| Quarter | Feature |
|---|---|
| Q1 | Multi-tenant dashboard for orgs with > 200 pipelines |
| Q1 | Slack/Teams bot: `@green-qa why did my build fail?` |
| Q2 | Recommendation explainability — "we chose SPACE_SHIFT because…" with attribution scores |
| Q2 | Carbon SLOs (analogous to error-budget SLOs) — team commits to a carbon ceiling per sprint |
| Q3 | Forecast-aware autoscaling — fewer pods at high-intensity hours |
| Q3 | Carbon-aware container scheduling — Kubernetes admission controller |
| Q4 | Federated learning across customer instances to improve MAIZX weights |

---

## E · Out of scope (intentional)

- Scope-3 emissions (employee commute, etc.) — Carbon Cost Dashboard is **pipeline-only**
- End-user device emissions of the deployed application — needs frontend RUM tooling, separate product
- Hardware refresh cycle / embodied carbon of new datacenter expansion — that
  sits with the cloud vendor, not the customer

---

## F · How to feed this list back

Open an issue on the central repo tagged `gap:` — the team triages weekly and
items move into the deployment guide once shipped.
