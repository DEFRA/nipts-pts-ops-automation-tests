import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { DeleteCommand, DynamoDBDocumentClient, GetCommand, PutCommand, QueryCommand } from '@aws-sdk/lib-dynamodb';
import { randomUUID } from 'node:crypto';
import {
  CONNECTION_ID,
  type AuditEvent, type CarbonSample, type ConnectionRecord, type DeferredRecord, type ExecutionRecord, type Item, type Repository,
} from './types';

export interface DynamoTables {
  carbon: string;
  executions: string;
  deferred: string;
  connections: string;
  audit: string;
}

const CARBON_TTL_DAYS = 90;
const AUDIT_TTL_DAYS = 400;
const MAX_ITEM_RAW_BYTES = 100_000;

const INTERNAL_KEYS = ['pk', 'sk', 'gsi1pk', 'gsi1sk', 'gsi2pk', 'gsi2sk', 'expires_at'];

function strip<T extends Item>(item: Item | undefined): T | null {
  if (!item) return null;
  const out: Item = { ...item };
  for (const k of INTERNAL_KEYS) delete out[k];
  return out as T;
}

const epochIn = (days: number) => Math.floor(Date.now() / 1000) + days * 86_400;

/**
 * DynamoDB adapter. Access patterns:
 *  carbon       pk=provider#region, sk=sampled_at                 (latest = Query desc, Limit 1; TTL 90d)
 *  executions   pk=pipeline_id, sk=id                             (idempotent upsert)
 *               by_pipeline_provider: gsi1pk=pipeline#provider, gsi1sk=stored_at
 *               by_provider:          gsi2pk=provider,          gsi2sk=stored_at
 *  deferred     pk=id; by_status: gsi1pk=status, gsi1sk=defer_until_iso
 *  connections  pk=id
 *  audit        pk=AUDIT#yyyy-mm-dd, sk=ts#uuid (TTL)
 */
export class DynamoRepository implements Repository {
  private readonly doc: DynamoDBDocumentClient;

  constructor(private readonly tables: DynamoTables, client: DynamoDBClient = new DynamoDBClient({})) {
    this.doc = DynamoDBDocumentClient.from(client, { marshallOptions: { removeUndefinedValues: true } });
  }

  private async put(table: string, item: Item): Promise<void> {
    await this.doc.send(new PutCommand({ TableName: table, Item: item }));
  }

  private async queryAll(params: ConstructorParameters<typeof QueryCommand>[0], limit?: number): Promise<Item[]> {
    const out: Item[] = [];
    let key: Record<string, unknown> | undefined;
    do {
      const res = await this.doc.send(new QueryCommand({ ...params, ExclusiveStartKey: key }));
      out.push(...((res.Items as Item[]) ?? []));
      key = res.LastEvaluatedKey;
    } while (key && (limit === undefined || out.length < limit));
    return limit === undefined ? out : out.slice(0, limit);
  }

  async upsertCarbonSample(s: CarbonSample) {
    await this.put(this.tables.carbon, { ...s, pk: `${s.provider}#${s.region}`, sk: s.sampled_at, expires_at: epochIn(CARBON_TTL_DAYS) });
    return s;
  }

  async upsertExecution(e: ExecutionRecord) {
    const item: Item = { ...e, pk: e.pipeline_id, sk: e.id };
    if (e.provider && e.stored_at) {
      item.gsi1pk = `${e.pipeline_id}#${e.provider}`;
      item.gsi1sk = e.stored_at;
      item.gsi2pk = e.provider;
      item.gsi2sk = e.stored_at;
    }
    // Webhook payloads can be large; keep the item well under the 400 KB limit.
    if (item.raw && JSON.stringify(item.raw).length > MAX_ITEM_RAW_BYTES) item.raw = { truncated: true };
    await this.put(this.tables.executions, item);
    return e;
  }

  async upsertDeferred(d: DeferredRecord) {
    const item: Item = { ...d, pk: d.id };
    if (d.status && d.defer_until_iso) {
      item.gsi1pk = d.status;
      item.gsi1sk = d.defer_until_iso;
    }
    await this.put(this.tables.deferred, item);
    return d;
  }

  async getDeferred(id: string) {
    const res = await this.doc.send(new GetCommand({ TableName: this.tables.deferred, Key: { pk: id } }));
    return strip<DeferredRecord>(res.Item as Item | undefined);
  }

  async listPendingDeferred(nowIso: string) {
    const rows = await this.queryAll({
      TableName: this.tables.deferred,
      IndexName: 'by_status',
      KeyConditionExpression: 'gsi1pk = :s AND gsi1sk <= :now',
      ExpressionAttributeValues: { ':s': 'pending', ':now': nowIso },
      ScanIndexForward: true,
    });
    return rows.map((r) => strip<DeferredRecord>(r) as DeferredRecord);
  }

  async listExecutionsForPipeline(pipelineId: string, provider: string, limit: number) {
    const rows = await this.queryAll({
      TableName: this.tables.executions,
      IndexName: 'by_pipeline_provider',
      KeyConditionExpression: 'gsi1pk = :k',
      ExpressionAttributeValues: { ':k': `${pipelineId}#${provider}` },
      ScanIndexForward: false,
      Limit: limit,
    }, limit);
    return rows.map((r) => strip<ExecutionRecord>(r) as ExecutionRecord);
  }

  async listAllExecutions(provider: string, limit: number) {
    const rows = await this.queryAll({
      TableName: this.tables.executions,
      IndexName: 'by_provider',
      KeyConditionExpression: 'gsi2pk = :p',
      ExpressionAttributeValues: { ':p': provider },
      ScanIndexForward: false,
      Limit: limit,
    }, limit);
    return rows.map((r) => strip<ExecutionRecord>(r) as ExecutionRecord);
  }

  async listExecutionsSince(provider: string, sinceIso: string) {
    const rows = await this.queryAll({
      TableName: this.tables.executions,
      IndexName: 'by_provider',
      KeyConditionExpression: 'gsi2pk = :p AND gsi2sk >= :s',
      ExpressionAttributeValues: { ':p': provider, ':s': sinceIso },
    });
    return rows.map((r) => strip<ExecutionRecord>(r) as ExecutionRecord);
  }

  async getLatestCarbon(provider: string, region: string) {
    const res = await this.doc.send(new QueryCommand({
      TableName: this.tables.carbon,
      KeyConditionExpression: 'pk = :k',
      ExpressionAttributeValues: { ':k': `${provider}#${region}` },
      ScanIndexForward: false,
      Limit: 1,
    }));
    return strip<CarbonSample>(res.Items?.[0] as Item | undefined);
  }

  async latestCarbonByRegion(provider: string, regions: string[]) {
    const entries = await Promise.all(regions.map(async (r) => [r, await this.getLatestCarbon(provider, r)] as const));
    const out: Record<string, CarbonSample> = {};
    for (const [region, sample] of entries) if (sample) out[region] = sample;
    return out;
  }

  async upsertConnection(c: ConnectionRecord, id: string = CONNECTION_ID) {
    const record = { ...c, id };
    await this.put(this.tables.connections, { ...record, pk: id });
    return record;
  }

  async getConnection(id: string = CONNECTION_ID) {
    const res = await this.doc.send(new GetCommand({ TableName: this.tables.connections, Key: { pk: id } }));
    return strip<ConnectionRecord>(res.Item as Item | undefined);
  }

  async deleteConnection(id: string = CONNECTION_ID) {
    await this.doc.send(new DeleteCommand({ TableName: this.tables.connections, Key: { pk: id } }));
  }

  async putAudit(event: AuditEvent) {
    const ts = new Date().toISOString();
    await this.put(this.tables.audit, {
      pk: `AUDIT#${ts.slice(0, 10)}`,
      sk: `${ts}#${randomUUID()}`,
      ts,
      ...event,
      expires_at: epochIn(AUDIT_TTL_DAYS),
    });
  }

  async ping() {
    await this.doc.send(new GetCommand({ TableName: this.tables.connections, Key: { pk: '__health__' } }));
  }
}
