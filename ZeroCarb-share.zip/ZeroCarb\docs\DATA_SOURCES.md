# Data Sources — Live vs Demo

> **Bottom line:** the HTML prototype is 100% demo fixtures. The backend
> Python code that the prototype is *meant to call* really does fetch live
> data from UK Grid ESO, ElectricityMaps and Ember Climate. Wiring them
> together is a known gap (tracked in `GAPS.md`).

This page is the source of truth for "is this number real or fake?" for
every surface in the platform. **Cite this file** when you ship the
prototype to a stakeholder so nothing is mistaken for live telemetry.

---

## 1 · Dashboard prototype (`Carbon Cost Dashboard.html`)

| Section | Data origin | Live in prod? |
|---|---|---|
| Region intensities (gCO₂/kWh, renewable %) | `data.js` → `CCD_DATA.REGIONS` (hard-coded) | **No — demo only** |
| 10 Azure pipelines (auth-service-ci, payment-gateway-ci, …) | `data.js` → `CCD_DATA.PIPELINES` (hard-coded) | **No — demo only** |
| Per-pipeline history sparklines (`history7`) | `data.js` (hard-coded) | **No — demo only** |
| Per-transaction carbon breakdown (e.g. "login flow: 0.52 g CO₂") | `data.js` → fixture transactions | **No — demo only** |
| Team leaderboard, equivalences (km driven, etc.) | `data.js` | **No — demo only** |
| 24 h forecast curve | `data.js` (sine-wave generator) | **No — demo only** |
| Research watcher findings + sources | `data.js` → `RESEARCH_*` | **No — demo only** |
| Synthetic test status, polling countdown | Real `setInterval` in the browser | Real (in-prototype only) |
| Dashboard timestamp ("Updated 21 May · 12:56 UTC") | `Date.now()` driven by `usePolling()` | Real |
| Tweaks / settings (theme, density, polling minutes) | Real React state, persisted to `localStorage` | Real |

A `DEMO DATA` badge is shown in the masthead at all times so users can't
mistake the dashboard for live telemetry.

### How to wire the prototype to the live backend

Replace `data.js`'s static fixtures with `fetch()` calls against the Functions
app:

```js
// Instead of:
const REGIONS = [ { id: 'uksouth', intensity: 164, ... }, ... ];

// Do this:
const REGIONS = await fetch('/api/carbon').then(r => r.json());
```

Endpoints to call:

| `data.js` field | Replace with `fetch()` against |
|---|---|
| `REGIONS` | `GET /api/carbon` |
| `PIPELINES` history & current | `GET /api/history?limit=…` |
| Pre-run gate decision | `POST /api/decide` |
| Per-run SCI | `POST /api/calculate` |
| Budget verdict | `POST /api/budget/check` |

---

## 2 · Backend (`green_qa_lib/eu_carbon_api.py`) — **really live**

The fetcher has a 4-tier fallback chain; the `source` field in every response
tells you which tier served the value:

```
1. UK Grid ESO          (free, no auth)   → source = "live_eso"            (GB only)
2. ElectricityMaps      (token required)  → source = "live_electricitymaps" (any zone)
3. Ember Climate        (free, no auth)   → source = "live_ember"           (any country)
4. Synthetic baseline   (constants)       → source = "synthetic"            (always)
```

A 5-minute in-memory cache (`_CACHE_TTL_S = 300`) wraps the chain.
Per-region baselines used as the synthetic floor:

| AWS region | Zone | Fallback gCO₂/kWh | Renewable % (constant) |
|---|---|---|---|
| eu-north-1 (Stockholm) | SE | 30 | 95 |
| eu-west-3 (Paris) | FR | 60 | 78 |
| eu-south-2 (Madrid) | ES | 180 | 60 |
| eu-west-2 (London) | GB | 211 | 42 |
| eu-south-1 (Milan) | IT-NO | 233 | 55 |
| eu-west-1 (Dublin) | IE | 295 | 40 |
| eu-central-1 (Frankfurt) | DE | 350 | 46 |

PUE multiplier of **1.15** is applied to grid intensity to produce a
"datacenter-adjusted" figure (AWS published value, 2024 sustainability
report).

### How to verify live data is actually flowing

```bash
# Backend, locally
python local_server.py
curl http://localhost:8080/regions/eu | jq '.[0] | {region,intensity,source,is_live}'
# Expect: source ∈ {live_eso, live_electricitymaps, live_ember}
# If source = "synthetic" everywhere, your ELECTRICITYMAPS_TOKEN is missing or your egress is blocked.
```

### What is **always** static (even on the backend)

| Constant | File | Why static |
|---|---|---|
| `PUE_VALUES` (1.15 / 1.10 / 1.185 per cloud) | `green_qa_lib/constants.py` | Annual sustainability reports |
| `VCPU_TDP_WATTS` (10 W generic) | `constants.py` | Industry mean — overridden per CPU family in `hardware_profiler.py` |
| `MEMORY_COEFF_KWH_PER_GB` (0.000392) | `constants.py` | Cloud Carbon Footprint / Etsy Cloud Jewels coefficient |
| `EMBODIED_G_PER_VCPU_HOUR` (2.5) | `constants.py` | Teads / Dell LCA |
| `MAIZX_WEIGHTS` (0.40 / 0.30 / 0.20 / 0.10) | `constants.py` | MAIZX paper, can be overridden via env vars |
| `renewable_pct` per region | `eu_carbon_api.py` | We don't yet pull live generation mix per cloud-zone |

These are scientific constants, **not** telemetry. Their derivations are
documented inline in `constants.py`.

---

## 3 · Research watcher (`research.jsx`, mock-only)

Every field in the research watcher — sources, ingestion log, pending
findings, alignment results — is **fixture data** from `data.js`. The
"Run scan now" button simulates a job via `setInterval`. No HTTP traffic
leaves the browser.

To make this real, the dashboard would call a Function App endpoint that
runs the actual EU/UK gov RSS scan (not implemented in the backend yet —
it's a planned addition).

---

## 4 · Quick FAQ

**Q: The dashboard shows uksouth at 164 gCO₂/kWh. Where does that come from?**
A: It's hard-coded in `data.js`. The real-time value from UK Grid ESO at any
given moment will differ — typically 100–280 gCO₂/kWh depending on wind
output. To see the real number, call `GET /api/carbon` on a deployed
Function App or run `python local_server.py` and hit `/regions/eu`.

**Q: Will the dashboard fall back to demo data if the API is down?**
A: Yes — that's the intended behaviour when we wire it up. The fetch will
fail, we'll catch and log it, and `CCD_DATA.REGIONS` (the current fixture)
becomes the fallback. The `DEMO DATA` badge will flip from a hover-tooltip
into a persistent banner.

**Q: Is the per-transaction breakdown ("login flow: 0.52 g CO₂") real?**
A: No — the dashboard shows static fixture values. The real per-transaction
SCI is computed by `green_qa_lib/sci_calculator.py` after each pipeline run
and stored in Cosmos DB's `pipeline_executions` container. Wiring the
dashboard to read that container is on the gap list.
