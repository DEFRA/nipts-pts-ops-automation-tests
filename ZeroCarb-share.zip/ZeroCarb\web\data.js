/* ============================================================================
   Carbon Cost Dashboard — mock data
   10 Azure pipelines, regions, budgets, transactions, history, forecast
   ============================================================================ */

window.CCD_DATA = (function () {
  // ---------- Azure regions (with live carbon intensity gCO2/kWh) ----------
  const REGIONS = [
    { id: 'northeurope',       name: 'North Europe',          city: 'Dublin',       country: 'IE', intensity: 218, renewable: 0.46, cleanPct: 0.61 },
    { id: 'westeurope',        name: 'West Europe',           city: 'Amsterdam',    country: 'NL', intensity: 287, renewable: 0.38, cleanPct: 0.52 },
    { id: 'uksouth',           name: 'UK South',              city: 'London',       country: 'GB', intensity: 164, renewable: 0.52, cleanPct: 0.71 },
    { id: 'ukwest',            name: 'UK West',               city: 'Cardiff',      country: 'GB', intensity: 172, renewable: 0.50, cleanPct: 0.69 },
    { id: 'francecentral',     name: 'France Central',        city: 'Paris',        country: 'FR', intensity:  56, renewable: 0.27, cleanPct: 0.92 },
    { id: 'germanywestcentral',name: 'Germany West Central',  city: 'Frankfurt',    country: 'DE', intensity: 364, renewable: 0.49, cleanPct: 0.48 },
    { id: 'italynorth',        name: 'Italy North',           city: 'Milan',        country: 'IT', intensity: 312, renewable: 0.42, cleanPct: 0.47 },
    { id: 'swedencentral',     name: 'Sweden Central',        city: 'Gävle',        country: 'SE', intensity:  19, renewable: 0.71, cleanPct: 0.98 },
    { id: 'norwayeast',        name: 'Norway East',           city: 'Oslo',         country: 'NO', intensity:  31, renewable: 0.93, cleanPct: 0.97 },
    { id: 'switzerlandnorth',  name: 'Switzerland North',     city: 'Zurich',       country: 'CH', intensity:  41, renewable: 0.62, cleanPct: 0.94 },
    { id: 'polandcentral',     name: 'Poland Central',        city: 'Warsaw',       country: 'PL', intensity: 678, renewable: 0.21, cleanPct: 0.19 },
    { id: 'spaincentral',      name: 'Spain Central',         city: 'Madrid',       country: 'ES', intensity: 142, renewable: 0.51, cleanPct: 0.66 }
  ];

  const REGION_MAP = Object.fromEntries(REGIONS.map(r => [r.id, r]));

  // ---------- Teams ----------
  const TEAMS = [
    { id: 'identity',   name: 'Identity & Access',   lead: 'A. Okafor',     headcount: 11 },
    { id: 'payments',   name: 'Payments',            lead: 'J. Lindqvist',  headcount: 14 },
    { id: 'catalog',   name: 'Catalog & Search',    lead: 'R. Patel',      headcount:  9 },
    { id: 'platform',  name: 'Platform Engineering', lead: 'M. Costa',      headcount: 12 },
    { id: 'mobile',     name: 'Mobile',              lead: 'S. Tanaka',     headcount:  7 },
    { id: 'data',       name: 'Data & ML',           lead: 'E. Kowalski',   headcount: 10 }
  ];

  const TEAM_MAP = Object.fromEntries(TEAMS.map(t => [t.id, t]));

  // ---------- ADO pipelines (vibecode / GreenQA Pipelines) ----------
  // Mirrors the five pipeline definitions in dev.azure.com/vibecode/GreenQA Pipelines
  // (definition IDs 16–20). Metrics here are last-observed values from real
  // /api/decide calls; transactions are illustrative.
  //   strategy: RUN_NOW | TIME_SHIFT | SPACE_SHIFT | HYBRID
  //   buildStatus: pass | warn | fail
  const PIPELINES = [
    {
      id: 'billing-prod-hotfix', team: 'payments', name: 'billing-prod-hotfix',
      criticality: 'CRITICAL', region: 'uksouth', baselineRegion: 'uksouth',
      budget: 12, current: 8.4, lastRunMin: 12,
      strategy: 'RUN_NOW',
      strategyReason: 'Criticality=CRITICAL · runs immediately, no shifting allowed',
      lastRunISO: 'T-18m', lastRunUser: 'ado-pipeline',
      buildStatus: 'pass',
      history7: [9.6, 9.2, 9.0, 8.7, 8.5, 8.4, 8.4],
      vcpu: 4, memoryGb: 8,
      adoDefinitionId: 16,
      transactions: [
        { name: 'apply hotfix branch',       co2: 1.80, runs:    1, p95: 2.0 },
        { name: 'smoke billing tests',       co2: 4.20, runs:    1, p95: 6.0 },
        { name: 'rollback drill',            co2: 1.40, runs:    1, p95: 2.5 },
        { name: 'sign + deploy',             co2: 1.00, runs:    1, p95: 1.5 }
      ]
    },
    {
      id: 'nightly-ci-azure-fn', team: 'platform', name: 'nightly-ci-azure-fn',
      criticality: 'NORMAL', region: 'swedencentral', baselineRegion: 'swedencentral',
      budget: 24, current: 16.9, lastRunMin: 25,
      strategy: 'TIME_SHIFT',
      strategyReason: 'Forecast 36% drop in 3h · defer in-region',
      lastRunISO: 'T-22m', lastRunUser: 'ado-pipeline',
      buildStatus: 'pass',
      history7: [20.1, 19.4, 18.6, 17.8, 17.2, 17.0, 16.9],
      vcpu: 2, memoryGb: 4,
      adoDefinitionId: 17,
      transactions: [
        { name: 'unit suite',                co2: 6.20, runs:    1, p95:12.0 },
        { name: 'integration suite',         co2: 7.40, runs:    1, p95:14.0 },
        { name: 'lint + type check',         co2: 1.50, runs:    1, p95: 2.0 },
        { name: 'package + publish',         co2: 1.80, runs:    1, p95: 3.0 }
      ]
    },
    {
      id: 'api-tests-smoke', team: 'catalog', name: 'api-tests-smoke',
      criticality: 'NORMAL', region: 'uksouth', baselineRegion: 'uksouth',
      budget: 9, current: 6.4, lastRunMin: 6,
      strategy: 'SPACE_SHIFT',
      strategyReason: 'swedencentral is 88.4% cleaner (19 vs 164 gCO2/kWh) · relocate',
      lastRunISO: 'T-19m', lastRunUser: 'ado-pipeline',
      buildStatus: 'pass',
      history7: [7.8, 7.4, 7.0, 6.8, 6.6, 6.5, 6.4],
      vcpu: 2, memoryGb: 4,
      adoDefinitionId: 18,
      transactions: [
        { name: 'auth probe',                co2: 1.40, runs:    1, p95: 1.0 },
        { name: 'core API smoke',            co2: 3.20, runs:    1, p95: 3.5 },
        { name: 'pagination + filter probe', co2: 1.20, runs:    1, p95: 1.5 },
        { name: 'health endpoint check',     co2: 0.60, runs:    1, p95: 0.5 }
      ]
    },
    {
      id: 'ml-train-fraud-detection', team: 'data', name: 'ml-train-fraud-detection',
      criticality: 'LOW', region: 'germanywestcentral', baselineRegion: 'germanywestcentral',
      budget: 320, current: 218.0, lastRunMin: 180,
      strategy: 'HYBRID',
      strategyReason: 'Shift to swedencentral AND wait 5h for forecast minimum · 94.78% saving',
      lastRunISO: 'T-23m', lastRunUser: 'ado-pipeline',
      buildStatus: 'pass',
      history7: [284.0, 272.0, 254.0, 244.0, 232.0, 224.0, 218.0],
      vcpu: 16, memoryGb: 64,
      adoDefinitionId: 19,
      transactions: [
        { name: 'feature engineering',       co2:48.20, runs:    1, p95:42.0 },
        { name: 'embedding train',           co2:118.40,runs:    1, p95:90.0 },
        { name: 'eval + holdout',            co2:32.60, runs:    1, p95:28.0 },
        { name: 'checkpoint export',         co2:18.80, runs:    1, p95:12.0 }
      ]
    },
    {
      id: 'e2e-tests-ms-hosted', team: 'catalog', name: 'e2e-tests-ms-hosted',
      criticality: 'NORMAL', region: 'germanywestcentral', baselineRegion: 'germanywestcentral',
      budget: 14, current: 11.6, lastRunMin: 20,
      strategy: 'RUN_NOW',
      strategyReason: 'MS-hosted pool cannot relocate · engine recommended RELOCATE → swedencentral',
      lastRunISO: 'T-21m', lastRunUser: 'ado-pipeline',
      buildStatus: 'pass',
      history7: [12.4, 12.2, 12.0, 11.8, 11.7, 11.6, 11.6],
      vcpu: 2, memoryGb: 4,
      adoDefinitionId: 20,
      transactions: [
        { name: 'browser setup',             co2: 1.80, runs:    1, p95: 2.5 },
        { name: 'e2e suite (chromium)',      co2: 6.40, runs:    1, p95:11.0 },
        { name: 'visual diff',               co2: 2.40, runs:    1, p95: 5.0 },
        { name: 'artefact upload',           co2: 1.00, runs:    1, p95: 1.5 }
      ]
    }
  ];

  // ---------- 24h forecast (gCO2/kWh) for UK South ----------
  // hour 0..23, each: { hour, intensity, isOptimal }
  const FORECAST_24H = [
    164,159,152,148,142,138,134,128,124,138,156,178,
    194,206,218,226,232,228,214,196,176,162,154,148
  ].map((v, h) => ({ hour: h, intensity: v }));
  // optimal window 03:00–06:00
  FORECAST_24H[3].isOptimal = true;
  FORECAST_24H[4].isOptimal = true;
  FORECAST_24H[5].isOptimal = true;
  FORECAST_24H[6].isOptimal = true;

  // ---------- Pipeline history (last 30 days) ----------
  const HISTORY = (function () {
    const out = [];
    const strategies = ['RUN_NOW','TIME_SHIFT','SPACE_SHIFT','HYBRID'];
    let day = 0;
    for (let i = 0; i < 96; i++) {
      const p = PIPELINES[i % PIPELINES.length];
      const r = REGIONS[Math.floor(Math.random() * 6)];
      const base = p.current * (0.78 + Math.random() * 0.5);
      out.push({
        id: 'run-' + (10240 - i),
        pipeline: p.id,
        team: p.team,
        region: r.id,
        strategy: strategies[Math.floor(Math.random() * 4)],
        co2: +(base).toFixed(2),
        baselineCo2: +(base * (1.4 + Math.random() * 0.6)).toFixed(2),
        durationMin: +(p.lastRunMin * (0.8 + Math.random() * 0.5)).toFixed(0),
        when: i,
        status: Math.random() > 0.08 ? 'pass' : (Math.random() > 0.5 ? 'fail' : 'warn'),
        commit: 'a' + Math.random().toString(16).slice(2, 9),
        author: ['a.chen','r.patel','j.lindqvist','m.costa','s.tanaka','e.kowalski','a.okafor'][Math.floor(Math.random()*7)]
      });
      day = i;
    }
    return out;
  })();

  // ---------- Strategy distribution (last 30d) ----------
  const STRATEGY_MIX = (function () {
    const counts = { RUN_NOW: 0, TIME_SHIFT: 0, SPACE_SHIFT: 0, HYBRID: 0 };
    HISTORY.forEach(h => counts[h.strategy]++);
    const total = HISTORY.length;
    return Object.entries(counts).map(([k, v]) => ({ id: k, count: v, pct: v / total }));
  })();

  // ---------- Totals ----------
  const TOTALS = {
    co2SavedMonth: 4218,    // gCO2
    co2EmittedMonth: 12640, // gCO2
    co2PrevMonth: 17104,
    pricePerKgCO2: 0.085,   // $ shadow price per kg CO2
    azureSpendMonth: 18420, // $ total Azure spend this month
    azureSpendSaved: 612,   // $ saved by carbon-aware routing this month
    runs24h: 184,
    runsMonth: 2104,
    avgCarbonPerRun: 6.01,
    builds: { pass: 2061, warn: 38, fail: 5 },
    optimalWindow: '03:00–06:00',
    optimalSavingsPct: 0.34
  };

  // Equivalences (gCO2 -> human scale)
  function equivalences(gCo2) {
    return {
      drivingKm:   gCo2 / 192,        // ~192 gCO2/km for petrol car
      treesYears:  gCo2 / 21000,      // tree absorbs ~21 kg CO2/year
      homesHours:  gCo2 / 740,        // avg home 740 gCO2/h
      phoneCharge: gCo2 / 8.4,        // phone charge ~8.4 gCO2
      flightsLON_PAR: gCo2 / 53000    // economy LON→PAR ~53 kg CO2
    };
  }

  // ---------- Research Watcher: trusted EU/UK gov sources ----------
  // Curated allow-list. NO arXiv, no broad crawling.
  const RESEARCH_SOURCES = [
    { id: 'gov-uk',        name: 'GOV.UK Publications',           org: 'UK Cabinet Office',         host: 'gov.uk/api/content/publications',                 country: 'GB', kind: 'json-api', status: 'ok',     lastMs: 412,  lastChecked: 'T-02h', newDocs: 2, processed: 1842, type: 'incremental' },
    { id: 'defra',         name: 'Defra Digital Sustainability',  org: 'Dept for Env, Food & Rural Affairs', host: 'defra.gov.uk/sustainability/feeds/rss', country: 'GB', kind: 'rss',      status: 'ok',     lastMs: 188,  lastChecked: 'T-02h', newDocs: 1, processed:  214, type: 'incremental' },
    { id: 'desnz',         name: 'DESNZ — Energy Statistics',     org: 'Dept for Energy Security & Net Zero', host: 'desnz.gov.uk/datasets/api',           country: 'GB', kind: 'json-api', status: 'ok',     lastMs: 624,  lastChecked: 'T-02h', newDocs: 0, processed:  398, type: 'incremental' },
    { id: 'ofgem',         name: 'Ofgem Decarbonisation',          org: 'Office of Gas & Electricity Markets', host: 'ofgem.gov.uk/publications.atom',      country: 'GB', kind: 'atom',     status: 'slow',   lastMs: 4180, lastChecked: 'T-02h', newDocs: 0, processed:  167, type: 'incremental' },
    { id: 'ec-europa',     name: 'European Commission OP',         org: 'EU Publications Office',    host: 'op.europa.eu/api/cellar',                         country: 'EU', kind: 'sparql',   status: 'ok',     lastMs: 902,  lastChecked: 'T-02h', newDocs: 1, processed: 2117, type: 'incremental' },
    { id: 'eea',           name: 'European Environment Agency',    org: 'EEA',                       host: 'eea.europa.eu/api/SITE/datahub',                  country: 'EU', kind: 'json-api', status: 'ok',     lastMs: 318,  lastChecked: 'T-02h', newDocs: 0, processed:  541, type: 'incremental' },
    { id: 'jrc',           name: 'JRC Open Data',                  org: 'EC Joint Research Centre',  host: 'data.jrc.ec.europa.eu/api/datasets',              country: 'EU', kind: 'ckan',     status: 'ok',     lastMs: 1102, lastChecked: 'T-02h', newDocs: 1, processed:  883, type: 'incremental' },
    { id: 'eurostat',      name: 'Eurostat Environment',           org: 'Eurostat',                  host: 'ec.europa.eu/eurostat/api/dissemination/sdmx',    country: 'EU', kind: 'sdmx',     status: 'ok',     lastMs: 740,  lastChecked: 'T-02h', newDocs: 0, processed:  329, type: 'incremental' },
    { id: 'cnra-fr',       name: 'ADEME Base Carbone',             org: 'ADEME (Fr. env. agency)',   host: 'data.ademe.fr/datasets/base-carbone',             country: 'FR', kind: 'json-api', status: 'timeout',lastMs: null, lastChecked: 'T-02h', newDocs: 0, processed:  118, type: 'fallback'    },
    { id: 'uk-parl',       name: 'UK Parliament Library',          org: 'House of Commons Library',  host: 'commonslibrary.parliament.uk/api/research',       country: 'GB', kind: 'rss',      status: 'ok',     lastMs: 256,  lastChecked: 'T-02h', newDocs: 0, processed:  207, type: 'incremental' }
  ];

  // ---------- Filter keywords applied BEFORE downloading full content ----------
  const RESEARCH_KEYWORDS = [
    'carbon', 'sustainability', 'emissions', 'net zero', 'decarbonisation',
    'green compute', 'energy intensity', 'grid carbon', 'scope 3', 'renewable'
  ];

  // ---------- Pending findings (need user confirmation before adding to /researchPaper/) ----------
  const PENDING_FINDINGS = [
    {
      id: 'finding-01',
      title: 'Greening Government ICT and Digital Services Strategy 2025–2030 — annex C',
      source: 'gov-uk', sourceLabel: 'GOV.UK',
      published: '2026-05-18',
      docType: 'PDF', sizeKb: 1842,
      keywords: ['carbon', 'sustainability', 'net zero', 'scope 3'],
      relevance: 0.93,
      summary: 'Updates mandatory carbon reporting bands for central-gov digital services, including new SCI thresholds for CI/CD pipelines.',
      url: 'https://gov.uk/government/publications/greening-government-ict-2025-annex-c',
      stage: 'metadata-only'
    },
    {
      id: 'finding-02',
      title: 'Defra Digital Sustainability Strategy 2025–2030 — revision 1.1',
      source: 'defra', sourceLabel: 'Defra',
      published: '2026-05-15',
      docType: 'HTML', sizeKb: 312,
      keywords: ['sustainability', 'emissions', 'decarbonisation'],
      relevance: 0.88,
      summary: 'Adds explicit guidance on carbon-aware scheduling for departmental compute. Aligned with MAIZX framework references.',
      url: 'https://defra.gov.uk/sustainability/strategy-2025-rev-1-1',
      stage: 'full-fetched'
    },
    {
      id: 'finding-03',
      title: 'JRC Technical Report — Marginal vs Average Carbon Intensity for Data-Centre Workloads',
      source: 'jrc', sourceLabel: 'JRC',
      published: '2026-05-12',
      docType: 'PDF', sizeKb: 4214,
      keywords: ['carbon', 'grid carbon', 'energy intensity'],
      relevance: 0.82,
      summary: 'Quantifies under-reporting risk when using average-intensity attribution; recommends marginal-CI for workload shifting decisions.',
      url: 'https://publications.jrc.ec.europa.eu/repository/handle/JRC138291',
      stage: 'metadata-only'
    },
    {
      id: 'finding-04',
      title: 'EU Commission CSRD Delegated Act — ESRS E1 Climate Change (consolidated)',
      source: 'ec-europa', sourceLabel: 'EU Commission',
      published: '2026-05-09',
      docType: 'PDF', sizeKb: 2987,
      keywords: ['emissions', 'net zero', 'scope 3'],
      relevance: 0.71,
      summary: 'Consolidated reporting standard. Scope 3 category 1 (purchased goods/services) clarifications relevant for cloud-emissions attribution.',
      url: 'https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32026R0418',
      stage: 'metadata-only'
    }
  ];

  // ---------- Structured ingest log (most recent first) ----------
  const RESEARCH_LOG = [
    { ts: 'T-02h 12m', source: 'gov-uk',   docKey: 'pub:greening-gov-ict-2025-annex-c',          action: 'queued',      detail: 'matches 4/10 keywords · relevance 0.93' },
    { ts: 'T-02h 12m', source: 'gov-uk',   docKey: 'pub:digital-service-manual-update-may-2026', action: 'filtered',    detail: 'no keyword match' },
    { ts: 'T-02h 11m', source: 'defra',    docKey: 'rss:strategy-2025-rev-1-1',                  action: 'queued',      detail: 'full doc fetched · 312 kB' },
    { ts: 'T-02h 11m', source: 'defra',    docKey: 'rss:flood-risk-bulletin-may-2026',           action: 'filtered',    detail: 'no keyword match' },
    { ts: 'T-02h 10m', source: 'desnz',    docKey: 'ds:energy-stats-q1-2026',                    action: 'duplicate',   detail: 'sha256 matches stored doc' },
    { ts: 'T-02h 10m', source: 'ofgem',    docKey: '—',                                          action: 'timeout',     detail: 'fallback skipped after 5s · will retry next cycle' },
    { ts: 'T-02h 09m', source: 'ec-europa',docKey: 'cellar:CELEX-32026R0418',                    action: 'queued',      detail: 'matches 3/10 keywords · relevance 0.71' },
    { ts: 'T-02h 09m', source: 'eea',      docKey: 'datahub:eu-air-quality-2026-q1',             action: 'filtered',    detail: 'not in scope (air quality)' },
    { ts: 'T-02h 08m', source: 'jrc',      docKey: 'jrc:JRC138291',                              action: 'queued',      detail: 'matches 3/10 keywords · relevance 0.82' },
    { ts: 'T-02h 08m', source: 'jrc',      docKey: 'jrc:JRC138217',                              action: 'duplicate',   detail: 'sha256 matches stored doc' },
    { ts: 'T-02h 07m', source: 'eurostat', docKey: 'sdmx:env_air_gge',                           action: 'unchanged',   detail: 'last-modified ≤ last run timestamp' },
    { ts: 'T-02h 07m', source: 'uk-parl',  docKey: 'rss:cbp-9876-net-zero-2026',                 action: 'unchanged',   detail: 'last-modified ≤ last run timestamp' },
    { ts: 'T-02h 06m', source: 'cnra-fr',  docKey: '—',                                          action: 'timeout',     detail: 'connection refused · fallback skipped' }
  ];

  // ---------- Alignment scorecard (post-acceptance suggestions — never auto-applied) ----------
  const RESEARCH_ALIGNMENT = [
    { kind: 'aligned',    area: 'Carbon-aware scheduling',     finding: 'Defra strategy §4.2 endorses workload time-shifting',   evidence: 'green_qa_lib/scheduling_engine.py · MAIZX scorer present' },
    { kind: 'aligned',    area: 'Scope 3 attribution',         finding: 'CSRD ESRS E1 mandates cloud emissions attribution',     evidence: 'green_qa_lib/sci_calculator.py · TEADS calc present' },
    { kind: 'aligned',    area: 'Pipeline-level budgets',      finding: 'GOV.UK annex C mandates per-service budgets',           evidence: 'carbon_gate.py · per-pipeline budgets enforced' },
    { kind: 'gap',        area: 'Marginal carbon intensity',   finding: 'JRC report: average-CI under-reports by 8–22%',         evidence: 'utility currently uses average-CI from ElectricityMaps' },
    { kind: 'gap',        area: 'Mandatory reporting bands',   finding: 'GOV.UK new SCI thresholds (≤8 / ≤20 / ≤60 g per build)', evidence: 'budgets are configurable but bands are not preset' },
    { kind: 'suggestion', area: 'Quarterly disclosure pack',   finding: 'CSRD requires audit-ready quarterly bundle',            evidence: 'no quarterly export task — add to lambda/api/' }
  ];

  // Schedule for the watcher
  const RESEARCH_SCHEDULE = {
    intervalDays: 7,
    nextRunISO: '2026-05-26T02:00:00Z',
    lastRunISO: '2026-05-19T02:00:00Z',
    timeoutSec: 5,
    parallelism: 4,
    folderTarget: 'researchPaper/'
  };

  return {
    REGIONS, REGION_MAP, TEAMS, TEAM_MAP, PIPELINES,
    FORECAST_24H, HISTORY, STRATEGY_MIX, TOTALS,
    equivalences,
    RESEARCH_SOURCES, RESEARCH_KEYWORDS, PENDING_FINDINGS, RESEARCH_LOG, RESEARCH_ALIGNMENT, RESEARCH_SCHEDULE
  };
})();
