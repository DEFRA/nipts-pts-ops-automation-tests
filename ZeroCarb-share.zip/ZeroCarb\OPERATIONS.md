# Carbon Cost Dashboard — Operations Runbook

Code-accurate operational guide. For the deployment procedure see
`DEPLOYMENT.md`. For the component diagram see `docs/ARCHITECTURE.md`.

> Earlier versions of this file referenced PagerDuty, Front Door, k6 load
> tests, and a `/v1/*` API surface — those described a future state.
> What's below matches the Bicep + Function App we actually ship.

---

## 1 · Service surface

### 1.1 HTTP routes (auth: Function key)

All routes are POST unless marked. `host.json` sets `routePrefix=api`.

| Route | Notes |
|---|---|
| `POST /api/decide` | Carbon-aware scheduling decision |
| `POST /api/store_result` | Persist actual carbon cost of a run |
| `POST /api/calculate` | SCI footprint for a hypothetical workload |
| `POST /api/budget/check` | Compare actual gCO2 to a budget rule |
| `GET  /api/history?pipeline_id=&provider=&limit=` | Paginated execution history |
| `GET  /api/carbon?provider=` | Region catalogue + latest intensity |
| `POST /api/ingest-ado-event` | Azure DevOps Service Hook sink |

### 1.2 Timer triggers

| Function | Schedule | Effect |
|---|---|---|
| `ingest_carbon` | every 30 min | Polls `ElectricityMapsClient` per provider/region; upserts to `carbon_intensity_history`. Driven by the `INGEST_PROVIDERS` App Setting. |
| `resume_deferred` | every 5 min | Scans `deferred_runs` for `status=pending && defer_until_iso<=now`; re-triggers via `ado_client.run_pipeline`; bumps `attempts`, terminal at `DEFER_MAX_ATTEMPTS`. |

---

## 2 · Configuration

All knobs are App Settings on the Function App and surface via env vars in
code (see `backend/azure/functions/function_app.py` `_env_*` helpers).
Complete inventory with inline group comments: `local.settings.json.example`.

To change a runtime value without redeploying:

```bash
az functionapp config appsettings set \
  --resource-group rg-green-qa-prod \
  --name <functionAppName> \
  --settings MIN_SAVINGS_PERCENT=15 ALLOW_HYBRID=false
# Functions host restarts automatically (~30s).
```

To rotate the ADO PAT:

```bash
az keyvault secret set \
  --vault-name <keyVaultName> \
  --name ado-pat \
  --value "$NEW_PAT"

# Force-restart the Function App so the cached PAT clears.
az functionapp restart -g rg-green-qa-prod -n <functionAppName>
```

> Known gap (logged for Step 10 security review): `ado_client._KV_SECRET_CACHE`
> caches the PAT for the host's lifetime; restart is the only way to roll it
> right now.

---

## 3 · Observability

### 3.1 Where logs go

- Every `logger.exception(...)` site flows to Application Insights.
- The Log Analytics workspace named `log-<baseName>-<env>` is the
  long-term store. 30-day retention by default; change in `main.bicep`.

### 3.2 Useful KQL queries

```kusto
// Last 1h of /api/decide outcomes
requests
| where timestamp > ago(1h)
| where name == "decide_endpoint"
| summarize count() by tostring(resultCode)

// 5xx from any HTTP route
requests
| where timestamp > ago(24h) and toint(resultCode) >= 500
| project timestamp, name, resultCode, operation_Id

// ingest_carbon runs and their row counts (if logged at INFO)
traces
| where timestamp > ago(24h)
| where operation_Name == "ingest_carbon"

// resume_deferred — how many pending rows it picked up each cycle
traces
| where message startswith "resume_deferred"
| project timestamp, message
```

### 3.3 Suggested alerts (to be wired in Step 9)

The Bicep does **not** ship Monitor alert rules today. Author them as
follow-up resources or via portal. Recommended starter set:

| Alert | Threshold | Severity |
|---|---|---|
| Function 5xx rate | >1% over 15 min | High |
| Function failures (any) | >5 over 5 min | High |
| `ingest_carbon` quiet | No success in 90 min | Critical |
| `resume_deferred` failures | >3 in 30 min | High |
| Cosmos 429s | >10 in 5 min | Medium |
| Key Vault access denied | any | High |
| App Insights ingestion lag | >5 min | Medium |

---

## 4 · Incident playbooks

### "Dashboard says PREVIEW · FIXTURE DATA forever"

The SPA's `LIVE DATA` badge flips only when `useStore().azure.connected`
is true. Until Step 5 of the deployment plan runs (apiClient + tab
wiring), this is expected.

### "/api/decide is returning 500s"

1. App Insights: `requests | where name == "decide_endpoint" and resultCode == "500"`.
2. Inspect a sample's `operation_Id`, then `traces | where operation_Id == "<id>"`
   for the `'/decide failed'` exception.
3. If the failure is `green_qa_lib` import → confirm `green_qa_lib/` is in
   the deployed artifact. If the stub is in place and you expected the real
   library, the swap-out wasn't completed.
4. If the failure is `scheduling_engine_error: ...` text in the response,
   the engine itself raised — fallback already returns RUN_NOW, so no
   pipeline blocks; investigate the underlying engine issue.

### "Deferred runs are not resuming"

1. `traces | where operation_Name == "resume_deferred" | take 50`.
2. Confirm rows exist: portal → Cosmos → `deferred_runs` → query
   `SELECT * FROM c WHERE c.status = 'pending'`.
3. If `last_error` mentions ADO HTTP → check `ado-pat` secret validity.
4. Rows with `attempts >= DEFER_MAX_ATTEMPTS` are terminal (`status=failed`);
   that's by design.

### "Budget gate keeps firing but the build needs to ship"

There is no `Override budget` API path today — that's a SPA-only flow in
`modals.jsx` (see GAPS.md). For now: bypass at the pipeline level (skip
the gate task) and file the audit entry manually.

---

## 5 · Routine ops

### 5.1 Force a carbon ingestion run

```bash
# Portal: Function App → ingest_carbon → "Code + Test" → Run
# Or via REST:
curl -X POST "https://<functionAppName>.azurewebsites.net/admin/functions/ingest_carbon" \
  -H "Content-Type: application/json" \
  -H "x-functions-key: $MASTER_KEY" \
  -d '{}'
```

### 5.2 Tail logs live

```bash
func azure functionapp logstream <functionAppName>
```

### 5.3 Re-seed a pipeline marker

```python
# Locally, against an authenticated env:
from cosmos_dal import get_dal, seed_onboarding_marker
seed_onboarding_marker(get_dal(), pipeline_id="azdo://org/proj/123")
```

---

## 6 · Resilience guarantees today

- **In-memory DAL fallback**: if `COSMOS_ENDPOINT` is unset or unreachable
  at startup, `CosmosDAL` runs in-process — *useful for local dev only;
  do not deploy with `COSMOS_ENDPOINT` blank.*
- **Resume short-circuit**: pipelines re-triggered with
  `GreenQA_Resumed=true` skip MAIZX evaluation. Prevents DEFER loops.
- **Engine failure → RUN_NOW**: if `SchedulingEngine.get_optimal_strategy`
  raises, `decision_service.decide` returns RUN_NOW in the current region
  with `reasoning='scheduling_engine_error: ...'`. No pipeline is blocked
  by an engine outage.
- **DEFER_MAX_ATTEMPTS**: after that many tries, the deferred row goes to
  `failed` and stops re-triggering.

What we don't ship yet (logged in GAPS.md): circuit breakers, paired-region
deployment, automated backups, idempotency keys.

---

## 7 · Capacity

The Function App is on Consumption (`Y1`). Cold-start latency on Python
3.11 Linux Consumption is typically 1–3 s for the first request after
idle. For consistently sub-second latency, upgrade to a Premium plan
(`EP1`) — requires editing `hostingPlan.sku` in `main.bicep`.

Cosmos DB is Serverless; suitable for ≤ 5,000 RU/s sustained. Above that
switch to provisioned throughput or autoscale.
