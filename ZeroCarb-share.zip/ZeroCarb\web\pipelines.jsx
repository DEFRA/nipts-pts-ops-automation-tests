/* global React, Atoms, useStore */
// =======================================================================
// Pipelines tab — 100% Azure DevOps driven (no fixtures).
//
//   - Pipeline catalogue comes from the store (GET /api/ado/pipelines),
//     grouped by repository. The selector is search + grouped + lazy-loaded
//     so it scales past 100+ pipelines.
//   - Run history comes from GET /api/history?pipeline_id=<definitionId>.
//     When a pipeline has no recorded runs yet we show an empty state.
//   - The recommendation block compares the home region (tweak) against the
//     cleanest region from GET /api/carbon. When they are the same the
//     recommendation actions are hidden. The actions (Apply Recommendation /
//     Run Now / Re-route) call POST /api/decide and surface the real-time
//     execution status + raw API response.
// =======================================================================

const { PageHeader } = Atoms;
const PAGE_SIZE = 10;

function PipelinesTable({ tweaks }) {
  const { pipelines, repos, pipelinesState, toast } = useStore();
  const provider = tweaks.provider || 'azure';

  const [selectedId, setSelectedId] = React.useState('');
  React.useEffect(() => {
    if (!pipelines.length) { setSelectedId(''); return; }
    if (!pipelines.find(p => p.id === selectedId)) setSelectedId(pipelines[0].id);
  }, [pipelines, selectedId]);

  const selected = pipelines.find(p => p.id === selectedId) || null;
  // Bumped after a run is triggered so Run History re-fetches immediately.
  const [historyNonce, setHistoryNonce] = React.useState(0);
  const { runs, loading: runsLoading, error: runsError } = usePipelineRuns(selected, provider, historyNonce);
  const { regions, executionRegions } = useCarbonRegions(provider);

  const [page, setPage] = React.useState(1);
  React.useEffect(() => { setPage(1); }, [selectedId]);

  const totalPages = Math.max(1, Math.ceil(runs.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const start = (currentPage - 1) * PAGE_SIZE;
  const pageRows = runs.slice(start, start + PAGE_SIZE);
  const latest = runs[0];

  // Quick re-execution of a failed run: re-trigger the selected pipeline in the
  // same region the failed run targeted. Mirrors the recommendation card's
  // Run Now (decide → adoRun), then refreshes Run History.
  const [rerunningId, setRerunningId] = React.useState(null);
  const rerunFailed = (run) => {
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !selected) return;
    const region = run.region || tweaks.home_region || 'uksouth';
    const rowKey = run.id || run.run_id;
    setRerunningId(rowKey);
    const decideBody = {
      pipeline_id: selected.id, run_id: 'ui-rerun-' + Date.now(), provider,
      current_region: region, candidate_regions: [region],
      criticality: 'normal', pool_mode: 'ms_hosted_single_region'
    };
    api.decide(decideBody)
      .then(dres => {
        const decisionId = (dres.ok && dres.data && dres.data.decision_id) || undefined;
        return api.adoRun({
          pipeline_id: selected.id, project: selected.project, region,
          baseline_region: region, decision: 'RUN_NOW',
          decision_id: decisionId, provider, criticality: 'normal'
        });
      })
      .then(res => {
        const d = (res && res.data) || {};
        const triggered = !!d.triggered;
        toast({
          kind: triggered ? 'success' : 'error',
          title: triggered ? 'Re-run triggered' : 'Re-run failed',
          message: selected.name + ' → ' + region + (d.run_id ? ' · run ' + d.run_id : ''),
          detail: triggered
            ? 'Queued in Azure DevOps · logged to Run History'
            : (d.error || (res && res.error) || 'ADO trigger failed')
        });
        setHistoryNonce(n => n + 1);
      })
      .catch(() => {
        toast({ kind: 'error', title: 'Re-run failed', message: 'Could not reach the backend.' });
      })
      .finally(() => setRerunningId(null));
  };

  // ---- empty / loading states for the catalogue itself ----
  if (pipelinesState.loading) {
    return (
      <section aria-label="Pipelines">
        <PageHeader title="Pipelines" subtitle="Loading pipelines from Azure DevOps…" />
        <p className="muted" role="status">Fetching your repositories and pipelines…</p>
      </section>
    );
  }
  if (pipelinesState.error) {
    return (
      <section aria-label="Pipelines">
        <PageHeader title="Pipelines" subtitle="Azure DevOps pipelines." />
        <p className="inline-notice error" role="alert">
          Could not load pipelines ({pipelinesState.error}). Re-check the Azure Configuration.
        </p>
      </section>
    );
  }
  if (!pipelines.length) {
    return (
      <section aria-label="Pipelines">
        <PageHeader title="Pipelines" subtitle="Azure DevOps pipelines." />
        <p className="inline-notice" role="status">No pipelines were found in the connected organization.</p>
      </section>
    );
  }

  const repoCount = repos.length;

  return (
    <section aria-label="Pipelines">
      <PageHeader
        title="Pipelines"
        subtitle={
          pipelines.length + ' pipelines across ' + repoCount + ' '
          + (repoCount === 1 ? 'repository' : 'repositories') + ' · carbon-aware run history.'
        }
        actions={
          <PipelineSelect repos={repos} value={selectedId} onChange={setSelectedId} />
        }
      />

      {selected && (
        <PipelineRecommendation
          pipeline={selected}
          regions={regions}
          executionRegions={executionRegions}
          tweaks={tweaks}
          provider={provider}
          latest={latest}
          onRan={() => setHistoryNonce(n => n + 1)}
        />
      )}

      <section className="subsection" aria-label="Run history">
        <h2 className="subsection-title">Run history</h2>
        <p className="subsection-subtitle">
          {selected ? selected.name : '—'}
          {runs.length ? ' · last ' + runs.length + ' runs · 10 per page' : ''}
        </p>

        {runsLoading ? (
          <p className="muted" role="status">Loading run history…</p>
        ) : runsError && runsError !== 'no_api_url' ? (
          <p className="inline-notice error" role="alert">Could not load run history ({runsError}).</p>
        ) : runs.length === 0 ? (
          <p className="inline-notice" role="status">
            No runs recorded for <strong>{selected && selected.name}</strong> yet.
            History appears once carbon-gated runs complete.
          </p>
        ) : (
          <>
            <div className="data-table-wrap">
              <table className="pipe-table">
                <thead>
                  <tr>
                    <th style={{ minWidth: 200 }}>Pipeline</th>
                    <th style={{ minWidth: 150 }}>When</th>
                    <th style={{ minWidth: 170 }}>Region</th>
                    <th className="pipe-numeric" style={{ minWidth: 130 }}>gCO₂ / Run</th>
                    <th className="pipe-numeric" style={{ minWidth: 110 }}>Duration</th>
                    <th>Status</th>
                    <th style={{ minWidth: 110 }}>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {pageRows.map(r => (
                    <tr key={r.id || r.run_id}>
                      <td>
                        <span className="run-pipeline-name">{selected ? selected.name : (r.pipeline || '—')}</span>
                        {r === latest && <span className="reg-flag best-flag" style={{ marginLeft: 8 }}>Latest</span>}
                      </td>
                      <td className="muted">{formatRunWhen(r)}</td>
                      <td><IntensityCell region={r.region} intensity={regionIntensity(regions, r.region)} /></td>
                      <td className="pipe-numeric">
                        <strong>{(r.co2 || 0).toFixed(1)} g</strong>
                        {r.baselineCo2 > r.co2 && (
                          <div className="muted" style={{ fontSize: 'var(--t-12)' }}>
                            saved {(r.baselineCo2 - r.co2).toFixed(1)} g vs baseline
                          </div>
                        )}
                      </td>
                      <td className="pipe-numeric muted">{formatDuration(r)}</td>
                      {/* Failed status shows the brief failure reason on hover (native tooltip). */}
                      <td><StatusPill status={r.status} reason={isFailedRun(r) ? failureReasonText(r) : null} /></td>
                      {/* Quick re-execution for failed runs only. */}
                      <td>
                        {isFailedRun(r) && (
                          <button
                            type="button"
                            className="btn ghost"
                            style={{ padding: '4px 10px', fontSize: 'var(--t-12)' }}
                            disabled={rerunningId === (r.id || r.run_id)}
                            title={'Re-run ' + (selected ? selected.name : 'this pipeline') + ' in ' + (r.region || 'home region')}
                            onClick={() => rerunFailed(r)}
                          >
                            {rerunningId === (r.id || r.run_id) ? 'Starting…' : 'Run Now'}
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {runs.length > PAGE_SIZE && (
              <Pagination
                currentPage={currentPage}
                totalPages={totalPages}
                totalItems={runs.length}
                pageSize={PAGE_SIZE}
                start={start}
                onChange={setPage}
              />
            )}
          </>
        )}
      </section>
    </section>
  );
}

// -----------------------------------------------------------------------
// PipelineSelect — search + repo-grouped + lazy-loaded picker for 100+ items.
// -----------------------------------------------------------------------
function PipelineSelect({ repos, value, onChange }) {
  const [open, setOpen] = React.useState(false);
  const [query, setQuery] = React.useState('');
  const [limit, setLimit] = React.useState(60);
  const rootRef = React.useRef(null);

  React.useEffect(() => {
    if (!open) return undefined;
    const onDoc = (e) => { if (rootRef.current && !rootRef.current.contains(e.target)) setOpen(false); };
    const onEsc = (e) => { if (e.key === 'Escape') setOpen(false); };
    document.addEventListener('mousedown', onDoc);
    document.addEventListener('keydown', onEsc);
    return () => { document.removeEventListener('mousedown', onDoc); document.removeEventListener('keydown', onEsc); };
  }, [open]);

  React.useEffect(() => { setLimit(60); }, [query, open]);

  const q = query.trim().toLowerCase();
  const matchedGroups = [];
  let matchCount = 0;
  for (const g of repos) {
    const items = (g.pipelines || []).filter(p =>
      !q || p.name.toLowerCase().includes(q) || (g.repo || '').toLowerCase().includes(q)
    );
    if (items.length) { matchedGroups.push({ repo: g.repo, project: g.project, items }); matchCount += items.length; }
  }

  // Lazy window: cap rendered options at `limit`, grow on scroll.
  let rendered = 0;
  const visibleGroups = [];
  for (const g of matchedGroups) {
    if (rendered >= limit) break;
    const slice = g.items.slice(0, Math.max(0, limit - rendered));
    rendered += slice.length;
    visibleGroups.push({ ...g, items: slice });
  }
  const hasMore = matchCount > rendered;

  const onScroll = (e) => {
    const el = e.currentTarget;
    if (hasMore && el.scrollTop + el.clientHeight >= el.scrollHeight - 48) setLimit(l => l + 60);
  };

  let selectedLabel = 'Select a pipeline';
  for (const g of repos) {
    const hit = (g.pipelines || []).find(p => p.definition_id === value);
    if (hit) { selectedLabel = hit.name; break; }
  }

  return (
    <div className="pipeline-select" ref={rootRef}>
      <span className="inline-select-label">Pipeline</span>
      <button
        type="button"
        className="pipeline-select-button"
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen(o => !o)}
      >
        <span className="pipeline-select-current">{selectedLabel}</span>
        <span className="pipeline-select-caret" aria-hidden="true">▾</span>
      </button>

      {open && (
        <div className="pipeline-select-panel" role="listbox" aria-label="Pipelines">
          <div className="pipeline-select-search">
            <input
              type="search"
              className="form-field"
              placeholder="Search pipelines or repos…"
              value={query}
              onChange={e => setQuery(e.target.value)}
              autoFocus
              aria-label="Search pipelines"
            />
            <span className="pipeline-select-count muted">{matchCount} match{matchCount === 1 ? '' : 'es'}</span>
          </div>

          <div className="pipeline-select-list" onScroll={onScroll}>
            {visibleGroups.length === 0 && (
              <div className="pipeline-select-empty muted">No pipelines match “{query}”.</div>
            )}
            {visibleGroups.map(g => (
              <div className="pipeline-select-group" key={g.project + '::' + g.repo}>
                <div className="pipeline-select-group-head">
                  <span className="pipeline-select-repo">{g.repo}</span>
                  <span className="pipeline-select-proj muted">{g.project}</span>
                </div>
                {g.items.map(p => (
                  <button
                    key={p.definition_id}
                    type="button"
                    role="option"
                    aria-selected={p.definition_id === value}
                    className={'pipeline-select-option' + (p.definition_id === value ? ' active' : '')}
                    onClick={() => { onChange(p.definition_id); setOpen(false); }}
                  >
                    {p.name}
                  </button>
                ))}
              </div>
            ))}
            {hasMore && (
              <button type="button" className="pipeline-select-more" onClick={() => setLimit(l => l + 60)}>
                Show more ({matchCount - rendered} remaining)
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

// -----------------------------------------------------------------------
// usePipelineRuns — run history from /api/history. No fixtures.
// -----------------------------------------------------------------------
const NON_TERMINAL = ['queued', 'inprogress', 'running'];

function usePipelineRuns(pipeline, provider, nonce) {
  const [state, setState] = React.useState({ runs: [], loading: true, error: null });
  // Internal poll tick — bumped while any run is still in flight so the table
  // reflects the run's real status once it finishes in Azure DevOps.
  const [tick, setTick] = React.useState(0);

  React.useEffect(() => {
    if (!pipeline) { setState({ runs: [], loading: false, error: null }); return undefined; }
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured()) { setState({ runs: [], loading: false, error: 'no_api_url' }); return undefined; }
    let cancelled = false;
    // Only show the loading state on first load, not on background polls.
    setState(s => ({ ...s, loading: s.runs.length === 0 }));
    api.history({ pipeline_id: pipeline.id, provider, limit: 200, refresh: true }).then((res) => {
      if (cancelled) return;
      if (!res.ok || !res.data || !Array.isArray(res.data.items)) {
        setState({ runs: [], loading: false, error: res.error || 'bad_payload' });
        return;
      }
      const runs = res.data.items.map(normalizeRunRow)
        .sort((a, b) => String(b.stored_at || '').localeCompare(String(a.stored_at || '')));
      setState({ runs, loading: false, error: null });
    });
    return () => { cancelled = true; };
  }, [pipeline && pipeline.id, provider, nonce, tick]);

  // Keep polling every 6s while any run is Queued / InProgress.
  React.useEffect(() => {
    const inFlight = state.runs.some(r => NON_TERMINAL.includes(String(r.status || '').toLowerCase()));
    if (!inFlight) return undefined;
    const id = setTimeout(() => setTick(t => t + 1), 6000);
    return () => clearTimeout(id);
  }, [state.runs]);

  return state;
}

function normalizeRunRow(row) {
  return {
    id: row.run_id || row.id,
    run_id: row.run_id,
    pipeline: row.pipeline_id,
    region: row.region,
    strategy: (row.decision || row.strategy || 'RUN_NOW').toUpperCase(),
    co2: Number(row.actual_carbon_g || row.co2 || 0),
    baselineCo2: Number(row.baseline_carbon_g || row.baselineCo2 || 0),
    durationMin: row.duration_seconds ? Math.round(row.duration_seconds / 60) : (row.durationMin || 0),
    durationSec: (typeof row.duration_seconds === 'number') ? row.duration_seconds : null,
    status: (row.status || 'pass').toLowerCase().startsWith('succe') ? 'pass'
           : (row.status || 'pass').toLowerCase().startsWith('fail') ? 'fail'
           : (row.status || 'pass').toLowerCase(),
    commit: row.commit_sha || row.commit,
    author: row.author,
    stored_at: row.stored_at,
    // Brief failure reason (shown as a tooltip on a Failed status) + the ADO
    // run URL used as a fallback hint when no explicit reason was recorded.
    failureReason: row.failure_reason || row.error || row.reason || null,
    webUrl: row.web_url || null
  };
}

// A run is "failed" once normalised to 'fail' (or any raw 'failed' label).
function isFailedRun(r) {
  const s = String(r && r.status || '').toLowerCase();
  return s === 'fail' || s === 'failed';
}

// Brief, human-readable failure reason for the Failed-status tooltip.
function failureReasonText(r) {
  if (r && r.failureReason) return r.failureReason;
  if (r && r.webUrl) return 'Run failed — open the run in Azure DevOps for details.';
  return 'Run failed — no further detail was recorded.';
}

function formatRunWhen(r) {
  if (r.stored_at) {
    try { return new Date(r.stored_at).toLocaleString(); } catch (e) { /* fallthrough */ }
  }
  return '—';
}

// Exact seconds when a run is under a minute; minutes otherwise.
function formatDuration(r) {
  const sec = r.durationSec;
  if (sec == null) return r.durationMin ? r.durationMin + ' min' : '—';
  if (sec <= 0) return '—';
  if (sec < 60) return sec + 's';
  return Math.round(sec / 60) + ' min';
}

// Title-case status label + colour class. Maps both raw ADO labels and the
// normalised pass/fail tokens.
const STATUS_MAP = {
  pass: { label: 'Succeeded', cls: 'succeeded' },
  succeeded: { label: 'Succeeded', cls: 'succeeded' },
  fail: { label: 'Failed', cls: 'failed' },
  failed: { label: 'Failed', cls: 'failed' },
  queued: { label: 'Queued', cls: 'queued' },
  inprogress: { label: 'In Progress', cls: 'inprogress' },
  running: { label: 'In Progress', cls: 'inprogress' },
  canceled: { label: 'Cancelled', cls: 'canceled' },
  cancelled: { label: 'Cancelled', cls: 'canceled' }
};

function StatusPill({ status, reason }) {
  const key = String(status || '').toLowerCase();
  const s = STATUS_MAP[key] || { label: (status || '—'), cls: 'queued' };
  const isFail = s.cls === 'failed';
  // Native tooltip on hover; focusable + aria-label so it's keyboard/SR accessible.
  const title = isFail && reason ? reason : undefined;
  return (
    <span
      className={'status-pill ' + s.cls}
      title={title}
      tabIndex={title ? 0 : undefined}
      aria-label={title ? (s.label + ': ' + reason) : undefined}
    >
      <span className="status-dot" aria-hidden="true" />
      {s.label}
    </span>
  );
}

// -----------------------------------------------------------------------
// useCarbonRegions — live region intensities (for recommendation + table).
// -----------------------------------------------------------------------
function useCarbonRegions(provider) {
  const [state, setState] = React.useState({ regions: [], executionRegions: [] });
  React.useEffect(() => {
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured()) return undefined;
    let cancelled = false;
    api.carbon({ provider }).then((res) => {
      if (cancelled || !res.ok || !res.data || !Array.isArray(res.data.regions)) return;
      const seen = Object.create(null);
      const out = [];
      for (const r of res.data.regions) {
        if (!r || !r.code || seen[r.code]) continue;
        seen[r.code] = true;
        const v = r.intensity_gco2_kwh ?? r.grid_intensity_gco2_kwh;
        out.push({ id: r.code, intensity: typeof v === 'number' ? v : null });
      }
      setState({ regions: out, executionRegions: res.data.execution_regions || [] });
    });
    return () => { cancelled = true; };
  }, [provider]);
  return state;
}

function regionIntensity(regions, id) {
  const r = regions.find(x => x.id === id);
  return r ? r.intensity : null;
}

// -----------------------------------------------------------------------
// PipelineRecommendation — home vs cleanest region + real-time decide actions.
// Actions are hidden when the home region IS the recommended region.
// -----------------------------------------------------------------------
function PipelineRecommendation({ pipeline: p, regions, executionRegions, tweaks, provider, latest, onRan }) {
  const { toast, setTweak } = useStore();

  // Only regions with agent capacity can be run in; everything else is
  // reportable but not schedulable.
  const runnable = (executionRegions && executionRegions.length)
    ? regions.filter(r => executionRegions.indexOf(r.id) >= 0)
    : regions;
  const runnableIds = runnable.map(r => r.id);
  const defaultHome = runnableIds[0] || 'uksouth';
  const tweakHome = tweaks.home_region || defaultHome;
  // A home region outside the runnable set can't host a run — fall back.
  const homeId = runnableIds.indexOf(tweakHome) >= 0 ? tweakHome : defaultHome;

  const withIntensity = runnable.filter(r => typeof r.intensity === 'number');
  const sortedClean = [...withIntensity].sort((a, b) => a.intensity - b.intensity);
  const cleanest = sortedClean[0] || null;
  const homeIntensity = regionIntensity(regions, homeId);
  const recommendedId = cleanest ? cleanest.id : null;
  const isOnCleanest = recommendedId && recommendedId === homeId;

  const [action, setAction] = React.useState({ status: 'idle' }); // idle|calling|done|error
  const [rerouteOpen, setRerouteOpen] = React.useState(false);
  const [reroutePick, setReroutePick] = React.useState('');

  // Persist the chosen region as the pipeline's home region — the real
  // allocation. Future decisions/overview use it from then on.
  const allocate = (regionId) => {
    if (regionId && regionId !== homeId) setTweak('home_region', regionId);
  };

  // intent: 'apply' (cleanest) | 'runnow' (stay home) | 'reroute' (chosen region)
  const runDecision = (intent, chosenRegion) => {
    const api = window.greenQaApi;
    if (!api) return;
    const target = intent === 'runnow' ? homeId
                 : intent === 'apply'  ? recommendedId
                 : chosenRegion;
    if (!target) return;

    setAction({ status: 'calling', intent });
    const body = {
      pipeline_id: p.id,
      run_id: 'ui-' + Date.now(),
      provider,
      current_region: homeId,
      // Constrain candidates to the intended target so the decision the
      // backend records is consistent with what the user picked.
      candidate_regions: intent === 'runnow' ? [homeId] : [homeId, target],
      criticality: 'normal',
      pool_mode: intent === 'runnow' ? 'ms_hosted_single_region' : 'self_hosted_multi_region'
    };

    // Savings are derived from the SAME region feed the user sees, so the
    // headline region + percentage always agree (no recommend-A/return-B drift).
    const hi = regionIntensity(regions, homeId);
    const ti = regionIntensity(regions, target);
    const savings = (hi != null && ti != null) ? Math.max(0, hi - ti) : null;
    const savingsPct = (savings != null && hi) ? (savings / hi) * 100 : null;
    const label = (intent === 'runnow' || target === homeId) ? 'RUN_NOW' : 'RELOCATE';

    api.decide(body).then((res) => {
      if (res.ok && res.data) {
        if (intent !== 'runnow') allocate(target);
        setAction({
          status: 'done', intent, target, label,
          homeId, hi, ti, savings, savingsPct,
          allocated: intent !== 'runnow' && target !== homeId ? target : null,
          response: res.data
        });
        setRerouteOpen(false);
        toast({
          kind: 'success',
          title: 'Decision: ' + label,
          message: p.name + ' → ' + target,
          detail: savings != null
            ? 'Projected saving ' + savings.toFixed(1) + ' g (' + (savingsPct || 0).toFixed(0) + '%)'
              + (intent !== 'runnow' && target !== homeId ? ' · home region set to ' + target : '')
            : (res.data.reasoning || '')
        });
      } else {
        setAction({ status: 'error', intent, error: res.error || 'decision_failed' });
        toast({ kind: 'error', title: 'Decision failed', message: res.error || 'The /api/decide call failed.' });
      }
    });
  };

  // Run Now triggers the ACTUAL pipeline run in the current home region
  // (which Apply/Re-route may have just updated), then logs it to Run History.
  const runNow = () => {
    const api = window.greenQaApi;
    if (!api) return;
    const region = homeId;
    setAction({ status: 'calling', intent: 'runnow' });
    const decideBody = {
      pipeline_id: p.id, run_id: 'ui-' + Date.now(), provider,
      current_region: region, candidate_regions: [region],
      criticality: 'normal', pool_mode: 'ms_hosted_single_region'
    };
    api.decide(decideBody)
      .then(dres => {
        const decisionId = (dres.ok && dres.data && dres.data.decision_id) || undefined;
        return api.adoRun({
          pipeline_id: p.id, project: p.project, region,
          baseline_region: region, decision: 'RUN_NOW',
          decision_id: decisionId, provider, criticality: 'normal'
        });
      })
      .then(res => {
        const d = (res && res.data) || {};
        const triggered = !!d.triggered;
        setAction({ status: 'ran', intent: 'runnow', target: region, triggered, run: d });
        if (onRan) onRan(); // refresh Run History (the run is logged either way)
        toast({
          kind: triggered ? 'success' : 'error',
          title: triggered ? 'Pipeline triggered' : 'Trigger failed',
          message: p.name + ' → ' + region + (d.run_id ? ' · run ' + d.run_id : ''),
          detail: triggered
            ? 'Queued in Azure DevOps · logged to Run History'
            : (d.error || (res && res.error) || 'ADO trigger failed')
        });
      });
  };

  const intentLabel = { runnow: 'Run Now', apply: 'Apply Recommendation', reroute: 'Re-route' };
  const busy = action.status === 'calling';

  return (
    <div className="pipe-drill" style={{ marginBottom: 'var(--s-5)' }}>
      <div className="pipe-summary-head">
        <div>
          <div className="pipe-name" style={{ fontSize: 'var(--t-18)' }}>{p.name}</div>
          <div className="muted">
            <code>{p.repo}</code> · {p.project}
            {latest ? ' · latest run ' + formatRunWhen(latest) : ' · no runs yet'}
          </div>
        </div>
      </div>

      <div className="pipe-drill-grid">
        <div className="pipe-drill-rec">
          <h3 className="pipe-drill-h">Recommendation</h3>

          {runnable.length === 0 ? (
            <p className="muted">Loading region intensities…</p>
          ) : (
            <>
              <div className="pipe-drill-route">
                <div>
                  <div className="pipe-drill-route-label">Home region</div>
                  <div className="pipe-drill-route-region">{homeId}</div>
                  <div className="muted">{homeIntensity != null ? homeIntensity + ' gCO₂/kWh' : '—'}</div>
                </div>
                <div className="pipe-drill-route-arrow" aria-hidden="true">→</div>
                <div>
                  <div className="pipe-drill-route-label">Recommended</div>
                  <div className="pipe-drill-route-region good">{recommendedId || '—'}</div>
                  <div className="muted">{cleanest && cleanest.intensity != null ? cleanest.intensity + ' gCO₂/kWh' : '—'}</div>
                </div>
              </div>

              {isOnCleanest ? (
                <p className="pipe-drill-saving" role="status">
                  ✓ Home region is already the cleanest available — no re-routing needed.
                </p>
              ) : (
                homeIntensity != null && cleanest && cleanest.intensity != null && (
                  <p className="pipe-drill-saving">
                    Routing to <strong>{recommendedId}</strong> could cut grid intensity by{' '}
                    <strong>{Math.round((1 - cleanest.intensity / homeIntensity) * 100)}%</strong>.
                  </p>
                )
              )}

              {/* Run Now is ALWAYS available; Apply only when a cleaner region exists. */}
              <div className="actions">
                {!isOnCleanest && (
                  <button className="btn" disabled={busy} onClick={() => runDecision('apply')}>
                    {busy && action.intent === 'apply' ? 'Allocating…' : 'Apply Recommendation'}
                  </button>
                )}
                <button className="btn secondary" disabled={busy} onClick={runNow}>
                  {busy && action.intent === 'runnow' ? 'Triggering…' : 'Run Now'}
                </button>
                <button className="btn secondary" disabled={busy} onClick={() => setRerouteOpen(o => !o)}>
                  Re-route…
                </button>
              </div>

              <p className="muted" style={{ fontSize: 'var(--t-12)', marginTop: 'var(--s-2)' }}>
                <strong>Apply Recommendation</strong> sets the cleanest region as this pipeline's home region ·{' '}
                <strong>Run Now</strong> keeps the current home region ·{' '}
                <strong>Re-route</strong> lets you allocate any region you choose.
              </p>

              {runnableIds.length > 0 && (
                <p className="muted" style={{ fontSize: 'var(--t-12)' }}>
                  Runnable regions: {runnableIds.join(' · ')}. Carbon is reported for all regions,
                  but only these have agent capacity.
                </p>
              )}

              {rerouteOpen && (
                <RerouteChooser
                  regions={sortedClean}
                  homeId={homeId}
                  value={reroutePick}
                  onChange={setReroutePick}
                  busy={busy}
                  onConfirm={() => reroutePick && runDecision('reroute', reroutePick)}
                  onCancel={() => setRerouteOpen(false)}
                />
              )}

              <ActionResult action={action} intentLabel={intentLabel} />
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// Manual region picker for Re-route — relocate to ANY region you select.
function RerouteChooser({ regions, homeId, value, onChange, busy, onConfirm, onCancel }) {
  return (
    <div className="reroute-chooser" role="group" aria-label="Re-route to a region">
      <label className="reroute-chooser-label" htmlFor="reroute-region">Relocate this pipeline to</label>
      <select
        id="reroute-region"
        className="form-field"
        value={value}
        onChange={e => onChange(e.target.value)}
      >
        <option value="">Select a region…</option>
        {regions.map(r => (
          <option key={r.id} value={r.id} disabled={r.id === homeId}>
            {r.id}{typeof r.intensity === 'number' ? ' · ' + r.intensity + ' gCO₂/kWh' : ''}{r.id === homeId ? ' (current home)' : ''}
          </option>
        ))}
      </select>
      <button className="btn" disabled={busy || !value} onClick={onConfirm}>
        {busy ? 'Allocating…' : 'Relocate & set home'}
      </button>
      <button className="btn ghost" disabled={busy} onClick={onCancel}>Cancel</button>
    </div>
  );
}

// Real-time execution status + raw API response for the last decide action.
function ActionResult({ action, intentLabel }) {
  if (action.status === 'idle') return null;
  if (action.status === 'calling') {
    return (
      <div className="action-result calling" role="status">
        <span className="action-spinner" aria-hidden="true" /> Calling <code>/api/decide</code> for <strong>{intentLabel[action.intent]}</strong>…
      </div>
    );
  }
  if (action.status === 'error') {
    return (
      <div className="action-result error" role="alert">
        <strong>{intentLabel[action.intent]} failed.</strong> {action.error}
      </div>
    );
  }
  // A real pipeline trigger (Run Now).
  if (action.status === 'ran') {
    const r = action.run || {};
    return (
      <div className={'action-result ' + (action.triggered ? 'done' : 'error')} role="status">
        <div className="action-result-head">
          <span className={'ccd-tag ' + (action.triggered ? 'green' : '')}>
            {action.triggered ? 'TRIGGERED' : 'TRIGGER FAILED'}
          </span>
          <strong>Run Now</strong> · region <code>{action.target || '—'}</code>
        </div>
        <ul className="action-result-list">
          <li><span>Run ID</span><code>{r.run_id || '—'}</code></li>
          {r.target_region_sent && <li><span>Region sent to ADO</span><code>{action.target}</code></li>}
          <li><span>Logged to Run History</span><strong>{r.stored ? 'yes' : 'no'}</strong></li>
          {r.url && <li><span>ADO run</span><a href={r.url} target="_blank" rel="noopener noreferrer">open in Azure DevOps ↗</a></li>}
          {!action.triggered && r.error && <li><span>Error</span><span className="muted">{r.error}</span></li>}
        </ul>
      </div>
    );
  }
  const d = action.response || {};
  return (
    <div className="action-result done" role="status">
      <div className="action-result-head">
        <span className="ccd-tag green">{action.label}</span>
        <strong>{intentLabel[action.intent]}</strong> · selected region <code>{action.target || '—'}</code>
      </div>
      <ul className="action-result-list">
        <li><span>Decision ID</span><code>{(d.decision_id || '').slice(0, 8) || '—'}</code></li>
        <li><span>Home → Selected</span><code>{action.homeId} → {action.target}</code></li>
        <li><span>Intensity</span><code>{(action.hi != null ? action.hi : '—')} → {(action.ti != null ? action.ti : '—')} gCO₂/kWh</code></li>
        <li><span>Saving</span><strong>{action.savings != null ? action.savings.toFixed(1) + ' g (' + (action.savingsPct || 0).toFixed(0) + '%)' : '—'}</strong></li>
        {action.allocated && <li><span>Home region</span><strong>set to {action.allocated}</strong></li>}
        {d.defer_until_iso && <li><span>Defer until</span><code>{d.defer_until_iso}</code></li>}
      </ul>
      {d.reasoning && <p className="muted action-result-reason">{d.reasoning}</p>}
    </div>
  );
}

// -----------------------------------------------------------------------
// Pagination — GOV.UK-style Previous / page numbers / Next.
// -----------------------------------------------------------------------
function Pagination({ currentPage, totalPages, totalItems, pageSize, start, onChange }) {
  const pages = [];
  const window = 2;
  pages.push(1);
  for (let p = Math.max(2, currentPage - window); p <= Math.min(totalPages - 1, currentPage + window); p++) {
    pages.push(p);
  }
  if (totalPages > 1) pages.push(totalPages);
  const display = [];
  let last = 0;
  for (const p of [...new Set(pages)].sort((a, b) => a - b)) {
    if (last && p - last > 1) display.push('…');
    display.push(p);
    last = p;
  }

  const end = Math.min(start + pageSize, totalItems);

  return (
    <nav className="pagination" aria-label="Run history pagination">
      <button type="button" className="pagination-btn" onClick={() => onChange(currentPage - 1)}
        disabled={currentPage === 1} aria-label="Previous page">← Previous</button>
      <ul className="pagination-pages" role="list">
        {display.map((p, i) => (
          <li key={i}>
            {p === '…' ? (
              <span className="pagination-ellipsis" aria-hidden="true">…</span>
            ) : (
              <button type="button"
                className={'pagination-page' + (p === currentPage ? ' active' : '')}
                onClick={() => onChange(p)}
                aria-current={p === currentPage ? 'page' : undefined}
                aria-label={'Page ' + p}>{p}</button>
            )}
          </li>
        ))}
      </ul>
      <button type="button" className="pagination-btn" onClick={() => onChange(currentPage + 1)}
        disabled={currentPage === totalPages} aria-label="Next page">Next →</button>
      <span className="pagination-summary muted">Showing {start + 1}–{end} of {totalItems}</span>
    </nav>
  );
}

// =======================================================================
// IntensityCell — region code + heat dot + intensity, in one compact cell.
// =======================================================================
function IntensityCell({ region, intensity }) {
  if (intensity == null) return <span className="muted"><code className="intensity-cell-region">{region || '—'}</code></span>;
  const bucket =
    intensity < 100 ? 'clean' :
    intensity < 200 ? 'moderate' :
    intensity < 350 ? 'high' : 'dirty';
  return (
    <span className={'intensity-cell ' + bucket}
          title={'Grid carbon intensity · ' + bucket + ' (' + intensity + ' gCO₂/kWh)'}>
      <span className="intensity-cell-dot" aria-hidden="true" />
      <code className="intensity-cell-region">{region}</code>
      <span className="intensity-cell-value">{intensity}<small> g/kWh</small></span>
    </span>
  );
}

window.PipelinesTable = PipelinesTable;
window.IntensityCell  = IntensityCell;
