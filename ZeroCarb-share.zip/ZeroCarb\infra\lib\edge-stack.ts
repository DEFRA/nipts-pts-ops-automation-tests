import * as cdk from 'aws-cdk-lib';
import * as acm from 'aws-cdk-lib/aws-certificatemanager';
import * as route53 from 'aws-cdk-lib/aws-route53';
import * as wafv2 from 'aws-cdk-lib/aws-wafv2';
import { Construct } from 'constructs';
import type { EnvConfig } from './config';

/** CloudFront-scoped resources must live in us-east-1: the WAF web ACL and (optionally) the TLS certificate. */
export class EdgeStack extends cdk.Stack {
  readonly webAcl: wafv2.CfnWebACL;
  readonly certificate?: acm.ICertificate;

  constructor(scope: Construct, id: string, cfg: EnvConfig, props: cdk.StackProps) {
    super(scope, id, props);

    const rule = (name: string, priority: number, group: string, vendor = 'AWS', overrides: wafv2.CfnWebACL.RuleActionOverrideProperty[] = []): wafv2.CfnWebACL.RuleProperty => ({
      name,
      priority,
      overrideAction: { none: {} },
      statement: { managedRuleGroupStatement: { vendorName: vendor, name: group, ruleActionOverrides: overrides } },
      visibilityConfig: { sampledRequestsEnabled: true, cloudWatchMetricsEnabled: true, metricName: name },
    });

    this.webAcl = new wafv2.CfnWebACL(this, 'WebAcl', {
      name: `zerocarb-${cfg.name}`,
      scope: 'CLOUDFRONT',
      defaultAction: { allow: {} },
      visibilityConfig: { sampledRequestsEnabled: true, cloudWatchMetricsEnabled: true, metricName: `zerocarb-${cfg.name}` },
      rules: [
        {
          name: 'RateLimitPerIp',
          priority: 0,
          action: { block: {} },
          statement: { rateBasedStatement: { limit: cfg.wafRateLimit, aggregateKeyType: 'IP' } },
          visibilityConfig: { sampledRequestsEnabled: true, cloudWatchMetricsEnabled: true, metricName: 'RateLimitPerIp' },
        },
        rule('IpReputation', 1, 'AWSManagedRulesAmazonIpReputationList'),
        // SizeRestrictions_BODY is relaxed to count: ADO service-hook payloads can exceed the 8 KB default.
        rule('CommonRuleSet', 2, 'AWSManagedRulesCommonRuleSet', 'AWS', [{ name: 'SizeRestrictions_BODY', actionToUse: { count: {} } }]),
        rule('KnownBadInputs', 3, 'AWSManagedRulesKnownBadInputsRuleSet'),
      ],
    });

    if (cfg.domain) {
      const zone = route53.HostedZone.fromHostedZoneAttributes(this, 'Zone', {
        hostedZoneId: cfg.domain.hostedZoneId,
        zoneName: cfg.domain.hostedZoneName,
      });
      this.certificate = new acm.Certificate(this, 'Certificate', {
        domainName: cfg.domain.name,
        validation: acm.CertificateValidation.fromDns(zone),
      });
    }

    cdk.Tags.of(this).add('Tier', 'edge');
  }
}
