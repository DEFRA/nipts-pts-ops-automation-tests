export interface ServiceBudget {
  name: string;
  budget_gco2_per_run?: number | null;
  budget_gco2_per_transaction?: number | null;
  warn_at_percent: number;
}

export interface BudgetCheckResult {
  status: 'pass' | 'warn' | 'fail' | 'no_budget';
  passed: boolean;
  usage_percent: number;
  message: string;
  actual_gco2: number;
  budget_gco2: number | null;
  service: string;
  budget_name: string;
}

const fixed = (n: number, d: number) => n.toFixed(d);

/** Per-transaction limits apply when transaction_count > 0, otherwise per-run. */
export function checkBudget(
  actualGco2: number,
  transactionCount = 0,
  budget: ServiceBudget | null = null,
  service = 'unknown',
): BudgetCheckResult {
  if (!budget) {
    return {
      status: 'no_budget', passed: true, usage_percent: 0,
      message: 'No budget configured — recording only.',
      actual_gco2: actualGco2, budget_gco2: null, service, budget_name: 'none',
    };
  }

  const perTx = budget.budget_gco2_per_transaction ?? null;
  const perRun = budget.budget_gco2_per_run ?? null;
  let budgetG: number;
  let scope: string;
  if (transactionCount > 0 && perTx !== null) {
    budgetG = perTx * transactionCount;
    scope = `${transactionCount} transactions`;
  } else if (perRun !== null) {
    budgetG = perRun;
    scope = 'per run';
  } else if (perTx !== null) {
    budgetG = perTx;
    scope = 'per transaction';
  } else {
    return {
      status: 'no_budget', passed: true, usage_percent: 0,
      message: `Budget '${budget.name}' has no limits set.`,
      actual_gco2: actualGco2, budget_gco2: null, service, budget_name: budget.name,
    };
  }

  const usagePct = budgetG > 0 ? (actualGco2 / budgetG) * 100 : 0;
  let status: BudgetCheckResult['status'];
  let passed: boolean;
  let message: string;
  if (usagePct >= 100) {
    status = 'fail'; passed = false;
    message = `Budget breached: ${fixed(actualGco2, 2)}g vs ${fixed(budgetG, 2)}g (${scope})`;
  } else if (usagePct >= budget.warn_at_percent) {
    status = 'warn'; passed = true;
    message = `Budget warning: ${fixed(usagePct, 1)}% of ${fixed(budgetG, 2)}g (${scope})`;
  } else {
    status = 'pass'; passed = true;
    message = `Within budget: ${fixed(usagePct, 1)}% of ${fixed(budgetG, 2)}g (${scope})`;
  }

  return {
    status, passed, usage_percent: Math.round(usagePct * 100) / 100, message,
    actual_gco2: actualGco2, budget_gco2: budgetG, service, budget_name: budget.name,
  };
}
