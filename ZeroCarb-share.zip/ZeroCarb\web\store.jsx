/* global React */
// =======================================================================
// Store — global UI state shared across components
//   - tweaks (passed in)
//   - pipelines (live, fetched repo-wise from Azure DevOps; NO fixtures)
//   - repos (pipelines grouped by repository)
//   - toasts queue
//   - modal (single)
//   - Azure DevOps connection state (real, backed by /api/ado/status)
//
// Clean slate: on first launch nothing is preloaded. The utility stays
// locked until a successful Azure DevOps connection, after which pipelines
// are fetched from /api/ado/pipelines. There is no mock/fixture data here.
// =======================================================================

const StoreContext = React.createContext(null);

function StoreProvider({ tweaks, setTweak, children }) {
  const api = (typeof window !== 'undefined') && window.greenQaApi;

  // Live pipelines (flat) + repo-wise grouping. Empty until connected.
  const [pipelines, setPipelines] = React.useState([]);
  const [repos, setRepos] = React.useState([]);
  const [pipelinesState, setPipelinesState] = React.useState({ loading: false, error: null });

  const mutatePipeline = React.useCallback((id, patch) => {
    setPipelines(prev =>
      prev.map(p => p.id === id ? { ...p, ...(typeof patch === 'function' ? patch(p) : patch) } : p)
    );
  }, []);

  // Toasts queue
  const [toasts, setToasts] = React.useState([]);
  const toast = React.useCallback((opts) => {
    const id = 't' + (Date.now() + Math.random());
    const t = typeof opts === 'string'
      ? { id, kind: 'info', message: opts }
      : { id, kind: 'info', ...opts };
    setToasts(prev => [...prev, t]);
    const ttl = t.ttl ?? 4800;
    if (ttl > 0) {
      setTimeout(() => setToasts(prev => prev.filter(x => x.id !== id)), ttl);
    }
    return id;
  }, []);
  const dismissToast = React.useCallback((id) => {
    setToasts(prev => prev.filter(x => x.id !== id));
  }, []);

  // Modal (single)
  const [modal, setModal] = React.useState(null);
  const openModal = React.useCallback((node) => setModal(() => node), []);
  const closeModal = React.useCallback(() => setModal(null), []);

  // Azure DevOps connection state (real). `bootstrapping` is true until the
  // initial /api/ado/status probe resolves, so the gate doesn't flash.
  const [azure, setAzure] = React.useState({
    connected: false,
    organization: null,
    orgUrl: null,
    project: null,
    validatedAt: null,
    pipelines: 0,
    bootstrapping: true
  });

  // AWS CodePipeline connection (probed from /api/aws/status; keys live server-side).
  const [aws, setAws] = React.useState({
    connected: false, region: null, accountId: null, validatedAt: null, bootstrapping: true
  });
  const setAwsConnected = React.useCallback((info) => {
    setAws({
      connected: true,
      region: info.region || null,
      accountId: info.account_id || null,
      validatedAt: info.validated_at || null,
      bootstrapping: false
    });
  }, []);
  const disconnectAws = React.useCallback(() => {
    if (api && api.awsDisconnect) api.awsDisconnect();
    setAws({ connected: false, region: null, accountId: null, validatedAt: null, bootstrapping: false });
  }, [api]);
  React.useEffect(() => {
    if (!api || !api.isConfigured()) {
      setAws(prev => ({ ...prev, bootstrapping: false }));
      return;
    }
    let cancelled = false;
    api.awsStatus().then((res) => {
      if (cancelled) return;
      if (res.ok && res.data && res.data.connected) setAwsConnected(res.data);
      else setAws(prev => ({ ...prev, bootstrapping: false }));
    });
    return () => { cancelled = true; };
  }, [api, setAwsConnected]);

  // Fetch the repo-wise pipeline catalogue from ADO and flatten it.
  const loadPipelines = React.useCallback(() => {
    if (!api) return Promise.resolve();
    setPipelinesState({ loading: true, error: null });
    return api.adoPipelines().then((res) => {
      if (!res.ok || !res.data || !Array.isArray(res.data.repos)) {
        setPipelinesState({ loading: false, error: res.error || 'failed_to_load' });
        setPipelines([]); setRepos([]);
        return;
      }
      const grouped = res.data.repos;
      const flat = [];
      for (const g of grouped) {
        for (const p of (g.pipelines || [])) {
          flat.push({
            id: p.definition_id,
            definitionId: p.definition_id,
            name: p.name,
            repo: p.repo,
            project: p.project,
            webUrl: p.web_url
          });
        }
      }
      setRepos(grouped);
      setPipelines(flat);
      setPipelinesState({ loading: false, error: null });
      setAzure(prev => ({ ...prev, pipelines: flat.length }));
    });
  }, [api]);

  // Mark the connection live (called by the Azure Configuration panel on a
  // successful /api/ado/connect) and immediately pull the pipeline catalogue.
  const setConnected = React.useCallback((info) => {
    setAzure({
      connected: true,
      organization: info.organization || null,
      orgUrl: info.org_url || info.orgUrl || null,
      project: info.project || null,
      validatedAt: info.validated_at || info.validatedAt || null,
      pipelines: 0,
      bootstrapping: false
    });
    loadPipelines();
  }, [loadPipelines]);

  const disconnectAzure = React.useCallback(() => {
    if (api && api.adoDisconnect) api.adoDisconnect();
    setAzure({ connected: false, organization: null, orgUrl: null, project: null, validatedAt: null, pipelines: 0, bootstrapping: false });
    setPipelines([]); setRepos([]); setPipelinesState({ loading: false, error: null });
  }, [api]);

  // On first load, probe the backend for an existing connection (PAT lives
  // server-side, so a prior session can resume without re-entering it).
  React.useEffect(() => {
    if (!api || !api.isConfigured()) {
      setAzure(prev => ({ ...prev, bootstrapping: false }));
      return;
    }
    let cancelled = false;
    api.adoStatus().then((res) => {
      if (cancelled) return;
      if (res.ok && res.data && res.data.connected) {
        setAzure({
          connected: true,
          organization: res.data.organization || null,
          orgUrl: res.data.org_url || null,
          project: res.data.project || null,
          validatedAt: res.data.validated_at || null,
          pipelines: 0,
          bootstrapping: false
        });
        loadPipelines();
      } else {
        setAzure(prev => ({ ...prev, bootstrapping: false }));
      }
    });
    return () => { cancelled = true; };
  }, [api, loadPipelines]);

  const value = {
    tweaks, setTweak,
    pipelines, repos, pipelinesState, loadPipelines, mutatePipeline,
    toasts, toast, dismissToast,
    modal, openModal, closeModal,
    azure, setAzure, setConnected, disconnectAzure,
    aws, setAwsConnected, disconnectAws
  };

  return (
    <StoreContext.Provider value={value}>
      {children}
      <ToastTray toasts={toasts} onDismiss={dismissToast} />
      <ModalHost node={modal} />
    </StoreContext.Provider>
  );
}

function useStore() {
  const ctx = React.useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside <StoreProvider>');
  return ctx;
}

// ---- Toast tray ----
function ToastTray({ toasts, onDismiss }) {
  return (
    <div className="toast-tray" aria-live="polite" aria-atomic="true">
      {toasts.map(t => (
        <div key={t.id} className={'toast ' + (t.kind || 'info')} role="status">
          <span className="toast-bar" aria-hidden="true" />
          <div className="toast-body">
            {t.title && <div className="toast-title">{t.title}</div>}
            <div className="toast-msg">{t.message}</div>
            {t.detail && <div className="toast-detail">{t.detail}</div>}
          </div>
          <button className="toast-close" onClick={() => onDismiss(t.id)} aria-label="Dismiss">×</button>
        </div>
      ))}
    </div>
  );
}

// ---- Modal host ----
function ModalHost({ node }) {
  React.useEffect(() => {
    if (!node) return;
    const onKey = (e) => { if (e.key === 'Escape') node.onClose && node.onClose(); };
    window.addEventListener('keydown', onKey);
    document.body.style.overflow = 'hidden';
    return () => {
      window.removeEventListener('keydown', onKey);
      document.body.style.overflow = '';
    };
  }, [node]);
  if (!node) return null;
  return (
    <div className="modal-backdrop" onClick={(e) => {
      if (e.target === e.currentTarget) node.onClose && node.onClose();
    }}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title">
        {node.element}
      </div>
    </div>
  );
}

// ---- Helpers exposed to other modules ----
window.StoreContext = StoreContext;
window.StoreProvider = StoreProvider;
window.useStore = useStore;

// Download a CSV blob via an off-DOM <a> click.
window.downloadCSV = function downloadCSV(filename, rows) {
  const escape = (v) => {
    if (v == null) return '';
    const s = String(v);
    return /[",\n\r]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
  };
  const csv = rows.map(r => r.map(escape).join(',')).join('\r\n');
  const blob = new Blob(["\uFEFF" + csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = filename;
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1200);
};
