# Setup & Configuration

How to configure the platform locally and in Azure. Read this before
[`DEPLOYMENT_AZURE.md`](./DEPLOYMENT_AZURE.md).

---

## 1 · Local development

### 1.1 · Prereqs

- Python 3.11
- `azure-functions-core-tools@4` (for running Functions locally)
- Optional: Docker, for `docker-compose.yml`

### 1.2 · Clone and bootstrap

```bash
git clone <repo>
cd green-qa-platform

# Install runtime deps (used by the library + Lambdas)
pip install azure-functions azure-cosmos azure-identity azure-keyvault-secrets

# Install test deps
pip install -r requirements-test.txt
```

### 1.3 · Local environment file

```bash
cp config/.env.example config/.env
```

Open `config/.env` and fill in **only** the values you need for what you're
running:

| Variable | Required for | Notes |
|---|---|---|
| `ELECTRICITYMAPS_TOKEN` | Live carbon outside GB | Free key from electricitymaps.com. Without it, GB uses ESO and others fall through to Ember / synthetic |
| `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` | AWS deployment path only | Skip for pure Azure path |
| `CODEPIPELINE_ENABLED` | AWS CodePipeline triggering | Default `false` for safety |
| `AUTO_TRIGGER_RUN_NOW` | Auto-execute on `RUN_NOW_OPTIMAL` | Recommended `false` until you trust the gate |
| `MIN_SAVINGS_DEFER` | Threshold % to honour `WAIT_FOR_WINDOW` | Default 15 |
| `MAX_DEFER_HOURS` | Cap on time-shift | Default 24, reduce to 4 for time-sensitive teams |
| `MAIZX_W_*` | Override scheduler weights | Sum must = 1.0; defaults are paper values (0.40/0.30/0.20/0.10) |

**Never commit `.env`.** It's already in `.gitignore`.

### 1.4 · Run the local server

```bash
python local_server.py
# → http://localhost:8080
# Serves dashboard/public/ and proxies the API endpoints
```

### 1.5 · Run the Functions app locally

```bash
cd azure/functions
cp local.settings.json.example local.settings.json
# Edit local.settings.json — see §2 below
func start
# → http://localhost:7071/api/{decide,calculate,carbon,...}
```

### 1.6 · End-to-end Python demo (no cloud needed)

```bash
python pipelines/demo_runner.py
# Runs through every component:
#   eu_carbon_api → maizx_scorer → region_selector → sci_calculator → carbon_budget
# Prints a step-by-step trace. Use this to confirm the lib works before deploying.
```

### 1.7 · PowerShell demo (no Python required)

```powershell
powershell -ExecutionPolicy Bypass -File pipelines/Run-GreenQADemo.ps1
```

Useful for showing the carbon-aware decision logic to Windows-only ops
teams.

---

## 2 · `azure/functions/local.settings.json`

This file holds the env vars that the Functions runtime reads when running
locally with `func start`. It is **never deployed** — production reads from
Key Vault and the Function App's app settings.

Minimum local config:

```json
{
  "IsEncrypted": false,
  "Values": {
    "AzureWebJobsStorage": "UseDevelopmentStorage=true",
    "FUNCTIONS_WORKER_RUNTIME": "python",
    "FUNCTIONS_EXTENSION_VERSION": "~4",

    "ELECTRICITYMAPS_TOKEN":  "<your-key-here-or-empty>",
    "ADO_PAT":                "<for ado_client.py if you're testing pipeline triggers>",
    "ADO_ORG":                "your-ado-org",
    "ADO_PROJECT":            "your-ado-project",

    "COSMOS_ENDPOINT":        "https://localhost:8081",
    "COSMOS_KEY":             "C2y6yDjf5/R+ob0N8A7Cgv30VRDJIWEHLM+4QDU5DE2nQ9nDuVTqobD4b8mGGyPMbIZnqyMsEcaGQy67XIw/Jw==",
    "COSMOS_DB":              "green_qa",

    "LOG_LEVEL":              "INFO"
  }
}
```

The Cosmos values above are the Microsoft-published well-known dev
credentials for the Cosmos DB emulator — don't use them in prod.

For prod, the Bicep template wires these settings directly onto the Function
App from Key Vault references:

```
COSMOS_ENDPOINT     = <auto>
COSMOS_DB           = green_qa
KEY_VAULT_NAME      = kv-greenqa-prod-…
ELECTRICITYMAPS_TOKEN = @Microsoft.KeyVault(SecretUri=https://…/secrets/electricitymaps-token/)
ADO_PAT               = @Microsoft.KeyVault(SecretUri=https://…/secrets/ado-pat/)
```

---

## 3 · Per-pipeline configuration (`.green-qa.yml`)

Each consuming repository drops this file at its root. The carbon gate reads
it to decide what budgets apply and how aggressively to time-/space-shift.

```yaml
green_qa:
  service: auth-service
  home_region: eu-west-2          # AWS region or Azure region id
  criticality: critical           # critical | high | normal | low
  max_wait_hours: 4               # cap on TIME_SHIFT for this pipeline

  budgets:
    - name: default
      budget_gco2_per_transaction: 0.30
      budget_gco2_per_run: 50.0
      warn_at_percent: 80
    - name: regression
      test_suite: regression
      budget_gco2_per_run: 120.0

  regions:
    allowed: [eu-west-2, eu-west-1, eu-north-1]   # data-residency / latency constraint
    blocked: [eu-central-1]                       # explicit deny (overrides allowed)

  notifications:
    slack_channel: "#payments-build"
    email_on_breach: payments-lead@example.com
```

| Field | Default | Notes |
|---|---|---|
| `service` | required | Stable id; used as Cosmos partition key |
| `home_region` | required | Where the pipeline runs today |
| `criticality` | `normal` | `critical` disables time-shifting entirely |
| `max_wait_hours` | 4 | Hard cap for `WAIT_FOR_WINDOW` |
| `budgets[*].warn_at_percent` | 80 | Sends warn-level alert at this fraction of budget |
| `regions.allowed` | all EU | Useful for GDPR; restricts `SPACE_SHIFT` candidates |
| `notifications.*` | unset | If unset, falls back to the per-team default from `infrastructure/azure/notifications.bicep` (planned) |

The YAML schema is validated on each gate call; malformed configs fail-loud
with the line number.

---

## 4 · MAIZX weight tuning

The scheduling penalty function is:

```
MAIZX_score = w1·CFP + w2·FCFP + w3·CP_RATIO + w4·SCHEDULE
```

Paper defaults (Lower = greener):

| Weight | Env var | Default | What it captures |
|---|---|---|---|
| w1 | `MAIZX_W_CFP` | 0.40 | Current carbon footprint (this region, right now) |
| w2 | `MAIZX_W_FCFP` | 0.30 | Forecasted carbon footprint (next 4 h average) |
| w3 | `MAIZX_W_CP_RATIO` | 0.20 | Compute-efficiency penalty (perf/watt) |
| w4 | `MAIZX_W_SCHEDULE` | 0.10 | Schedule penalty (cost of waiting) |

**Sum must equal 1.0.** Validated at startup; the Function will refuse to
boot with a malformed sum.

When to tune:

- Forecast is unreliable in your region (e.g. UK on a calm day) → reduce w2 to 0.20, raise w1 to 0.50
- Latency-sensitive workload that can't tolerate `SPACE_SHIFT` to far regions → raise w3 to 0.30
- Very long deadlines (overnight batch) → raise w4 to 0.20

---

## 5 · Tunable thresholds (Function App settings)

These are read at boot from app settings; change them via
`az functionapp config appsettings set`.

| Setting | Default | What it controls |
|---|---|---|
| `EFFICIENCY_THRESHOLD_G_KWH` | 120 | A region is "efficient" if its intensity is below this — step 1 of the 4-step gate |
| `MIN_SAVINGS_PCT_FOR_SPACE_SHIFT` | 15 | Step 2 won't reroute unless saving exceeds this |
| `MIN_SAVINGS_PCT_FOR_TIME_SHIFT` | 15 | Step 3 won't delay unless saving exceeds this |
| `FORECAST_CONFIDENCE_THRESHOLD` | 0.7 | Step 3 refuses delay if forecast confidence < this |
| `CARBON_CACHE_TTL_S` | 300 | In-memory cache TTL for upstream API responses |
| `CIRCUIT_BREAKER_THRESHOLD` | 5 | Open the breaker after this many consecutive upstream failures |
| `CIRCUIT_BREAKER_COOLDOWN_S` | 600 | Hold the breaker open this long before retrying |

---

## 6 · Dashboard tweaks

These persist in `localStorage` per user and **do not** require backend
config. They live in the in-page "Tweaks" panel:

| Tweak | Default | Effect |
|---|---|---|
| Theme | `govuk` | UI palette (`govuk`, `contrast`, `azure-tinted`) |
| Density | `comfortable` | Vertical rhythm (`comfortable` or `compact`) |
| Time range | `30d` | Default range for the ledger + history sparklines |
| Cloud | `azure` | Filters pipeline view to one provider |
| Layout | `manager` | Eng-manager view vs Operator view |
| Show $ cost | `true` | Toggle dollar columns alongside carbon |
| Home region | `uksouth` | Used by the "fallback region" calculation in the regions panel |

Add or remove tweaks via `app.jsx` → `TWEAK_DEFAULTS` and the `<TweaksPanel>`
section.

---

## 7 · Common config mistakes

| Symptom | Cause | Fix |
|---|---|---|
| `/api/decide` always returns `RUN_NOW_DEFAULT` for every region | MAIZX weights don't sum to 1.0 — fallback to defaults | Check `*W_*` env vars |
| Carbon intensity stuck at the same number for hours | `CARBON_CACHE_TTL_S` set too high | Reduce to 300 (5 min) |
| `WAIT_FOR_WINDOW` never chosen even when forecast is great | `FORECAST_CONFIDENCE_THRESHOLD` too high | Lower to 0.5 for low-stakes pipelines |
| Pipeline budgets never trip | `budget_gco2_per_run` set on a per-txn pipeline | Use `budget_gco2_per_transaction` and pass `transaction_count` on `/store_result` |
| Function App returns 500 on every request | Missing app setting referenced by code | Tail `az functionapp log tail` for `KeyError` |
