import serverless from 'serverless-http';
import { createApp } from '../app';

// Built once per execution environment (cold start); reused across invocations.
export const handler = serverless(createApp(), {
  // API Gateway HTTP API (payload v2) — pass the request id through for log correlation.
  request(req: { headers: Record<string, string> }, _event: unknown, context: { awsRequestId?: string }) {
    if (context?.awsRequestId && !req.headers['x-request-id']) req.headers['x-request-id'] = context.awsRequestId;
  },
});
