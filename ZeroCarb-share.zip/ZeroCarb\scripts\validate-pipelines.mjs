#!/usr/bin/env node
// Offline structural validation of the GreenQA pipeline YAML (no ADO calls).
//
// Checks: every file is well-formed YAML; each scenario pipeline defaults agentPoolName=SF1 and extends the
// shared template; targetRegion is an allow-listed dropdown for routable scenarios and stays 'auto' for the
// MS-hosted lock demo (05); the template still selects the pool via a region-capability demand.
// The authoritative test is the ADO preview run (scripts/preview_pipeline.ps1), which needs a PAT.
import { readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { parse } from 'yaml';

const PIPE = join(resolve(dirname(fileURLToPath(import.meta.url)), '..'), 'pipelines');
const ROUTABLE = ['01-billing-prod-hotfix.yml', '02-nightly-ci-azure-fn.yml', '03-api-tests-smoke.yml', '04-ml-train-fraud-detection.yml'];
const LOCKED = '05-e2e-tests-ms-hosted.yml';
const EXPECTED_REGION_VALUES = ['auto', 'uksouth', 'ukwest', 'westeurope', 'swedencentral'];

const errors = [];
const oks = [];

const param = (doc, name) => (doc.parameters ?? []).find((p) => p.name === name);

function load(path, name) {
  try {
    return parse(readFileSync(path, 'utf8'));
  } catch (e) {
    errors.push(`${name}: YAML parse error: ${e.message}`);
    return null;
  }
}

function checkPipeline(name) {
  const doc = load(join(PIPE, name), name);
  if (!doc) return;
  oks.push(`${name}: well-formed YAML`);

  const pool = param(doc, 'agentPoolName');
  if (pool?.default !== 'SF1') errors.push(`${name}: agentPoolName default is ${pool ? pool.default : 'MISSING'} (expected SF1)`);
  else oks.push(`${name}: agentPoolName default = SF1`);

  const tr = param(doc, 'targetRegion');
  if (!tr) errors.push(`${name}: targetRegion parameter MISSING`);
  else if (name === LOCKED) {
    if (tr.default !== 'auto') errors.push(`${name}: lock demo targetRegion default != auto`);
    else if ('values' in tr) errors.push(`${name}: lock demo should NOT expose EU values (found ${JSON.stringify(tr.values)})`);
    else oks.push(`${name}: targetRegion pinned to 'auto' (lock demo, no values)`);
  } else if (JSON.stringify(tr.values) !== JSON.stringify(EXPECTED_REGION_VALUES)) {
    errors.push(`${name}: targetRegion values ${JSON.stringify(tr.values)} != ${JSON.stringify(EXPECTED_REGION_VALUES)}`);
  } else if (tr.default !== 'auto') errors.push(`${name}: targetRegion default != auto`);
  else oks.push(`${name}: targetRegion dropdown = ${JSON.stringify(tr.values)}`);

  const ext = doc.extends ?? {};
  if (ext.template !== '_shared/gate-template.yml') {
    errors.push(`${name}: does not extend _shared/gate-template.yml`);
    return;
  }
  const ep = ext.parameters ?? {};
  for (const k of ['targetRegion', 'agentPoolName']) if (!(k in ep)) errors.push(`${name}: extends does not forward ${k}`);
  oks.push(`${name}: extends gate-template, forwards targetRegion+agentPoolName`);
  // westeurope must be a candidate so the gate can recommend the new VM.
  const cand = String(ep.candidateRegions ?? '');
  if (ROUTABLE.includes(name)) {
    if (!cand.includes('westeurope')) errors.push(`${name}: candidateRegions missing westeurope (${cand})`);
    else oks.push(`${name}: candidateRegions includes westeurope`);
  }
}

function checkTemplate() {
  const name = 'gate-template.yml';
  const path = join(PIPE, '_shared', name);
  const doc = load(path, name);
  if (!doc) return;
  oks.push(`${name}: well-formed YAML`);
  const pool = param(doc, 'agentPoolName');
  if (pool?.default !== 'SF1') errors.push(`${name}: agentPoolName default != SF1`);
  else oks.push(`${name}: agentPoolName default = SF1`);
  const raw = readFileSync(path, 'utf8');
  if (!raw.includes('region -equals ${{ parameters.targetRegion }}')) errors.push(`${name}: missing 'region -equals' capability demand`);
  else oks.push(`${name}: pool selected via 'region -equals targetRegion' demand`);
  if (!raw.includes('decide.mjs')) errors.push(`${name}: gate step must call pipelines/_shared/decide.mjs`);
  else oks.push(`${name}: gate step uses decide.mjs`);
}

checkTemplate();
for (const f of [...ROUTABLE, LOCKED].sort()) checkPipeline(f);

console.log(oks.map((o) => `  PASS  ${o}`).join('\n'));
if (errors.length) {
  console.log(errors.map((e) => `  FAIL  ${e}`).join('\n'));
  console.log(`\n${errors.length} problem(s) found.`);
  process.exit(1);
}
console.log(`\nAll ${oks.length} checks passed.`);
