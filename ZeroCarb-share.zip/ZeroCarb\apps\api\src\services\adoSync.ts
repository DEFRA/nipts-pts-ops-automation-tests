import { settings } from '../config';
import { executionRegions } from '../domain/providers';
import { round } from '../domain/sci';
import { logger } from '../logger';
import type { Repository } from '../repo/types';
import { configuredProject, listPipelineRuns, parseOrgUrl, runPipeline } from './adoClient';
import { getConnection } from './adoConnection';
import { estimateRunCarbon } from './carbonService';

/** Recover the region from the `agents-<region>` pool convention or `<pool> (region=<region>)`. */
export function regionFromPoolName(poolName: string | null | undefined, providerName: string): string {
  const allowed = executionRegions(providerName);
  const fallback = allowed[0] ?? 'uksouth';
  if (!poolName) return fallback;
  const name = poolName.trim().toLowerCase();
  return allowed.find((r) => name === `agents-${r}` || name.includes(`region=${r}`)) ?? fallback;
}

/**
 * Reconcile real Azure DevOps runs into pipeline_executions. ADO is authoritative for status, duration and
 * the agent pool (hence region), so a dashboard run's *intended* region is overwritten with where it actually
 * ran. Decision metadata set at trigger time is preserved; externally started runs get an estimated emission.
 */
export async function ingestAdoRuns(repo: Repository, provider: string, pipelineId: string, limit: number): Promise<void> {
  let conn;
  try {
    conn = await getConnection(repo);
  } catch (err) {
    logger.error({ err }, 'ingestAdoRuns: getConnection failed');
    return;
  }
  if (!conn) return;

  const organization = parseOrgUrl(conn.org_url) || conn.organization;
  const project = conn.project || configuredProject();
  if (!organization || !conn.pat) return;

  let runs;
  try {
    runs = await listPipelineRuns(organization, project, pipelineId, conn.pat, limit);
  } catch (err) {
    logger.error({ err, pipelineId }, 'ingestAdoRuns: run listing failed');
    return;
  }

  const existing = new Map<string, Record<string, unknown>>();
  try {
    for (const r of await repo.listExecutionsForPipeline(pipelineId, provider, limit)) {
      if (r.run_id) existing.set(String(r.run_id), r);
    }
  } catch { /* first sync: nothing to merge */ }

  const allowed = executionRegions(provider);
  for (const run of runs) {
    if (!run.run_id) continue;
    const region = regionFromPoolName(run.pool, provider);
    const duration = run.duration_seconds ?? 0;
    const actual = duration ? await estimateRunCarbon(repo, region, provider, duration) : 0;

    // Baseline = same workload in the dirtiest region it could have used.
    let baseline = actual;
    if (duration && allowed.length) {
      baseline = Math.max(...(await Promise.all(allowed.map((r) => estimateRunCarbon(repo, r, provider, duration)))));
    }

    const prev = existing.get(run.run_id) ?? {};
    const row = {
      ...prev,
      id: `${pipelineId}::${run.run_id}`,
      run_id: run.run_id,
      pipeline_id: pipelineId,
      project,
      provider,
      region,
      pool: run.pool ?? null,
      duration_seconds: duration,
      status: run.status || 'Queued',
      actual_carbon_g: round(actual, 2),
      baseline_carbon_g: round(baseline, 2),
      carbon_estimated: true,
      commit_sha: run.commit_sha || prev.commit_sha,
      author: run.author || prev.author,
      web_url: run.web_url || prev.web_url,
      stored_at: String(run.created_at || prev.stored_at || new Date().toISOString()),
      decision: prev.decision ?? 'EXTERNAL',
      criticality: prev.criticality ?? 'normal',
    };
    try {
      await repo.upsertExecution(row);
    } catch (err) {
      logger.error({ err, runId: run.run_id }, 'ingestAdoRuns: upsert failed');
    }
  }
}

/** Fire pipelines whose DEFER window has elapsed. Returns how many were examined. */
export async function resumeDeferred(repo: Repository): Promise<number> {
  const maxAttempts = settings.deferMaxAttempts();
  const nowIso = new Date().toISOString();
  const pending = await repo.listPendingDeferred(nowIso);
  logger.info({ pending: pending.length }, 'resume_deferred');

  for (const row of pending) {
    const decisionId = String(row.decision_id ?? row.id);
    const ado = (row.ado_parts ?? {}) as { organization?: string; project?: string; definition_id?: string };

    if (!ado.organization || !ado.project || !ado.definition_id) {
      await repo.upsertDeferred({ ...row, status: 'failed', last_error: 'missing_ado_parts' });
      continue;
    }

    const result = await runPipeline({
      organization: ado.organization, project: ado.project, definitionId: ado.definition_id, decisionId,
    });

    const next: Record<string, unknown> = { ...row, attempts: Number(row.attempts ?? 0) + 1, last_attempt_at: nowIso };
    if (result.success) {
      next.status = 'fired';
      next.ado_run_id = result.run_id;
      next.ado_run_url = result.url;
    } else {
      next.last_error = result.error ?? 'unknown';
      if ((next.attempts as number) >= maxAttempts) next.status = 'failed';
    }
    await repo.upsertDeferred(next as typeof row);
  }
  return pending.length;
}
