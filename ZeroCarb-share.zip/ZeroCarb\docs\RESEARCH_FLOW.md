# Research Watcher — Add / Reject Flow

This document answers the specific questions raised about what happens when a
new research document is found and the operator chooses **Add** or **Reject**.

---

## 1 · Decision persistence

Every Accept / Reject decision is keyed by the document's `findingId` and
written to the browser's `localStorage` under:

| Key | Shape | Lives |
|---|---|---|
| `ccd.research.decisions.v1` | `{ [findingId]: 'accepted' \| 'rejected' }` | per browser, per user |
| `ccd.research.storedDocs.v1` | `[{ findingId, title, source, storedAt, location, artefacts }]` | per browser |
| `ccd.research.draftIssues.v1` | `[{ id, findingId, title, kind, status, … }]` | per browser |
| `ccd.research.storage.v1` | `{ kind, local, azureBlob, github }` | per browser |

In production these are mirrored to Cosmos DB so decisions are user-wide,
not browser-wide — but the contract is identical. The next research scan
filters out any `findingId` already present in `decisions`, so:

> **The same document is never re-suggested once a user has accepted or
> rejected it.** The "Reset decisions" button (visible only when the
> pending queue is empty) is a developer escape hatch and clears the
> store.

---

## 2 · Storage location — choose & switch any time

Operators pick one of three backends. The current target is shown in the
strip at the top of the Research tab; **Change storage…** opens the editor.

| Backend | What it does | Auth | Where to set credentials in prod |
|---|---|---|---|
| **Local folder** | Writes files into a repo-relative path (default `researchPaper/`). Best for prototypes and the Bicep-deployed Function App with a mounted file share. | n/a | — |
| **Azure Blob Storage** | Writes files into `{account}.blob.core.windows.net/{container}/{prefix}`. Both artefacts are tagged with source + ingestion time. | Function App managed identity (recommended) or SAS token in Key Vault | `kv:/green-qa/storage/blob-sas` |
| **GitHub repository** | Commits files to `{repo}@{branch}:{path}` via the GitHub Contents API. Also enables one-click **Push to GitHub** on draft issues. | Personal access token with `repo` + `write:issues` scopes | `kv:/green-qa/github/pat` |

**Switching is non-destructive.** Past artefacts stay where they were
written — only *future* ingests use the new target. The "Stored documents"
table records which location each entry went to.

---

## 3 · What "Add" actually does (5-step pipeline)

Clicking **Add** opens the *Ingest pipeline* modal. It is not a single
write — it's a 5-step asynchronous flow that the user watches:

| # | Step | What it does | Source code |
|---|---|---|---|
| 1 | **Fetch** | Downloads the full document from its source URL. Only runs if the source already passed metadata-stage keyword matching. | `lambda/carbon_ingestion/handler.py` (research subhandler — TODO wire from prototype) |
| 2 | **Summarise** | Generates a Markdown summary with structured front-matter (`title`, `source`, `published`, `keywords`, `relevance`) plus a 200-line body. | `green_qa_lib/research_summariser.py` (planned) |
| 3 | **Store** | Writes **both** the original (PDF/HTML) **and** the summary (Markdown) to the configured storage target. Two artefacts per document — never just one. | `green_qa_lib/research_storage.py` (planned: local / blob / github adapter) |
| 4 | **Align** | Compares the new document against the live utility code. Produces three lists: *aligned*, *gaps*, *suggestions*. Never modifies code. | `green_qa_lib/research_aligner.py` (planned) |
| 5 | **Draft issues** | Every *gap* and *suggestion* becomes one entry in the draft-issues tracker. | in-app `localStorage` (this document, §4) |

Abandoning the modal (close before step 5) does **not** commit a decision —
the document stays in the pending queue.

### Artefacts written per Accept

| File | Contents | Example path |
|---|---|---|
| `<findingId>.pdf` / `.html` | Original document, byte-identical to source. | `researchPaper/finding-01.pdf` |
| `<findingId>.summary.md` | Generated Markdown summary with front-matter. | `researchPaper/finding-01.summary.md` |

Both artefacts are required. The summary is what humans read; the original
is preserved for audit (regulators want the source-of-truth byte-stream,
not your summary of it).

---

## 4 · Draft issues — where they live and what happens next

The alignment step files **draft issues** into a tracker on the Research
tab. Each issue carries:

```jsonc
{
  "id": "iss-1716385920000-0",
  "findingId": "finding-01",
  "findingTitle": "Greening Government ICT and Digital Services Strategy 2025–2030 — annex C",
  "title": "Gap: Marginal carbon intensity",
  "body": "JRC report: average-CI under-reports by 8–22% — utility currently uses average-CI from ElectricityMaps",
  "kind": "gap",                // 'gap' | 'suggestion'
  "status": "draft",             // 'draft' | 'pushed' | 'dismissed'
  "createdAt": "2026-05-22T10:14:08Z"
}
```

### Lifecycle

| Status | Where it lives | What the user can do |
|---|---|---|
| `draft` | `localStorage.ccd.research.draftIssues.v1` (visible in this dashboard only) | Push to GitHub (if storage = GitHub), Dismiss |
| `pushed` | Real GitHub issue in the configured repo · stub URL recorded on the draft | Open on GitHub |
| `dismissed` | Stays in the tracker for audit, marked `DISMISSED` | — |

### Real-world workflow after a draft is created

1. Operator triages the draft in the dashboard (or filters by `gap` to see hard requirements).
2. If material, operator clicks **Push to GitHub**. This calls `POST /repos/{owner/repo}/issues` using the PAT from storage config. (Local / Blob storage modes don't push — drafts stay in-app.)
3. Engineering reviews the issue in the **weekly carbon review** (recurring meeting, owners: maintainers + sustainability lead).
4. Maintainer assigns an owner and labels by area (scheduler, budgets, regions, alignment-jrc-138291…).
5. Owner opens a PR referencing the issue (`Fixes #1024`). CI runs the standard test pack + the carbon-gate check.
6. Two maintainer approvals required; the issue auto-closes on merge.
7. The Research watcher re-runs alignment on the next scan and clears the gap — *or* surfaces a fresh follow-up if the implementation only partially addressed it.

### Why drafts and not direct creation?

- **Auditability.** Every gap appears in two places (this dashboard + the GitHub repo if pushed) and is keyed to the source document.
- **Noise control.** A research document can produce 5–15 alignment items; operators triage before flooding the engineering backlog.
- **Air-gap-friendliness.** Local & Blob storage modes never call GitHub, so the dashboard remains useful in restricted-egress environments.

---

## 5 · What is NEVER done automatically

- Modify the codebase
- Open a PR
- Merge anything
- Push to GitHub without the operator's explicit click
- Re-suggest a document the user has already accepted or rejected

These are deliberate safety rails. The Research watcher is an *assistant*,
not an *agent*.
