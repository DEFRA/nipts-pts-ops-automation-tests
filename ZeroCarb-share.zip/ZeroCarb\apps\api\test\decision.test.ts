import { beforeEach, describe, expect, it } from 'vitest';
import { MemoryRepository } from '../src/repo/memory';
import { parseDecideRequest } from '../src/schemas';
import { decide, labelForStrategy, parseAdoParts } from '../src/services/decisionService';

let repo: MemoryRepository;
beforeEach(() => { repo = new MemoryRepository(); });

const req = (over: Record<string, unknown> = {}) => parseDecideRequest({ pipeline_id: 'p1', run_id: 'r1', current_region: 'uksouth', ...over });

const sample = (region: string, grid: number) => repo.upsertCarbonSample({
  id: `azure::${region}`, provider: 'azure', region, sampled_at: new Date().toISOString(),
  grid_intensity_gco2_kwh: grid, dc_intensity_gco2_kwh: grid * 1.185,
});

describe('decide', () => {
  it('short-circuits resumed runs to RUN_NOW and keeps the decision id', async () => {
    const r = await decide(req({ resumed_decision_id: 'd-123' }), repo);
    expect(r.decision).toBe('RUN_NOW');
    expect(r.decision_id).toBe('d-123');
    expect(r.reasoning).toMatch(/Resumed/);
  });

  it('relocates to the cleaner execution region', async () => {
    await sample('uksouth', 400);
    await sample('ukwest', 100);
    const r = await decide(req(), repo);
    expect(r.decision).toBe('RELOCATE');
    expect(r.selected_region).toBe('ukwest');
    expect(r.selected_pool).toBe('agents-ukwest');
    expect(r.carbon.savings_percent).toBe(75);
  });

  it('uses supplied candidate pool names', async () => {
    await sample('uksouth', 400);
    await sample('ukwest', 100);
    const r = await decide(req({ candidate_pools: { ukwest: 'SF1' } }), repo);
    expect(r.selected_pool).toBe('SF1');
  });

  it('forces RUN_NOW with no pool for MS-hosted agents', async () => {
    await sample('uksouth', 400);
    await sample('ukwest', 100);
    const r = await decide(req({ pool_mode: 'ms_hosted_single_region' }), repo);
    expect(r.decision).toBe('RUN_NOW');
    expect(r.selected_region).toBe('uksouth');
    expect(r.selected_pool).toBeNull();
  });

  it('never shifts critical pipelines', async () => {
    await sample('uksouth', 400);
    await sample('ukwest', 100);
    expect((await decide(req({ criticality: 'CRITICAL' }), repo)).decision).toBe('RUN_NOW');
  });

  it('persists a pending deferred run for time-shifts', async () => {
    await sample('uksouth', 164);
    const r = await decide(req({ pipeline_id: 'azdo://org/proj/42' }), repo);
    // The synthetic forecast usually offers a >=10% dip within 12h; accept either outcome but verify persistence when deferred.
    if (r.decision === 'DEFER') {
      const row = await repo.getDeferred(r.decision_id);
      expect(row?.status).toBe('pending');
      expect(row?.ado_parts).toEqual({ organization: 'org', project: 'proj', definition_id: '42' });
      expect(r.defer_until_iso).toBeTruthy();
    } else {
      expect(await repo.getDeferred(r.decision_id)).toBeNull();
    }
  });
});

describe('helpers', () => {
  it('maps engine strategies to API labels', () => {
    expect(labelForStrategy('time_shift', 'a', 'a')).toBe('DEFER');
    expect(labelForStrategy('space_shift', 'b', 'a')).toBe('RELOCATE');
    expect(labelForStrategy('space_shift', 'a', 'a')).toBe('RUN_NOW');
    expect(labelForStrategy('hybrid', 'b', 'a')).toBe('HYBRID');
  });
  it('parses azdo:// pipeline ids', () => {
    expect(parseAdoParts('azdo://o/p/9')).toEqual({ organization: 'o', project: 'p', definition_id: '9' });
    expect(parseAdoParts('plain')).toEqual({});
    expect(parseAdoParts('azdo://o/p')).toEqual({});
  });
});
