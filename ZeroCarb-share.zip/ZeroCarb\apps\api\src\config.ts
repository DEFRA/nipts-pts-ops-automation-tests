// Env helpers read process.env lazily so tests and Lambda config can change values at runtime.

export function envStr(name: string, fallback = ''): string {
  const v = process.env[name];
  return v === undefined ? fallback : v;
}

export function envFloat(name: string, fallback: number): number {
  const n = Number.parseFloat(process.env[name] ?? '');
  return Number.isFinite(n) ? n : fallback;
}

export function envInt(name: string, fallback: number): number {
  const n = Number.parseInt(process.env[name] ?? '', 10);
  return Number.isFinite(n) ? n : fallback;
}

export function envBool(name: string, fallback = false): boolean {
  const v = process.env[name];
  if (v === undefined || v === '') return fallback;
  return ['1', 'true', 'yes'].includes(v.trim().toLowerCase());
}

export function envList(name: string, fallback: readonly string[]): string[] {
  const raw = process.env[name];
  if (!raw) return [...fallback];
  return raw.split(',').map((s) => s.trim()).filter(Boolean);
}

export type AppEnv = 'local' | 'dev' | 'uat' | 'prod';

export function appEnv(): AppEnv {
  const v = envStr('APP_ENV', 'local').toLowerCase();
  return (['local', 'dev', 'uat', 'prod'] as const).includes(v as AppEnv) ? (v as AppEnv) : 'local';
}

/** Tunables that were Function App settings in the Azure deployment. */
export const settings = {
  defaultCarbonIntensity: () => envFloat('DEFAULT_CARBON_INTENSITY_GCO2_KWH', 300),
  defaultPue: () => envFloat('DEFAULT_PUE', 1.185),
  defaultFunctionalUnit: () => envInt('DEFAULT_FUNCTIONAL_UNIT', 1),
  historyDefaultLimit: () => envInt('HISTORY_DEFAULT_LIMIT', 50),
  historyMaxLimit: () => envInt('HISTORY_MAX_LIMIT', 500),
  ingestProviders: () => envList('INGEST_PROVIDERS', ['aws', 'azure']),
  adoRunDefaultVcpu: () => envInt('ADO_RUN_DEFAULT_VCPU', 2),
  adoRunDefaultMemoryGb: () => envFloat('ADO_RUN_DEFAULT_MEMORY_GB', 4),
  deferMaxAttempts: () => envInt('DEFER_MAX_ATTEMPTS', 3),
};
