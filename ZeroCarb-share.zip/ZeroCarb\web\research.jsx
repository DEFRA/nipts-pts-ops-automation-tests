/* global React, CCD_DATA, useStore, useConfig */
// =======================================================================
// ⚠️ PHASE-2 — TEMPORARILY HIDDEN FROM THE UI.
// The Research tab is disabled via the `research` feature flag in app.jsx
// (CCD_FEATURES.research === false). This file is intentionally retained,
// unmodified, for phase 2. To re-enable: set window.CCD_FEATURES.research
// = true (e.g. in config.js) — the TABS entry and route restore automatically.
// NOTE: this module still references CCD_DATA fixtures; that is acceptable
// only because it is not mounted. Do not wire it into the live app until it
// has been migrated to API-driven data in phase 2.
// =======================================================================
// Research Watcher
//
// This module covers the full Add / Reject flow that operators see when the
// background scan surfaces a new EU/UK government document.
//
//   • Storage location is configurable — Local folder, Azure Blob or GitHub
//     repo — and can be switched at any time. The current target is shown
//     in the header strip; "Change…" opens a modal that lets the user pick
//     and edit credentials.
//
//   • Accept is a 5-step pipeline, not a single click:
//       1. fetch the original document (PDF / HTML)
//       2. generate a structured Markdown summary (front-matter + body)
//       3. store BOTH artefacts at the chosen location
//       4. run the alignment check against the live utility
//       5. file any gaps / suggestions as draft issues
//     The IngestFlowModal renders that pipeline live so users see exactly
//     what is happening.
//
//   • Every accept/reject decision is persisted to localStorage by document
//     ID, so the same finding is never resurfaced after a user has acted on
//     it — even after a page reload or another scan.
//
//   • Draft Issues live in their own section. They can be reviewed in-app,
//     dismissed, or pushed to GitHub. The post-creation real-world workflow
//     is documented inline (review → assign → PR → merge).
// =======================================================================

const {
  RESEARCH_SOURCES, RESEARCH_KEYWORDS, PENDING_FINDINGS,
  RESEARCH_LOG, RESEARCH_ALIGNMENT, RESEARCH_SCHEDULE
} = CCD_DATA;

// -----------------------------------------------------------------------
// localStorage helpers
// -----------------------------------------------------------------------
const LS_DECISIONS    = 'ccd.research.decisions.v1';   // { [findingId]: 'accepted' | 'rejected' }
const LS_STORAGE_CFG  = 'ccd.research.storage.v2';     // { kind, ... } (v2: default = github)
const LS_DRAFT_ISSUES = 'ccd.research.draftIssues.v1'; // [{ id, title, ... }]
const LS_STORED_DOCS  = 'ccd.research.storedDocs.v1';  // [{ findingId, storedAt, location, artefacts }]

function lsRead(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw == null ? fallback : JSON.parse(raw);
  } catch (e) { return fallback; }
}
function lsWrite(key, value) {
  try { localStorage.setItem(key, JSON.stringify(value)); }
  catch (e) { /* quota — ignore */ }
}
function useLocalStorage(key, initial) {
  const [value, setValue] = React.useState(() => lsRead(key, initial));
  React.useEffect(() => { lsWrite(key, value); }, [key, value]);
  return [value, setValue];
}

// -----------------------------------------------------------------------
// Storage defaults — local folder, switchable to Azure Blob or GitHub
// -----------------------------------------------------------------------
const DEFAULT_STORAGE = {
  kind: 'github',                         // 'github' | 'azure-blob' | 'local'
  local:    { folder: 'researchPaper/' },
  azureBlob:{ account: '', container: 'research-papers', prefix: 'papers/', sasOrManagedIdentity: 'managed-identity' },
  github:   { repo: 'cognizant/green-qa-platform', branch: 'main', path: 'researchPaper/', pat: '' }
};

function storageLabel(s) {
  if (!s) return 'Not configured';
  if (s.kind === 'local')      return 'Local folder · ' + s.local.folder;
  if (s.kind === 'azure-blob') return 'Azure Blob · ' + (s.azureBlob.account ? s.azureBlob.account + '.blob.core/' + s.azureBlob.container + '/' + s.azureBlob.prefix : 'not configured');
  if (s.kind === 'github')     return 'Under ' + s.github.path + ' in your repository';
  return 'Unknown';
}

// short tag used in tables and toasts
function storageShort(s) {
  return ({ local: 'LOCAL', 'azure-blob': 'AZURE BLOB', github: 'GITHUB' })[s.kind] || s.kind;
}

// -----------------------------------------------------------------------
// utility: relative time formatting (used for "next run / last run")
// -----------------------------------------------------------------------
function fmtUntil(targetISO, fromDate) {
  const target = new Date(targetISO).getTime();
  const now = fromDate.getTime();
  let diff = Math.floor((target - now) / 1000);
  const past = diff < 0;
  diff = Math.abs(diff);
  const d = Math.floor(diff / 86400);
  const h = Math.floor((diff % 86400) / 3600);
  const m = Math.floor((diff % 3600) / 60);
  let str;
  if (d > 0)      str = d + 'd ' + h + 'h';
  else if (h > 0) str = h + 'h ' + m + 'm';
  else            str = m + 'm';
  return past ? str + ' ago' : 'in ' + str;
}

function fmtDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

// -----------------------------------------------------------------------
// Research Watcher — main section
// -----------------------------------------------------------------------
function ResearchWatcherPanel({ now }) {
  const { toast, openModal, closeModal } = useStore();
  const [config] = useConfig();

  // Persisted state ---------------------------------------------------
  const [decisions,   setDecisions]   = useLocalStorage(LS_DECISIONS, {});
  const [storage,     setStorage]     = useLocalStorage(LS_STORAGE_CFG, DEFAULT_STORAGE);
  const [draftIssues, setDraftIssues] = useLocalStorage(LS_DRAFT_ISSUES, []);
  const [storedDocs,  setStoredDocs]  = useLocalStorage(LS_STORED_DOCS, []);

  // Findings = fixture pending list filtered by persisted decisions ----
  // The fixture list represents whatever a recent scan surfaced; once the
  // user has decided on one, it never reappears here.
  const allFindings = PENDING_FINDINGS;
  const findings = allFindings.map(f => ({ ...f, decision: decisions[f.id] || null }));
  const pending  = findings.filter(f => f.decision === null);
  const decided  = findings.filter(f => f.decision !== null);

  // Job state ---------------------------------------------------------
  const [job, setJob] = React.useState({ running: false, processed: 0, total: 0, found: 0 });
  const jobTimerRef = React.useRef(null);

  const [log, setLog] = React.useState(RESEARCH_LOG);
  const [keywords, setKeywords] = React.useState(RESEARCH_KEYWORDS);
  const [intervalDays, setIntervalDays] = React.useState(RESEARCH_SCHEDULE.intervalDays);
  const nextRun = React.useMemo(() => {
    const base = new Date(RESEARCH_SCHEDULE.lastRunISO).getTime();
    return new Date(base + intervalDays * 86400 * 1000).toISOString();
  }, [intervalDays]);

  // ------------------ Run-now scan job ------------------
  const runNow = () => {
    if (job.running) return;
    // De-dupe note: a real scan never re-surfaces docs the user already
    // decided on. We model that by skipping any source whose docs are
    // already in `decisions`.
    const total = RESEARCH_SOURCES.length;
    setJob({ running: true, processed: 0, total, found: 0 });
    toast({
      kind: 'info',
      title: 'Research scan started',
      message: 'Scanning ' + total + ' EU/UK gov sources · de-duping against ' + Object.keys(decisions).length + ' prior decisions',
      detail: 'Runs as a background job — you can keep using the dashboard'
    });

    let processed = 0, found = 0;
    jobTimerRef.current = setInterval(() => {
      processed += 1;
      const src = RESEARCH_SOURCES[processed - 1];
      if (src && src.newDocs > 0) {
        found += src.newDocs;
        setLog(prev => ([
          { ts: 'just now', source: src.id, docKey: 'live:' + src.id + ':' + Math.floor(Math.random() * 9999), action: 'queued', detail: 'live scan · pending user confirmation' },
          ...prev.slice(0, 49)
        ]));
      } else if (src && src.status === 'timeout') {
        setLog(prev => ([
          { ts: 'just now', source: src.id, docKey: '—', action: 'timeout', detail: 'fallback skipped after ' + RESEARCH_SCHEDULE.timeoutSec + 's' },
          ...prev.slice(0, 49)
        ]));
      } else if (src) {
        setLog(prev => ([
          { ts: 'just now', source: src.id, docKey: '—', action: 'unchanged', detail: 'last-modified ≤ last run timestamp' },
          ...prev.slice(0, 49)
        ]));
      }
      setJob(j => ({ ...j, processed, found }));
      if (processed >= total) {
        clearInterval(jobTimerRef.current);
        setJob(j => ({ ...j, running: false }));
        toast({
          kind: found > 0 ? 'warn' : 'success',
          title: found > 0 ? found + ' new documents found' : 'No new documents',
          message: found > 0
            ? 'Review pending findings and confirm before adding to ' + storageLabel(storage)
            : 'All ' + total + ' sources up-to-date · next run ' + fmtUntil(nextRun, now),
          ttl: 6000
        });
      }
    }, 420);
  };
  React.useEffect(() => () => clearInterval(jobTimerRef.current), []);

  // ------------------ Accept / Reject ------------------
  // Reject is a one-click action and writes to the log + decisions store.
  const reject = (f) => {
    setDecisions(prev => ({ ...prev, [f.id]: 'rejected' }));
    setLog(prev => ([
      { ts: 'just now', source: f.source, docKey: f.url.split('/').pop(), action: 'filtered', detail: 'rejected by user — won\'t be suggested again' },
      ...prev.slice(0, 49)
    ]));
    toast({ kind: 'info', title: 'Finding dismissed', message: f.title.slice(0, 60) + '…', detail: 'Won\'t resurface in future scans.' });
  };

  // Accept opens the 5-step ingest flow modal. It commits the decision
  // only on successful completion (so abandoning the modal keeps the doc
  // in the pending queue).
  const accept = (f) => {
    openModal({
      element: (
        <IngestFlowModal
          finding={f}
          storage={storage}
          onClose={closeModal}
          onComplete={(result) => {
            // Persist decision
            setDecisions(prev => ({ ...prev, [f.id]: 'accepted' }));
            // Record the stored artefacts
            setStoredDocs(prev => ([
              {
                findingId: f.id,
                title: f.title,
                source: f.sourceLabel,
                storedAt: new Date().toISOString(),
                location: storage,
                artefacts: result.artefacts,    // [{ kind, path, sizeKb }]
              },
              ...prev
            ]));
            // Log line
            setLog(prev => ([
              { ts: 'just now', source: f.source, docKey: f.url.split('/').pop(), action: 'ingested', detail: 'stored at ' + storageShort(storage) + ' · ' + result.artefacts.length + ' artefacts' },
              ...prev.slice(0, 49)
            ]));
            // Auto-file alignment gaps + suggestions as draft issues
            const newIssues = result.draftIssues.map((it, i) => ({
              ...it,
              id: 'iss-' + Date.now() + '-' + i,
              findingId: f.id,
              findingTitle: f.title,
              createdAt: new Date().toISOString(),
              status: 'draft'   // 'draft' | 'pushed' | 'dismissed'
            }));
            setDraftIssues(prev => [...newIssues, ...prev]);

            toast({
              kind: 'success',
              title: 'Document ingested',
              message: f.title.length > 64 ? f.title.slice(0, 64) + '…' : f.title,
              detail: 'Stored at ' + storageShort(storage) + ' · ' + newIssues.length + ' draft issues filed'
            });
          }}
        />
      ),
      onClose: closeModal
    });
  };

  // ------------------ Storage change ------------------
  const openStorageModal = () => openModal({
    element: <StorageLocationModal value={storage} onSave={(v) => { setStorage(v); toast({ kind: 'success', title: 'Storage updated', message: storageLabel(v), detail: 'New findings will be stored here. Existing artefacts are not moved.' }); }} onClose={closeModal} />,
    onClose: closeModal
  });

  // ------------------ Issue actions ------------------
  const pushIssue = (issue) => {
    if (storage.kind !== 'github') {
      toast({
        kind: 'warn',
        title: 'GitHub not configured',
        message: 'Switch storage to GitHub to push issues directly to a repo.',
        detail: 'Local & Blob storage keep issues in this dashboard\'s draft tracker.'
      });
      return;
    }
    setDraftIssues(prev => prev.map(i => i.id === issue.id ? { ...i, status: 'pushed', pushedAt: new Date().toISOString(), githubUrl: 'https://github.com/' + storage.github.repo + '/issues/' + (1000 + Math.floor(Math.random() * 200)) } : i));
    toast({
      kind: 'success',
      title: 'Pushed to GitHub',
      message: '#' + (1000 + Math.floor(Math.random() * 200)) + ' opened in ' + storage.github.repo,
      detail: 'Engineering will triage in the weekly carbon review.'
    });
  };
  const dismissIssue = (issue) => {
    setDraftIssues(prev => prev.map(i => i.id === issue.id ? { ...i, status: 'dismissed' } : i));
  };
  const clearAllIssues = () => {
    if (!window.confirm('Remove all dismissed/draft issues from the tracker? Pushed issues stay on GitHub.')) return;
    setDraftIssues([]);
  };

  // ------------------ KPI strip stats ------------------
  const okCount      = RESEARCH_SOURCES.filter(s => s.status === 'ok').length;
  const slowCount    = RESEARCH_SOURCES.filter(s => s.status === 'slow').length;
  const failedCount  = RESEARCH_SOURCES.filter(s => s.status === 'timeout').length;
  const totalProcessed = RESEARCH_SOURCES.reduce((acc, s) => acc + s.processed, 0);
  const liveDraftIssues = draftIssues.filter(i => i.status !== 'dismissed');

  const PageHeader = window.Atoms && window.Atoms.PageHeader;

  return (
    <section aria-label="Research watcher">
      <PageHeader
        title="Research"
        subtitle="EU / UK government sustainability publications. Stored at your chosen location only after you approve each finding."
        actions={
          <button type="button" className="gov-btn-secondary" onClick={(e) => {
            e.preventDefault();
            openModal({ element: <SchedulerModal intervalDays={intervalDays} setIntervalDays={setIntervalDays} keywords={keywords} setKeywords={setKeywords} onClose={closeModal} />, onClose: closeModal });
          }}>Configure schedule &amp; keywords</button>
        }
      />

      {/* ----- Status bar (storage + scan controls in one slim row) ----- */}
      <div className="research-statusbar">
        <div className="research-statusbar-item">
          <span className="research-statusbar-label">Storage</span>
          <span className="research-statusbar-value">{storageLabel(storage)}</span>
          <button type="button" className="research-link" onClick={openStorageModal}>Change</button>
        </div>
        <div className="research-statusbar-item">
          <span className="research-statusbar-label">Schedule</span>
          <span className="research-statusbar-value">Every {intervalDays} days</span>
          <span className="muted">Next {fmtUntil(nextRun, now)}</span>
        </div>
        <div className="research-statusbar-item">
          <span className="research-statusbar-label">Sources</span>
          <span className="research-statusbar-value">
            {okCount + slowCount}/{RESEARCH_SOURCES.length} reachable
          </span>
          {failedCount > 0 && (
            <span style={{ color: 'var(--gov-red-2)', fontWeight: 700 }}>{failedCount} failed</span>
          )}
        </div>
        <div className="research-statusbar-action">
          {job.running ? (
            <button type="button" className="gov-btn-secondary" onClick={() => { clearInterval(jobTimerRef.current); setJob(j => ({ ...j, running: false })); }}>
              Cancel scan
            </button>
          ) : (
            <button type="button" className="gov-btn-secondary" onClick={runNow}>
              Run scan now
            </button>
          )}
        </div>
      </div>

      {job.running && (
        <div className="research-job-progress" aria-live="polite">
          <span>Scanning <strong>{job.processed}</strong> of {job.total} sources</span>
          {job.found > 0 && <span style={{ color: 'var(--gov-amber)', fontWeight: 700 }}>{job.found} new</span>}
          <div className="job-progress" aria-label="Scan progress">
            <span style={{ width: ((job.processed / job.total) * 100) + '%' }} />
          </div>
        </div>
      )}

      {/* ----- Pending findings — collapsible, matches sibling sections ---- */}
      <details className="research-details">
        <summary>
          <span className="research-details-title">Pending Review</span>
          {pending.length > 0 ? (
            <span className="research-details-count">{pending.length}</span>
          ) : (
            <span className="research-details-count up-to-date" aria-label="Up to date">✓</span>
          )}
          <span className="muted">
            {pending.length > 0
              ? 'document' + (pending.length === 1 ? '' : 's') + ' awaiting your decision'
              : 'all documents from the last scan decided'}
          </span>
          {pending.length > 0 && (
            <button type="button" className="research-link" onClick={(e) => { e.preventDefault(); pending.forEach(reject); }}>
              Reject all
            </button>
          )}
        </summary>
        {pending.length > 0 ? (
          <div className="finding-cards">
            {findings.map(f => (
              <FindingCard key={f.id} f={f} keywords={keywords} onAccept={accept} onReject={reject} />
            ))}
          </div>
        ) : (
          <p className="research-empty">
            All {allFindings.length} documents have been decided.{' '}
            <button type="button" className="research-link" onClick={() => setDecisions({})}
              title="Reset all your accept/reject decisions — for testing only">
              Reset decisions
            </button>
          </p>
        )}
      </details>

      {/* ----- Tertiary content — collapsed by default ----- */}
      <details className="research-details">
        <summary>
          <span className="research-details-title">Trusted Sources</span>
          <span className="research-details-count">{RESEARCH_SOURCES.length}</span>
          <span className="muted">EU / UK government only</span>
        </summary>
        <table className="research-source-table compact">
          <thead>
            <tr>
              <th>Source</th>
              <th>Status</th>
              <th className="src-num">In cache</th>
              <th className="src-num">New</th>
            </tr>
          </thead>
          <tbody>
            {RESEARCH_SOURCES.map(s => (
              <tr key={s.id}>
                <td>
                  <div className="src-name">{s.name}</div>
                  <div className="src-org">{s.org} · {s.country}</div>
                </td>
                <td>
                  <span className={'status-dot ' + s.status} aria-hidden="true" />
                  <span className={'status-label ' + s.status}>
                    {s.status === 'ok' ? 'OK' : s.status === 'slow' ? 'Slow' : 'Timeout'}
                  </span>
                </td>
                <td className="src-num">{s.processed.toLocaleString('en-GB')}</td>
                <td className="src-num">
                  {s.newDocs > 0 ? <strong style={{ color: 'var(--gov-amber)' }}>{s.newDocs}</strong> : <span className="muted">—</span>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        <div className="research-details-footnote">
          Keyword pre-filter: {keywords.map((kw, i) => (
            <span key={kw} className="keyword-chip">{kw}<span className="x" onClick={() => setKeywords(keywords.filter(k => k !== kw))} title="Remove">×</span></span>
          ))}
        </div>
      </details>

      {storedDocs.length > 0 && (
        <details className="research-details">
          <summary>
            <span className="research-details-title">Stored Documents</span>
            <span className="research-details-count">{storedDocs.length}</span>
            <span className="muted">original + Markdown summary for each accepted finding</span>
          </summary>
          <StoredDocsTable docs={storedDocs} />
        </details>
      )}

      <details className="research-details">
        <summary>
          <span className="research-details-title">Draft Issues</span>
          {liveDraftIssues.length > 0 && <span className="research-details-count">{liveDraftIssues.length}</span>}
          <span className="muted">
            {draftIssues.length === 0
              ? 'None yet — accept a finding to file alignment gaps'
              : draftIssues.length + ' total · ' + liveDraftIssues.length + ' active'}
          </span>
        </summary>
        <DraftIssuesPanel
          issues={draftIssues}
          liveCount={liveDraftIssues.length}
          storage={storage}
          onPush={pushIssue}
          onDismiss={dismissIssue}
          onClearAll={clearAllIssues}
        />
      </details>

      <details className="research-details">
        <summary>
          <span className="research-details-title">Ingestion Log</span>
          <span className="muted">latest {Math.min(log.length, 14)} entries</span>
        </summary>
        <ul className="ingest-log-list">
          {log.slice(0, 14).map((l, i) => (
            <li key={i}>
              <span className="ingest-log-ts">{l.ts}</span>
              <span className={'ingest-log-action ' + l.action}>{l.action}</span>
              <span className="ingest-log-src">{l.source}</span>
              <span className="ingest-log-detail muted">{l.detail}</span>
            </li>
          ))}
        </ul>
      </details>
    </section>
  );
}

// =======================================================================
// Storage strip — the visible header that tells users where docs go
// =======================================================================
function StorageStrip({ storage, onChange, storedCount }) {
  const kindLabel = ({ local: 'Local folder', 'azure-blob': 'Azure Blob Storage', github: 'GitHub repository' })[storage.kind];
  return (
    <div className="storage-strip" style={{
      display: 'flex', alignItems: 'center', gap: 'var(--s-3)',
      padding: 'var(--s-3) var(--s-4)', border: '1px solid var(--gov-border)',
      background: 'var(--gov-bg-3)', marginBottom: 'var(--s-4)', flexWrap: 'wrap'
    }}>
      <span className="ccd-tag dark" style={{ flexShrink: 0 }}>STORAGE TARGET</span>
      <div style={{ flex: 1, minWidth: 240 }}>
        <div style={{ fontWeight: 700, fontSize: 'var(--t-16)' }}>
          {kindLabel}
        </div>
        <div className="muted" style={{ fontSize: 'var(--t-14)' }}>
          {storageLabel(storage)}
        </div>
      </div>
      <div className="muted" style={{ fontSize: 'var(--t-14)', textAlign: 'right' }}>
        {storedCount} document{storedCount === 1 ? '' : 's'} stored here
        <br />
        <span style={{ fontSize: 'var(--t-12)' }}>Switchable at any time · existing artefacts stay where they were</span>
      </div>
      <button className="btn tiny secondary" onClick={onChange} style={{ flexShrink: 0 }}>Change storage…</button>
    </div>
  );
}

// =======================================================================
// Finding card — one document, all metadata + actions inline
// =======================================================================
function FindingCard({ f, keywords, onAccept, onReject }) {
  const relBucket = f.relevance >= 0.85 ? 'high' : f.relevance >= 0.7 ? 'med' : 'low';
  return (
    <article className="finding-card">
      <header className="finding-card-meta">
        <span className="finding-card-source">{f.sourceLabel}</span>
        <span className="finding-card-sep" aria-hidden="true">·</span>
        <span className="muted">{fmtDate(f.published)}</span>
        <span className="finding-card-sep" aria-hidden="true">·</span>
        <span className="muted">{f.docType} · {(f.sizeKb).toLocaleString('en-GB')} kB</span>
        <span className={'finding-card-relevance ' + relBucket}>
          {(f.relevance * 100).toFixed(0)}% relevance
        </span>
      </header>
      <h3 className="finding-card-title">{f.title}</h3>
      <p className="finding-card-summary">{f.summary}</p>
      <div className="finding-card-keywords">
        {f.keywords.map(kw => (
          <span key={kw} className={'finding-kw ' + (keywords.includes(kw) ? 'match' : '')}>{kw}</span>
        ))}
      </div>
      <div className="finding-card-actions">
        <button type="button" className="btn" onClick={() => onAccept(f)}>Add document</button>
        <button type="button" className="btn ghost" onClick={() => onReject(f)}>Reject</button>
      </div>
    </article>
  );
}

// =======================================================================
// Stored documents table — proves both artefacts (original + summary) exist
// =======================================================================
function StoredDocsTable({ docs }) {
  return (
    <table className="ingest-log">
      <thead>
        <tr>
          <th>Document</th>
          <th>Source</th>
          <th style={{ width: 140 }}>Stored at</th>
          <th>Artefacts</th>
          <th style={{ width: 130 }}>When</th>
        </tr>
      </thead>
      <tbody>
        {docs.map(d => (
          <tr key={d.findingId + d.storedAt}>
            <td><strong>{d.title}</strong></td>
            <td>{d.source}</td>
            <td><span className="kind-badge">{storageShort(d.location)}</span></td>
            <td>
              {d.artefacts.map((a, i) => (
                <div key={i} style={{ fontSize: 'var(--t-14)' }}>
                  <span className={'log-action ' + (a.kind === 'original' ? 'queued' : 'ingested')} style={{ marginRight: 6 }}>
                    {a.kind}
                  </span>
                  <code>{a.path}</code>
                  <span className="muted"> · {a.sizeKb.toLocaleString('en-GB')} kB</span>
                </div>
              ))}
            </td>
            <td className="muted">{new Date(d.storedAt).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

// =======================================================================
// Draft Issues panel — created during ingest; tracked here; pushable to GitHub
// =======================================================================
function DraftIssuesPanel({ issues, liveCount, storage, onPush, onDismiss, onClearAll }) {
  if (issues.length === 0) {
    return <WorkflowExplainer storage={storage} />;
  }
  return (
    <div>
      <WorkflowExplainer storage={storage} />
      <div className="draft-issue-actions">
        <span className="muted">{liveCount} active · {issues.length - liveCount} dismissed</span>
        <button type="button" className="research-link" onClick={onClearAll}>Clear tracker</button>
      </div>
      <ul className="draft-issue-list">
        {issues.map(i => (
          <li key={i.id} className="draft-issue-item">
            <div className="draft-issue-row">
              <span className={'ccd-tag ' + (i.status === 'pushed' ? 'green' : i.status === 'dismissed' ? 'grey' : 'amber')}>
                {i.status.toUpperCase()}
              </span>
              <span className="draft-issue-title">{i.title}</span>
              <span className="draft-issue-time muted">
                {new Date(i.createdAt).toLocaleString('en-GB', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <p className="draft-issue-body">{i.body}</p>
            <p className="draft-issue-from muted">From: {i.findingTitle}</p>
            {i.githubUrl && (
              <p><a href={i.githubUrl} target="_blank" rel="noopener noreferrer">{i.githubUrl}</a></p>
            )}
            {i.status === 'draft' && (
              <div className="draft-issue-buttons">
                <button type="button" className="btn" onClick={() => onPush(i)}
                  disabled={storage.kind !== 'github'}
                  title={storage.kind === 'github' ? 'Push to ' + storage.github.repo : 'Switch storage to GitHub first'}>
                  Push to GitHub
                </button>
                <button type="button" className="btn ghost" onClick={() => onDismiss(i)}>Dismiss</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

// =======================================================================
// Workflow explainer — answers the user's real-world question
// =======================================================================
function WorkflowExplainer({ storage }) {
  const isGithub = storage.kind === 'github';
  return (
    <div className="no-write-note" style={{ marginTop: 'var(--s-3)', alignItems: 'flex-start' }}>
      <span className="lock-icon">ℹ︎</span>
      <div>
        <strong>Where do draft issues live, and what happens next?</strong>
        <ol style={{ margin: '6px 0 0 0', paddingLeft: 18, lineHeight: 1.55 }}>
          <li>
            <strong>Stored in this dashboard</strong> (browser <code>localStorage</code> · key <code>{LS_DRAFT_ISSUES}</code>) until you act on them.
            They survive page reloads on this machine — to share, push to GitHub.
          </li>
          <li>
            <strong>Push to GitHub:</strong> {isGithub
              ? <>creates a real issue in <code>{storage.github.repo}</code> via the GitHub Issues REST API (<code>POST /repos/{'{owner/repo}'}/issues</code>) using the PAT stored in your storage config.</>
              : <>currently disabled — switch storage to <em>GitHub</em> to enable. Local & Blob storage keep issues here only.</>}
          </li>
          <li><strong>Triage:</strong> Engineering reviews the issue in the weekly carbon review, assigns an owner and labels by area (scheduler, budgets, regions…).</li>
          <li><strong>Implementation:</strong> Owner opens a PR referencing the issue; CI runs the standard test pack + the carbon-gate check.</li>
          <li><strong>Review &amp; merge:</strong> Two maintainer approvals required; the issue auto-closes on merge. The Carbon Cost Dashboard's <em>Alignment</em> view re-evaluates on the next research scan and clears the gap.</li>
        </ol>
        <div style={{ marginTop: 8, fontSize: 'var(--t-14)' }}>
          The dashboard <strong>never modifies your code</strong>. All draft issues are advisory until a human picks them up.
        </div>
      </div>
    </div>
  );
}

// =======================================================================
// IngestFlowModal — the 5-step pipeline shown when user clicks "Add"
// =======================================================================
function IngestFlowModal({ finding, storage, onClose, onComplete }) {
  // Step state: 0=idle, 1=fetch, 2=summarise, 3=store, 4=align, 5=draft, 6=done
  const [step, setStep] = React.useState(0);
  const stepNames = ['Fetch full document', 'Generate Markdown summary', 'Store at ' + storageShort(storage), 'Run alignment check', 'File draft issues'];
  const aligned     = RESEARCH_ALIGNMENT.filter(a => a.kind === 'aligned');
  const gaps        = RESEARCH_ALIGNMENT.filter(a => a.kind === 'gap');
  const suggestions = RESEARCH_ALIGNMENT.filter(a => a.kind === 'suggestion');

  // Paths for the two artefacts at the chosen storage location
  const safeId = finding.id;
  const originalExt = finding.docType.toLowerCase() === 'pdf' ? '.pdf' : '.html';
  const paths = (() => {
    if (storage.kind === 'local') {
      return {
        original: storage.local.folder + safeId + originalExt,
        summary:  storage.local.folder + safeId + '.summary.md'
      };
    }
    if (storage.kind === 'azure-blob') {
      const base = (storage.azureBlob.account ? storage.azureBlob.account + '.blob.core.windows.net/' : '') + storage.azureBlob.container + '/' + storage.azureBlob.prefix;
      return { original: base + safeId + originalExt, summary: base + safeId + '.summary.md' };
    }
    return {
      original: storage.github.repo + '@' + storage.github.branch + ':' + storage.github.path + safeId + originalExt,
      summary:  storage.github.repo + '@' + storage.github.branch + ':' + storage.github.path + safeId + '.summary.md'
    };
  })();

  // Auto-advance through steps when started.
  const start = () => setStep(1);
  React.useEffect(() => {
    if (step >= 1 && step <= 5) {
      const t = setTimeout(() => setStep(step + 1), step === 3 ? 1100 : 800);
      return () => clearTimeout(t);
    }
  }, [step]);

  const finish = () => {
    const draftIssues = [
      ...gaps.map(a => ({ kind: 'gap', title: 'Gap: ' + a.area, body: a.finding + ' — ' + a.evidence })),
      ...suggestions.map(a => ({ kind: 'suggestion', title: 'Suggestion: ' + a.area, body: a.finding + ' — ' + a.evidence }))
    ];
    onComplete({
      artefacts: [
        { kind: 'original', path: paths.original, sizeKb: finding.sizeKb },
        { kind: 'summary',  path: paths.summary,  sizeKb: Math.max(8, Math.round(finding.sizeKb * 0.04)) }
      ],
      draftIssues
    });
    onClose();
  };

  return (
    <div className="modal-inner">
      <header className="modal-head">
        <div>
          <div className="modal-eyebrow">ADD RESEARCH DOCUMENT</div>
          <h2 className="modal-title">Ingest pipeline</h2>
          <p className="modal-sub">
            Five steps. Both the <strong>original document</strong> and a generated <strong>Markdown summary</strong> are stored at <strong>{storageLabel(storage)}</strong>. Any alignment gaps become draft issues in the tracker.
          </p>
        </div>
        <button className="modal-close" aria-label="Close" onClick={onClose}>×</button>
      </header>

      <div className="modal-body">
        <div style={{ padding: 'var(--s-3)', background: 'var(--gov-bg-3)', border: '1px solid var(--gov-border)', marginBottom: 'var(--s-3)' }}>
          <div style={{ fontWeight: 700 }}>{finding.title}</div>
          <div className="muted" style={{ fontSize: 'var(--t-14)' }}>
            {finding.sourceLabel} · {finding.docType} · {finding.sizeKb.toLocaleString('en-GB')} kB · published {fmtDate(finding.published)}
          </div>
        </div>

        <ol className="run-progress" style={{ marginTop: 0 }}>
          {stepNames.map((label, i) => {
            const sn = i + 1;
            const state = step >= sn ? (step > sn ? 'done' : 'active') : 'pending';
            return (
              <div key={label} className={'run-step ' + (state === 'pending' ? '' : 'on')}>
                <div className="run-step-dot" />
                <div>
                  <strong>{label}</strong>
                  {sn === 3 && step >= 3 && (
                    <div className="muted" style={{ fontSize: 'var(--t-14)' }}>
                      <div>original → <code>{paths.original}</code></div>
                      <div>summary → <code>{paths.summary}</code></div>
                    </div>
                  )}
                  {sn === 4 && step >= 4 && (
                    <div className="muted" style={{ fontSize: 'var(--t-14)' }}>
                      {aligned.length} aligned · {gaps.length} gaps · {suggestions.length} suggestions
                    </div>
                  )}
                  {sn === 5 && step >= 5 && (
                    <div className="muted" style={{ fontSize: 'var(--t-14)' }}>
                      {gaps.length + suggestions.length} draft issue{gaps.length + suggestions.length === 1 ? '' : 's'} prepared
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </ol>

        {step >= 6 && (
          <>
            <h3 className="settings-h" style={{ marginTop: 'var(--s-4)' }}>Alignment summary</h3>
            <AlignmentInline aligned={aligned} gaps={gaps} suggestions={suggestions} />
            <div className="no-write-note" style={{ marginTop: 'var(--s-3)' }}>
              <span className="lock-icon">🔒</span>
              <div>
                <strong>No codebase changes will be made.</strong>{' '}
                The {gaps.length + suggestions.length} item{gaps.length + suggestions.length === 1 ? '' : 's'} below will be filed as <strong>draft issues</strong> in the tracker on this page.
                {storage.kind === 'github'
                  ? <> You can push any of them to <code>{storage.github.repo}</code> from the tracker.</>
                  : <> Switch storage to GitHub if you want a one-click push to a real repo.</>}
              </div>
            </div>
          </>
        )}

        {step === 0 && (
          <div style={{ padding: 'var(--s-3)', background: 'var(--gov-bg-2)', border: '1px dashed var(--gov-border)', fontSize: 'var(--t-14)' }}>
            <strong>What this does:</strong> downloads the full {finding.docType} (~{finding.sizeKb.toLocaleString('en-GB')} kB), generates a Markdown summary with structured front-matter, stores both at <strong>{storageLabel(storage)}</strong>, runs the alignment check against the live utility, and files any gaps / suggestions as <strong>draft issues</strong> in this dashboard. Nothing is pushed to GitHub or your codebase automatically.
          </div>
        )}
      </div>

      <footer className="modal-foot">
        <button className="btn ghost" onClick={onClose}>Cancel</button>
        {step === 0 && <button className="btn" onClick={start}>Start ingest →</button>}
        {step >= 1 && step <= 5 && <button className="btn" disabled>Running…</button>}
        {step >= 6 && <button className="btn" onClick={finish}>Confirm &amp; file {gaps.length + suggestions.length} draft issue{gaps.length + suggestions.length === 1 ? '' : 's'}</button>}
      </footer>
    </div>
  );
}

function AlignmentInline({ aligned, gaps, suggestions }) {
  const sections = [
    { title: 'Aligned · ' + aligned.length,    items: aligned,    cls: 'aligned' },
    { title: 'Gaps · ' + gaps.length,          items: gaps,       cls: 'gap' },
    { title: 'Suggestions · ' + suggestions.length, items: suggestions, cls: 'suggestion' }
  ];
  return (
    <>
      {sections.map(s => (
        <div key={s.title} style={{ marginBottom: 'var(--s-3)' }}>
          <div style={{ fontSize: 'var(--t-12)', textTransform: 'uppercase', letterSpacing: '0.08em', color: 'var(--gov-text-muted)', fontWeight: 700, marginBottom: 6 }}>{s.title}</div>
          <ul className="alignment-list">
            {s.items.map((a, i) => (
              <li key={i} className={'alignment-row ' + s.cls}>
                <div className="alignment-icon">{s.cls === 'aligned' ? '✓' : s.cls === 'gap' ? '!' : '+'}</div>
                <div>
                  <span className={'alignment-tag ' + s.cls}>{s.cls}</span>
                  <div className="alignment-area">{a.area}</div>
                  <div className="alignment-finding">{a.finding}</div>
                </div>
                <div className="alignment-evidence">{a.evidence}</div>
              </li>
            ))}
          </ul>
        </div>
      ))}
    </>
  );
}

// =======================================================================
// StorageLocationModal — pick where research documents are stored
// =======================================================================
function StorageLocationModal({ value, onSave, onClose }) {
  const [draft, setDraft] = React.useState(value);
  const set = (patch) => setDraft(prev => ({ ...prev, ...patch }));
  const setSub = (key, patch) => setDraft(prev => ({ ...prev, [key]: { ...prev[key], ...patch } }));

  return (
    <div className="modal-inner">
      <header className="modal-head">
        <div>
          <div className="modal-eyebrow">RESEARCH STORAGE</div>
          <h2 className="modal-title">Where should accepted documents be stored?</h2>
          <p className="modal-sub">
            Switchable at any time. Existing artefacts stay at their original location — only future ingests go to the new target.
          </p>
        </div>
        <button className="modal-close" aria-label="Close" onClick={onClose}>×</button>
      </header>
      <div className="modal-body">
        <div className="form-grid">
          <div>
            <span className="form-label">Storage backend</span>
            <div className="chip-grid">
              {[
                { id: 'local',      label: 'Local folder',           sub: 'researchPaper/ in repo' },
                { id: 'azure-blob', label: 'Azure Blob Storage',     sub: 'enterprise · auditable · cheap' },
                { id: 'github',     label: 'GitHub repository',      sub: 'visible to all contributors · enables one-click issue push' }
              ].map(o => (
                <button key={o.id} type="button"
                  className={'chip ' + (draft.kind === o.id ? 'on' : '')}
                  onClick={() => set({ kind: o.id })}
                  style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', padding: '10px 14px', minWidth: 220 }}>
                  <span style={{ fontWeight: 700 }}>{o.label}</span>
                  <span style={{ fontSize: 'var(--t-12)', color: 'var(--gov-text-muted)', fontWeight: 400 }}>{o.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {draft.kind === 'local' && (
            <label>
              <span className="form-label">Folder path (repo-relative)</span>
              <input className="form-field" value={draft.local.folder}
                onChange={e => setSub('local', { folder: e.target.value })} />
              <div className="settings-field-tip">
                Path inside this repository. Default <code>researchPaper/</code> matches the existing layout.
                Documents are written as files in this folder when the Function App runs locally.
              </div>
            </label>
          )}

          {draft.kind === 'azure-blob' && (
            <>
              <label>
                <span className="form-label">Storage account</span>
                <input className="form-field" placeholder="greenqastorage" value={draft.azureBlob.account}
                  onChange={e => setSub('azureBlob', { account: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Container</span>
                <input className="form-field" value={draft.azureBlob.container}
                  onChange={e => setSub('azureBlob', { container: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Prefix</span>
                <input className="form-field" value={draft.azureBlob.prefix}
                  onChange={e => setSub('azureBlob', { prefix: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Authentication</span>
                <select className="form-field" value={draft.azureBlob.sasOrManagedIdentity}
                  onChange={e => setSub('azureBlob', { sasOrManagedIdentity: e.target.value })}>
                  <option value="managed-identity">Function App managed identity (recommended)</option>
                  <option value="sas">SAS token (kv:/green-qa/storage/blob-sas)</option>
                </select>
              </label>
              <div className="form-note">
                The Function App writes via the configured identity — your browser never holds credentials.
                Both <em>original</em> and <em>summary</em> artefacts are saved with content-type and source metadata as blob tags.
              </div>
            </>
          )}

          {draft.kind === 'github' && (
            <>
              <label>
                <span className="form-label">Repository (owner/repo)</span>
                <input className="form-field" value={draft.github.repo}
                  onChange={e => setSub('github', { repo: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Branch</span>
                <input className="form-field" value={draft.github.branch}
                  onChange={e => setSub('github', { branch: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Path</span>
                <input className="form-field" value={draft.github.path}
                  onChange={e => setSub('github', { path: e.target.value })} />
              </label>
              <label>
                <span className="form-label">Personal access token (PAT)</span>
                <input className="form-field" type="password" placeholder={draft.github.pat ? '•••••••• (saved)' : 'ghp_… · scopes: repo, write:issues'}
                  value={draft.github.pat}
                  onChange={e => setSub('github', { pat: e.target.value })} />
                <div className="settings-field-tip">
                  Stored in your browser only. In a real deployment this lives in Key Vault and the Function App proxies the call.
                  Scopes required: <code>repo</code> (to commit artefacts) and <code>write:issues</code> (to push draft issues).
                </div>
              </label>
              <div className="form-note">
                Choosing GitHub also enables one-click <strong>Push to GitHub</strong> on draft issues. Files are committed to the chosen branch via the Contents API; issues are created via <code>POST /repos/{'{owner/repo}'}/issues</code>.
              </div>
            </>
          )}
        </div>
      </div>
      <footer className="modal-foot">
        <button className="btn ghost" onClick={onClose}>Cancel</button>
        <button className="btn" onClick={() => { onSave(draft); onClose(); }}>Save storage target</button>
      </footer>
    </div>
  );
}

// =======================================================================
// SchedulerModal — interval, keywords, parallelism, timeout
// =======================================================================
function SchedulerModal({ intervalDays, setIntervalDays, keywords, setKeywords, onClose }) {
  const { toast } = useStore();
  const [draftInterval, setDraftInterval] = React.useState(intervalDays);
  const [draftKeywords, setDraftKeywords] = React.useState(keywords.join(', '));
  const [draftTimeout, setDraftTimeout]   = React.useState(RESEARCH_SCHEDULE.timeoutSec);
  const [draftPar, setDraftPar]           = React.useState(RESEARCH_SCHEDULE.parallelism);

  const save = () => {
    setIntervalDays(draftInterval);
    setKeywords(draftKeywords.split(',').map(s => s.trim()).filter(Boolean));
    onClose();
    toast({
      kind: 'success',
      title: 'Research watcher updated',
      message: 'Schedule: every ' + draftInterval + ' day' + (draftInterval === 1 ? '' : 's') + ' · ' + draftKeywords.split(',').length + ' keywords',
      detail: 'Next scan will pick up the new configuration'
    });
  };

  return (
    <div className="modal-inner">
      <header className="modal-head">
        <div>
          <div className="modal-eyebrow">RESEARCH WATCHER</div>
          <h2 className="modal-title">Configure schedule &amp; filters</h2>
          <p className="modal-sub">
            Pick how often the watcher runs and what it considers relevant. All settings persist per-installation.
          </p>
        </div>
        <button className="modal-close" aria-label="Close" onClick={onClose}>×</button>
      </header>
      <div className="modal-body">
        <h3 className="settings-h">Schedule</h3>
        <div className="settings-grid">
          <SettingsField label="Interval" unit="days" tip="Default 7 days. Lower = more frequent · 1 = daily · 30 = monthly.">
            <input className="form-field" type="number" min="1" max="60" value={draftInterval}
              onChange={e => setDraftInterval(+e.target.value)} />
          </SettingsField>
          <SettingsField label="Per-source timeout" unit="seconds" tip="Sources that don't respond within this window are skipped — the rest of the scan continues.">
            <input className="form-field" type="number" min="2" max="60" value={draftTimeout}
              onChange={e => setDraftTimeout(+e.target.value)} />
          </SettingsField>
        </div>

        <h3 className="settings-h">Parallel fetch</h3>
        <div className="settings-grid">
          <SettingsField label="Parallelism" unit="concurrent sources" tip="How many sources to scan at once.">
            <input className="form-field" type="number" min="1" max="10" value={draftPar}
              onChange={e => setDraftPar(+e.target.value)} />
          </SettingsField>
        </div>

        <h3 className="settings-h">Keyword pre-filter</h3>
        <div className="settings-field">
          <div className="settings-field-head">
            <label className="form-label" style={{ marginBottom: 0 }}>Keywords</label>
            <span className="settings-field-unit">comma-separated</span>
          </div>
          <textarea className="form-field" rows="3" value={draftKeywords}
            onChange={e => setDraftKeywords(e.target.value)} />
          <div className="settings-field-tip">
            Applied to title, abstract and metadata tags. Documents that don't match at least one keyword are skipped at the metadata stage — full content is never downloaded.
          </div>
        </div>

        <div className="no-write-note" style={{ marginTop: 'var(--s-4)' }}>
          <span className="lock-icon">🔒</span>
          <div>
            <strong>Source allow-list is locked.</strong>{' '}
            New sources cannot be added from this UI — only audited EU / UK government endpoints qualify.
            Open a PR against <code>config/research_sources.yaml</code> to propose changes.
          </div>
        </div>
      </div>
      <footer className="modal-foot">
        <button className="btn ghost" onClick={onClose}>Cancel</button>
        <button className="btn" onClick={save}>Save configuration</button>
      </footer>
    </div>
  );
}

function SettingsField({ label, unit, tip, children }) {
  return (
    <div className="settings-field">
      <div className="settings-field-head">
        <label className="form-label" style={{ marginBottom: 0 }}>{label}</label>
        {unit && <span className="settings-field-unit">{unit}</span>}
      </div>
      {children}
      {tip && <div className="settings-field-tip">{tip}</div>}
    </div>
  );
}

// expose
Object.assign(window, {
  ResearchWatcherPanel,
  IngestFlowModal,
  StorageLocationModal,
  SchedulerModal
});
