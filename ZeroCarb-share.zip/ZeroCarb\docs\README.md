# Green QA Platform — Documentation Pack

This folder is a drop-in documentation set for the **Green QA Platform**
(`green-qa-platform/` repository). Copy the whole `docs/` folder into the
repo root.

Read in this order:

| # | File | Audience | What's in it |
|---|---|---|---|
| 1 | [`USER_GUIDE.md`](./USER_GUIDE.md) | Anyone | End-to-end walkthrough — what the utility does, who it's for, what every tab is, the daily / weekly / monthly / research workflows |
| 2 | [`DATA_SOURCES.md`](./DATA_SOURCES.md) | Anyone | Which screens/figures are **live API data** vs **demo fixtures**, with file-level provenance |
| 3 | [`EXTERNAL_APIS.md`](./EXTERNAL_APIS.md) | Engineers, security | Full inventory of third-party endpoints we call: URL, auth, quotas, fallback chain, response shape |
| 4 | [`INFRASTRUCTURE.md`](./INFRASTRUCTURE.md) | Cloud / platform | Azure resources we provision, SKUs, networking, RBAC, monthly cost |
| 5 | [`SETUP.md`](./SETUP.md) | Engineers | Local dev, environment variables, secrets, config files |
| 6 | [`DEPLOYMENT_AZURE.md`](./DEPLOYMENT_AZURE.md) | DevOps | Prereqs → infra → code → post-deploy validation, with rollback |
| 7 | [`RESEARCH_FLOW.md`](./RESEARCH_FLOW.md) | Operators, engineers | What happens when a user clicks **Add** on a research finding — storage choices, the 5-step ingest pipeline, draft issues, push-to-GitHub workflow |
| 8 | [`TESTING.md`](./TESTING.md) | QA / engineers | Unit, integration, smoke, load, chaos; how to run each |

---

## TL;DR — Is the dashboard real?

**No.** The HTML prototype (`Carbon Cost Dashboard.html`) renders entirely
from `data.js` fixtures. **The backend** (`green_qa_lib/`, `azure/functions/`)
*does* fetch live data from UK Grid ESO, ElectricityMaps and Ember Climate —
the dashboard just isn't yet wired to call it. See
[`DATA_SOURCES.md`](./DATA_SOURCES.md) for the line-by-line breakdown and
[`EXTERNAL_APIS.md`](./EXTERNAL_APIS.md) for what's already implemented
server-side.

## TL;DR — Can we deploy this to Azure today?

**Yes**, as a working prototype. The repo already ships:

- `infrastructure/azure/main.bicep` — full Bicep template (Cosmos, Functions, Static Web App, Key Vault, App Insights, Storage)
- `azure/functions/` — Python v2 Functions app with `/api/decide`, `/api/calculate`, `/api/budget/check`, `/api/history`, timer triggers
- `dashboard/public/` — static SPA target for Static Web Apps

The 4-step deployment is in [`DEPLOYMENT_AZURE.md`](./DEPLOYMENT_AZURE.md).

## What's not production-ready

See `GAPS.md` in the repo root (already maintained). The short list:

- Workload Identity Federation instead of SP secrets (currently uses SP + secret in KV)
- Zero-trust API auth on `/api/*` (currently Function-level keys only)
- Carbon data lineage in responses (source / method / PUE attribution)
- α-fairness and cost-ceiling guards in scheduling
- Cryptographic signing of emitted carbon figures for ESG audit

None of these block a pilot deployment; all should land before customer GA.
