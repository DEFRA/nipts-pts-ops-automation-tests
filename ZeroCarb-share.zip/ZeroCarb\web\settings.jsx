/* global React, useStore */
// =======================================================================
// Settings & Polling
//  - SettingsModal: configure polling, test interval, retries, alerts
//  - usePolling: in-prototype heartbeat (counts down to next refresh,
//                triggers data refresh, drives the live indicator)
//  - useBackgroundTests: drives the synthetic test runner ticks
// =======================================================================

const DEFAULT_CONFIG = {
  pollingMinutes: 10,        // dashboard data refresh
  testIntervalMinutes: 5,    // background synthetic carbon test cadence
  retryAttempts: 3,
  retryBackoffSeconds: 30,
  alertThresholdPct: 85,     // % of budget that triggers alert
  failBuildOnBreach: true,
  alertChannels: ['email', 'slack'],
  region: 'uksouth',
  serviceName: 'green-qa-utility',
  environment: 'prod'
};

// expose immediately so other files can read it before settings.jsx finishes parsing
window.DEFAULT_CONFIG = DEFAULT_CONFIG;

function ConfigProvider({ children }) {
  const [config, setConfig] = React.useState(() => {
    try {
      const stored = localStorage.getItem('ccd-config');
      return stored ? { ...DEFAULT_CONFIG, ...JSON.parse(stored) } : DEFAULT_CONFIG;
    } catch (e) { return DEFAULT_CONFIG; }
  });
  React.useEffect(() => {
    try { localStorage.setItem('ccd-config', JSON.stringify(config)); }
    catch (e) { /* ignore */ }
  }, [config]);
  return (
    <ConfigContext.Provider value={[config, setConfig]}>{children}</ConfigContext.Provider>
  );
}
const ConfigContext = React.createContext([DEFAULT_CONFIG, () => {}]);
function useConfig() { return React.useContext(ConfigContext); }

// ---------- Polling hook ----------
function usePolling(intervalMinutes, onTick) {
  const [secondsToNext, setSecondsToNext] = React.useState(intervalMinutes * 60);
  const [isPolling, setIsPolling] = React.useState(true);
  const [lastTickAt, setLastTickAt] = React.useState(() => new Date());
  const onTickRef = React.useRef(onTick);
  onTickRef.current = onTick;

  React.useEffect(() => {
    setSecondsToNext(intervalMinutes * 60);
  }, [intervalMinutes]);

  React.useEffect(() => {
    if (!isPolling) return;
    const id = setInterval(() => {
      setSecondsToNext(s => {
        if (s <= 1) {
          // tick — refresh
          setLastTickAt(new Date());
          try { onTickRef.current && onTickRef.current(); } catch (e) { console.error(e); }
          return intervalMinutes * 60;
        }
        return s - 1;
      });
    }, 1000);
    return () => clearInterval(id);
  }, [isPolling, intervalMinutes]);

  const forceRefresh = React.useCallback(() => {
    setLastTickAt(new Date());
    setSecondsToNext(intervalMinutes * 60);
    try { onTickRef.current && onTickRef.current(); } catch (e) {}
  }, [intervalMinutes]);

  return { secondsToNext, isPolling, setIsPolling, forceRefresh, lastTickAt };
}

// ---------- Settings Modal ----------
function SettingsModal({ onClose }) {
  const { toast } = useStore();
  const [config, setConfig] = useConfig();
  const [draft, setDraft] = React.useState(config);

  const change = (k, v) => setDraft(prev => ({ ...prev, [k]: v }));
  const save = () => {
    setConfig(draft);
    onClose();
    toast({
      kind: 'success',
      title: 'Settings saved',
      message: 'Polling: every ' + draft.pollingMinutes + ' min · Tests: every ' + draft.testIntervalMinutes + ' min',
      detail: 'Persisted to localStorage · will be re-read on next page load'
    });
  };
  const reset = () => setDraft(DEFAULT_CONFIG);

  return (
    <div className="modal-inner">
      <header className="modal-head">
        <div>
          <div className="modal-eyebrow">UTILITY CONFIGURATION</div>
          <h2 className="modal-title">Settings &amp; Operations</h2>
          <p className="modal-sub">Configure polling, retries, the budget gate, and deployment defaults.</p>
        </div>
        <button className="modal-close" aria-label="Close" onClick={onClose}>×</button>
      </header>
      <div className="modal-body">
        <h3 className="settings-h">Polling &amp; refresh</h3>
        <div className="settings-grid">
          <SettingsField
            label="Dashboard polling interval"
            unit="minutes"
            tip="How often the dashboard fetches fresh carbon data."
          >
            <input type="number" min="1" max="120" className="form-field"
              value={draft.pollingMinutes}
              onChange={e => change('pollingMinutes', +e.target.value)} />
          </SettingsField>

          <SettingsField
            label="Background test interval"
            unit="minutes"
            tip="Cadence for synthetic carbon tests."
          >
            <input type="number" min="1" max="60" className="form-field"
              value={draft.testIntervalMinutes}
              onChange={e => change('testIntervalMinutes', +e.target.value)} />
          </SettingsField>
        </div>

        <h3 className="settings-h">Resilience</h3>
        <div className="settings-grid">
          <SettingsField label="Retry attempts" unit="" tip="On failed API calls to upstream services.">
            <input type="number" min="0" max="10" className="form-field"
              value={draft.retryAttempts}
              onChange={e => change('retryAttempts', +e.target.value)} />
          </SettingsField>
          <SettingsField label="Backoff" unit="seconds" tip="Exponential backoff between retries.">
            <input type="number" min="5" max="600" className="form-field"
              value={draft.retryBackoffSeconds}
              onChange={e => change('retryBackoffSeconds', +e.target.value)} />
          </SettingsField>
        </div>

        <h3 className="settings-h">Budget gate</h3>
        <div className="settings-grid">
          <SettingsField label="Alert threshold" unit="% of budget" tip="Warn when a run reaches this share of budget.">
            <input type="number" min="1" max="100" className="form-field"
              value={draft.alertThresholdPct}
              onChange={e => change('alertThresholdPct', +e.target.value)} />
          </SettingsField>
          <SettingsField label="Fail build on breach" unit="" tip="Fail CI when a run exceeds 100% of budget.">
            <label className="settings-toggle">
              <input type="checkbox" checked={draft.failBuildOnBreach}
                onChange={e => change('failBuildOnBreach', e.target.checked)} />
              <span>{draft.failBuildOnBreach ? 'Enabled' : 'Disabled (warn-only mode)'}</span>
            </label>
          </SettingsField>
        </div>

        <h3 className="settings-h">Deployment</h3>
        <div className="settings-grid">
          <SettingsField label="Environment" unit="" tip="Tag applied to metric exports.">
            <select className="form-field" value={draft.environment}
              onChange={e => change('environment', e.target.value)}>
              <option value="dev">dev</option>
              <option value="staging">staging</option>
              <option value="prod">prod</option>
            </select>
          </SettingsField>
          <SettingsField label="Default region" unit="" tip="Used when no region is pinned to a pipeline.">
            <input className="form-field" value={draft.region}
              onChange={e => change('region', e.target.value)} />
          </SettingsField>
        </div>

      </div>
      <footer className="modal-foot">
        <button className="btn ghost" onClick={reset}>Reset to defaults</button>
        <button className="btn secondary" onClick={onClose}>Cancel</button>
        <button className="btn" onClick={save}>Save settings</button>
      </footer>
    </div>
  );
}

function SettingsField({ label, unit, tip, children }) {
  return (
    <div className="settings-field">
      <div className="settings-field-head">
        <label className="form-label" style={{ marginBottom: 0 }}>{label}</label>
        {unit && <span className="settings-field-unit">{unit}</span>}
      </div>
      {children}
      {tip && <div className="settings-field-tip">{tip}</div>}
    </div>
  );
}

window.SettingsModal = SettingsModal;
window.ConfigProvider = ConfigProvider;
window.useConfig = useConfig;
window.usePolling = usePolling;
