import { envStr } from '../config';

export interface DcMetrics {
  pue: number;
  wue_l_per_kwh: number;
  renewable_pct: number;
}

export interface Region {
  code: string;
  display_name: string;
  country_code: string;
  electricitymaps_zone: string;
  latitude: number;
  longitude: number;
  dc_metrics: DcMetrics;
}

const r = (
  code: string, display_name: string, country_code: string, electricitymaps_zone: string,
  latitude: number, longitude: number, pue: number, wue: number, renewable: number,
): Region => ({
  code, display_name, country_code, electricitymaps_zone, latitude, longitude,
  dc_metrics: { pue, wue_l_per_kwh: wue, renewable_pct: renewable },
});

// Kept in lock-step with web/data.js REGIONS[].
const AZURE_REGIONS: Region[] = [
  r('northeurope', 'North Europe', 'IE', 'IE', 53.349, -6.26, 1.185, 0.49, 0.46),
  r('westeurope', 'West Europe', 'NL', 'NL', 52.379, 4.9, 1.185, 0.49, 0.38),
  r('uksouth', 'UK South', 'GB', 'GB', 51.507, -0.128, 1.185, 0.49, 0.52),
  r('ukwest', 'UK West', 'GB', 'GB', 51.483, -3.169, 1.185, 0.49, 0.5),
  r('francecentral', 'France Central', 'FR', 'FR', 48.857, 2.353, 1.185, 0.49, 0.27),
  r('germanywestcentral', 'Germany West Central', 'DE', 'DE', 50.11, 8.682, 1.185, 0.49, 0.49),
  r('italynorth', 'Italy North', 'IT', 'IT', 45.464, 9.19, 1.185, 0.49, 0.42),
  r('swedencentral', 'Sweden Central', 'SE', 'SE-SE3', 60.674, 17.141, 1.15, 0.49, 0.71),
  r('norwayeast', 'Norway East', 'NO', 'NO-NO1', 59.913, 10.752, 1.15, 0.49, 0.93),
  r('switzerlandnorth', 'Switzerland North', 'CH', 'CH', 47.376, 8.541, 1.185, 0.49, 0.62),
  r('polandcentral', 'Poland Central', 'PL', 'PL', 52.23, 21.012, 1.185, 0.49, 0.21),
  r('spaincentral', 'Spain Central', 'ES', 'ES', 40.416, -3.703, 1.185, 0.49, 0.51),
];

const AWS_REGIONS: Region[] = [
  r('eu-west-1', 'Europe (Ireland)', 'IE', 'IE', 53.349, -6.26, 1.135, 0.18, 0.46),
  r('eu-west-2', 'Europe (London)', 'GB', 'GB', 51.507, -0.128, 1.135, 0.18, 0.52),
  r('eu-west-3', 'Europe (Paris)', 'FR', 'FR', 48.857, 2.353, 1.135, 0.18, 0.27),
  r('eu-north-1', 'Europe (Stockholm)', 'SE', 'SE-SE3', 59.329, 18.069, 1.1, 0.18, 0.71),
  r('eu-central-1', 'Europe (Frankfurt)', 'DE', 'DE', 50.11, 8.682, 1.135, 0.18, 0.49),
];

export interface Provider {
  name: string;
  regions: Region[];
  listRegions(): Region[];
  defaultRegion(): string;
}

function makeProvider(name: string, regions: Region[], defaultCode: string): Provider {
  return {
    name,
    regions,
    listRegions: () => [...regions],
    defaultRegion: () => defaultCode || regions[0]?.code || '',
  };
}

const PROVIDERS: Record<string, Provider> = {
  azure: makeProvider('azure', AZURE_REGIONS, 'uksouth'),
  aws: makeProvider('aws', AWS_REGIONS, 'eu-west-2'),
};

export function getProvider(name: string): Provider {
  const key = (name || '').toLowerCase();
  const p = PROVIDERS[key];
  if (!p) {
    throw new Error(`Unknown provider: '${name}'. Supported: ${JSON.stringify(Object.keys(PROVIDERS).sort())}`);
  }
  return p;
}

// Where a pipeline can physically RUN (a regional agent pool exists there).
const DEFAULT_EXECUTION_REGIONS: Record<string, string[]> = {
  azure: ['uksouth', 'ukwest'],
  aws: ['eu-west-2'],
};

/** Override with GREENQA_EXECUTION_REGIONS; codes unknown to the provider are dropped. */
export function executionRegions(providerName = 'azure'): string[] {
  const raw = envStr('GREENQA_EXECUTION_REGIONS').trim();
  const codes = raw
    ? raw.split(',').map((c) => c.trim()).filter(Boolean)
    : [...(DEFAULT_EXECUTION_REGIONS[(providerName || '').toLowerCase()] ?? [])];
  let valid: Set<string>;
  try {
    valid = new Set(getProvider(providerName).listRegions().map((x) => x.code));
  } catch {
    return [];
  }
  return codes.filter((c) => valid.has(c));
}
