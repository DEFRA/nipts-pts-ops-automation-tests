# Carbon Cost Dashboard — User Guide

A complete walkthrough of the utility, who it's for, what every screen does,
and the workflows it enables. Written for product owners, engineering
managers, sustainability leads and new platform engineers.

---

## 1 · What this utility is

The **Carbon Cost Dashboard** integrates GreenOps into the CI/CD pipeline.
Every time one of your build / test / deploy pipelines runs, we estimate
the **grams of CO₂** that run produced, attribute it to a team and
pipeline, and decide whether the run is within its **carbon budget**.

It does three things that are individually unremarkable but together change
how an engineering org thinks about its emissions:

1. **Measures.** Every pipeline run is costed using the Green Software
   Foundation's SCI formula. Numbers, not vibes.
2. **Decides.** A four-step decision tree (the MAIZX framework) picks
   between running now, deferring, re-routing to a cleaner region, or
   doing both.
3. **Enforces.** Builds that exceed budget fail at the gate — the same
   way a failing unit test or breached SLO would. Overrides are allowed
   but logged.

Around these three loops we expose: a live regions view, a research
watcher that surfaces new gov/research publications, a glossary, and the
operational plumbing (Azure connect, Key Vault, deployment).

---

## 2 · Who it's for, by role

| Role | What they get out of it |
|---|---|
| **Sustainability lead / ESG officer** | Auditable per-team carbon ledger, ready for CSRD / ESRS E1 reporting. Monthly digests, override visibility. |
| **Engineering manager** | A scoreboard. Sees which pipelines are costing the team carbon, can drill into the per-transaction breakdown, set budgets. |
| **Platform / DevOps engineer** | The runtime that schedules pipelines carbon-aware, plus the dashboard to verify the gate behaves correctly. |
| **Individual contributor** | An honest signal in their PR: "this pipeline produced 21.6 g CO₂ — 20% over budget, recommend SPACE_SHIFT to France Central". |
| **Compliance / audit** | Source provenance, methodology references, immutable log trail, RBAC matrix on the Azure connection. |

---

## 3 · The dashboard, screen by screen

There are **five tabs**, hash-routed (`#/overview`, `#/pipelines`, …).
Each tab is a discrete concern; you can deep-link any of them.

### 3.1 Overview

The landing page. A masthead **Ledger** strip shows the headline KPIs:

- Total carbon emitted this period
- Carbon avoided through MAIZX decisions
- Number of pipelines over budget
- "Equivalences" — how the figure compares to driving, flights or trees

Underneath: four jump-cards into the other tabs.

### 3.2 Pipelines

The core operational view.

A table of every CI/CD pipeline connected to the dashboard. Each row
shows: pipeline name, owning team, criticality tier, region, **grid
carbon intensity (gCO₂/kWh)**, gCO₂ per run, budget, 7-day trend
sparkline, MAIZX strategy, build status, and (optionally) the dollar
cost per run.

Above the table is the **Intensity chart** — a sorted horizontal bar
chart that puts every pipeline next to every other on a single scale of
grid carbon intensity. Coloured by clean / moderate / high / dirty
bucket. It's the at-a-glance answer to "which pipelines are running on
a dirty grid?"

Click any pipeline row to expand the **drill-down**:

| Panel | What it does |
|---|---|
| Per-transaction carbon | Breaks the run into its constituent transactions (login flow, checkout intent, …) with carbon per call × call count |
| MAIZX recommendation | Names the chosen strategy with a 1-line reason and the **From → Recommend** region diff. Three action buttons: Apply, Run now, Override budget |
| Build receipt | SCI breakdown (operational, embodied, energy / cost), region + PUE, and a "If routed via X, you'd save Y g" footer |

Actions available from the drill-down:

- **Apply recommendation** — opens a modal showing the carbon delta and confirms a config-as-code PR is opened against the pipeline definition.
- **Run now** — opens the carbon-aware scheduler. Walks through the 4-step decision tree, then queues the build.
- **Override budget** — file a reasoned exception. Logged with reason, requester and expiry.

### 3.3 Regions

The state of every Azure region we know about, plus a 24h carbon
intensity forecast for the home region. Use this when:

- You're deciding which region a new pipeline should run in.
- You want to time a big batch job for the cleanest window.
- You're explaining to a stakeholder why "moving the workload to
  France" actually matters.

The forecast curve comes from ElectricityMaps + a calibrated Ember
fallback (see `docs/EXTERNAL_APIS.md` §2).

### 3.4 Research

A background job that scans a curated allow-list of EU/UK government
publications (gov.uk, defra, JRC, EEA, …) and surfaces new documents
relevant to sustainable software.

Detailed flow in `docs/RESEARCH_FLOW.md`. The short version:

1. Operator picks a **storage target** — local folder, Azure Blob or
   GitHub repo. Switchable any time.
2. The scheduler runs every N days (default 7).
3. When new documents are found, the user is asked to **Add** or
   **Reject** each one. Decisions persist across reloads — the same
   document is never resurfaced.
4. **Add** runs a 5-step pipeline: fetch → summarise → store (both
   original + Markdown summary) → run alignment check → file draft
   issues.
5. Draft issues live in the in-app tracker. Push them to GitHub (only
   when storage = GitHub) to start the real-world triage process.

### 3.5 Glossary

Plain-English definitions for every term used in the platform.
Searchable, cross-linked, organised into five sections. Aimed at
non-technical readers and onboarding engineers.

---

## 4 · Workflows — end-to-end

### 4.1 First-run setup

```mermaid
flowchart LR
  A[Deploy infra<br/>(Bicep)] --> B[Function App<br/>boots]
  B --> C[Open dashboard]
  C --> D[Click "Connect Azure" chip]
  D --> E[Enter SP credentials<br/>+ pick RBAC scope]
  E --> F[Verify · 10 pipelines<br/>discovered]
  F --> G[First scan job runs<br/>30-min timer trigger]
  G --> H[Live data in dashboard]
```

Pre-requisites: an Azure subscription, a service principal with at
minimum Reader role, an ElectricityMaps token (or accept the free tier
for now). Full steps in `docs/DEPLOYMENT_AZURE.md`.

### 4.2 The daily loop — engineer-facing

```
push code
  ↓
CI pipeline starts
  ↓
carbon ingestion runs → estimates kWh × intensity
  ↓
carbon gate decides → pass | warn | fail
  ↓
build status posted to PR
  ↓
if fail → engineer fixes (region, schedule, code), or files override
```

The dashboard's job is to make this loop visible. The carbon-gate
verdict is no different from a failing test from the engineer's point
of view.

### 4.3 The weekly loop — manager-facing

1. Weekly digest lands in inbox / Slack (Monday 09:00 by default).
2. Manager reviews the team's leaderboard rank.
3. Drills into pipelines that breached budget or saw a trend swing.
4. Acts on a MAIZX recommendation (apply, override, or escalate) — or
   updates budgets if the baseline has moved.

### 4.4 The monthly loop — sustainability/ESG-facing

1. Ledger export → carbon emitted per team / pipeline / region.
2. Override audit — every reasoned exception, with reason and outcome.
3. Cross-check against CSRD ESRS E1 disclosure template.
4. Publish quarterly bundle (planned — see `GAPS.md` C.6).

### 4.5 The research loop — strategy-facing

1. Background scan finds new gov publications (every 7 days).
2. Operator reviews **Pending findings** — accepts what's relevant.
3. Accept runs the 5-step pipeline: original + summary stored, alignment
   check runs, gaps and suggestions become **draft issues**.
4. Operator triages drafts; pushes to GitHub when ready.
5. Engineering reviews in the weekly carbon review; opens PRs.
6. Next scan re-evaluates alignment; gaps close on merge.

Full details in `docs/RESEARCH_FLOW.md`.

---

## 5 · How carbon is actually calculated

The dashboard uses the **GSF SCI formula**:

```
SCI = (E × I) + M
```

- **E** — energy used by the run, in kWh. Estimated from vCPU-seconds,
  RAM-GB-seconds, and the Teads.io power model.
- **I** — carbon intensity of the grid serving the data centre, in
  gCO₂/kWh. Live from NESO for GB, ElectricityMaps for everywhere else,
  Ember as fallback.
- **M** — embodied carbon, amortised over the server's expected
  lifetime (typically 4 years, ~30,000 jobs).

The dashboard reports the total as `g CO₂ / run`. The drill-down shows
both the E×I and M components separately.

For shifting decisions, we use the same intensity number but also
compute the **marginal** intensity (the carbon avoided/added by adding
one more kWh of load right now). Marginal CI is the academically
correct number for scheduling — see the JRC alignment in the
Research watcher for the live recommendation.

---

## 6 · Configuration

| What | Where | Default |
|---|---|---|
| Home region | Tweaks → Routing → Home region | `uksouth` |
| Polling cadence | Settings (gear icon) → Polling | 5 minutes |
| Theme / density / show-cost | Tweaks panel (bottom-right) | GOV.UK / Comfortable / $ shown |
| Research scan interval | Research tab → Configure schedule | 7 days |
| Research storage target | Research tab → Change storage… | Local folder `researchPaper/` |
| Per-pipeline budget | Pipeline drill-down → Override / set | 75th-percentile of last 30 d |
| Service-principal scope | Connect Azure modal | Reader |

All UI tweaks persist to `localStorage`. Server-side config lives in
Bicep parameters (`infrastructure/azure/main.parameters.example.json`)
and Key Vault for secrets.

---

## 7 · What this utility does NOT do

- **Modify your codebase.** Alignment gaps surface as draft issues, never as commits.
- **Push to GitHub without your explicit click.** Storage backend = GitHub is required, and the Push button is opt-in per issue.
- **Re-suggest documents the user has already decided on.** Accepts and rejects persist forever (unless the user clicks "Reset decisions").
- **Take down a build for being over budget without an audit trail.** Every gate decision is logged; overrides are first-class.
- **Replace your APM.** Latency, error rate, throughput — all live in App Insights / Datadog / whatever. The dashboard sits next to them.

---

## 8 · Deploy & operate — pointer index

| Topic | Doc |
|---|---|
| Local dev, env vars, secrets | `docs/SETUP.md` |
| Azure resources, SKUs, RBAC, cost | `docs/INFRASTRUCTURE.md` |
| Deployment (pre / infra / code / post) | `docs/DEPLOYMENT_AZURE.md` |
| Testing — unit / integration / smoke / load / chaos | `docs/TESTING.md` |
| External APIs we depend on | `docs/EXTERNAL_APIS.md` |
| Live vs demo data clarity | `docs/DATA_SOURCES.md` |
| Research watcher Accept/Reject flow | `docs/RESEARCH_FLOW.md` |
| Known gaps (not yet production-ready) | `GAPS.md` |
| Operations runbook | `OPERATIONS.md` |
| Deploy quick-start | `DEPLOYMENT.md` |

---

## 9 · Glossary (in-app & here)

Every term you'll encounter — gCO₂, SCI, MAIZX, TIME_SHIFT, SPACE_SHIFT,
PUE, scope 3, embodied, NESO, ElectricityMaps, draft issue, alignment
check — has a plain-English entry in the **Glossary** tab. Search, jump
between related terms, share a deep link.

---

## 10 · Credits & references

- **Green Software Foundation** — SCI specification
- **MAIZX framework** — KTH/NTNU 2024
- **α-fair scheduling** — Inria research line
- **GOV.UK Design System** — visual language
- **National Energy System Operator (NESO)** — UK live grid data
- **ElectricityMaps · Ember Climate** — non-UK grid data
- **Research watcher allow-list** — gov.uk, Defra, DESNZ, Ofgem, EC Open Publications, EEA, JRC, Eurostat, ADEME, UK Parliament Library
