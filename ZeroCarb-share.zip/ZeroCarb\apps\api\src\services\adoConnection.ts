import { configuredOrgUrl, configuredProject, parseOrgUrl, resolveAdoPat } from './adoClient';
import { getSecretStore } from '../lib/secrets';
import { logger } from '../logger';
import type { Repository } from '../repo/types';

export interface AdoConnection {
  organization: string;
  org_url: string;
  project: string;
  pat: string;
  validated_at?: string;
  source?: string;
}

/**
 * Stored connection (metadata in the repository, PAT in Secrets Manager — never in the table).
 * An env/secret-provisioned PAT is promoted to a connection on first use so operators need not re-enter it.
 */
export async function getConnection(repo: Repository): Promise<AdoConnection | null> {
  let record = null;
  try {
    record = await repo.getConnection();
  } catch (err) {
    logger.error({ err }, 'getConnection: repository read failed');
    return null;
  }

  if (record) {
    const pat = await getSecretStore().get('ado_pat');
    if (!pat) return null;
    return {
      organization: String(record.organization ?? ''),
      org_url: String(record.org_url ?? ''),
      project: String(record.project ?? ''),
      pat,
      validated_at: record.validated_at,
      source: record.source,
    };
  }

  const pat = await resolveAdoPat();
  const orgUrl = configuredOrgUrl();
  const organization = orgUrl ? parseOrgUrl(orgUrl) : null;
  if (!pat || !organization) return null;

  const bootstrapped = {
    organization, org_url: orgUrl, project: configuredProject(),
    validated_at: new Date().toISOString(), source: 'env',
  };
  try {
    await repo.upsertConnection(bootstrapped);
  } catch (err) {
    logger.error({ err }, 'getConnection: failed to persist bootstrapped connection');
  }
  return { ...bootstrapped, pat };
}

export async function saveConnection(
  repo: Repository, c: { organization: string; org_url: string; project: string; pat: string; validated_at: string },
): Promise<void> {
  await getSecretStore().put('ado_pat', c.pat);
  await repo.upsertConnection({ organization: c.organization, org_url: c.org_url, project: c.project, validated_at: c.validated_at, source: 'user' });
}

export async function deleteConnection(repo: Repository): Promise<void> {
  await repo.deleteConnection();
  await getSecretStore().clear('ado_pat');
}
