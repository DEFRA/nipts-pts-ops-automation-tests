import { envStr } from '../config';
import { DynamoRepository } from './dynamo';
import { MemoryRepository } from './memory';
import type { Repository } from './types';

let instance: Repository | undefined;

/** DynamoDB when TABLE_EXECUTIONS is set; in-memory otherwise (local dev / tests). */
export function getRepository(): Repository {
  if (!instance) {
    instance = envStr('TABLE_EXECUTIONS')
      ? new DynamoRepository({
        carbon: envStr('TABLE_CARBON'),
        executions: envStr('TABLE_EXECUTIONS'),
        deferred: envStr('TABLE_DEFERRED'),
        connections: envStr('TABLE_CONNECTIONS'),
        audit: envStr('TABLE_AUDIT'),
      })
      : new MemoryRepository();
  }
  return instance;
}

export function setRepository(repo: Repository | undefined): void {
  instance = repo;
}
