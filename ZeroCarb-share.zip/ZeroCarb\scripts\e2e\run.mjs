// Orchestrates an end-to-end run: mock ADO + API (in-memory) + static SPA server, then the browser test.
//   npm run test:e2e           (requires `npm run build` first; browser via CHROME_PATH or E2E_BROWSER_CHANNEL)
import { spawn } from 'node:child_process';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { startMockAdo } from './mock-ado.mjs';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '..', '..');
const children = [];

async function waitFor(url, ms = 20_000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    try { if ((await fetch(url)).ok) return; } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 300));
  }
  throw new Error(`Timed out waiting for ${url}`);
}

function start(cmd, args, env = {}) {
  const child = spawn(cmd, args, { cwd: root, env: { ...process.env, ...env }, stdio: ['ignore', 'inherit', 'inherit'] });
  children.push(child);
  return child;
}

const API_PORT = 7171;
const WEB_PORT = 8181;
let code = 1;
const mock = await startMockAdo(7099);
try {
  start(process.execPath, ['apps/api/dist/server.mjs'], {
    APP_ENV: 'local', AUTH_MODE: 'disabled', PORT: String(API_PORT), LOG_LEVEL: 'warn', RUN_TIMERS: 'false',
    CORS_ALLOWED_ORIGINS: `http://localhost:${WEB_PORT}`,
    ADO_BASE_URL: 'http://localhost:7099', ADO_ORG_URL: 'https://dev.azure.com/contoso', ADO_PROJECT: 'Demo', ADO_PIPELINE_IDS: '',
    DEV_SEED_ENABLED: 'true', AZURE_DEVOPS_PAT: '',
  });
  start(process.execPath, ['scripts/static-server.mjs', String(WEB_PORT)], { API_URL: `http://localhost:${API_PORT}/api` });
  await waitFor(`http://localhost:${API_PORT}/api/health`);
  await waitFor(`http://localhost:${WEB_PORT}/config.js`);

  code = await new Promise((res) => start(process.execPath, ['scripts/e2e/e2e.mjs'], {
    E2E_URL: `http://localhost:${WEB_PORT}/Carbon%20Cost%20Dashboard.html`,
  }).on('exit', (c) => res(c ?? 1)));
} finally {
  mock.close();
  for (const c of children) c.kill();
}
process.exit(code);
