// End-to-end smoke test for the Azure DevOps integration + clean-slate gating.
// Uses playwright-core with a system browser.
//
// Run:  npm run build && npm run test:e2e      (orchestrated by scripts/e2e/run.mjs)
// Env:  CHROME_PATH            explicit browser executable, or
//       E2E_BROWSER_CHANNEL    'msedge' (default) | 'chrome'
//       E2E_URL                dashboard URL (default http://localhost:8080/)
//       E2E_SHOTS_DIR          screenshot output (default ./e2e-shots)

import { mkdirSync } from 'node:fs';
import { chromium } from 'playwright-core';

const URL = process.env.E2E_URL ?? 'http://localhost:8080/Carbon%20Cost%20Dashboard.html';
const SHOTS = process.env.E2E_SHOTS_DIR ?? './e2e-shots';
mkdirSync(SHOTS, { recursive: true });

const results = [];
function check(name, cond, detail = '') {
  results.push({ name, ok: !!cond, detail });
  console.log((cond ? 'PASS ' : 'FAIL ') + name + (detail ? '  — ' + detail : ''));
}

const sleep = (ms) => new Promise(r => setTimeout(r, ms));

const browser = await chromium.launch(
  process.env.CHROME_PATH
    ? { executablePath: process.env.CHROME_PATH, headless: true }
    : { channel: process.env.E2E_BROWSER_CHANNEL ?? 'msedge', headless: true },
);
const page = await browser.newPage({ viewport: { width: 1400, height: 1000 } });
page.setDefaultTimeout(8000);

const consoleErrors = [];
page.on('console', m => {
  if (m.type() !== 'error') return;
  const t = m.text();
  // Ignore expected handled API error statuses (the error-path test deliberately
  // triggers a 400; 401/409 are also surfaced and handled in the UI, not crashes).
  if (/status of (400|401|409)/.test(t)) return;
  consoleErrors.push(t);
});
page.on('pageerror', e => consoleErrors.push('PAGEERROR: ' + e.message));

async function loadApp() {
  // CDN (unpkg) + in-browser Babel can occasionally glitch (ERR_NETWORK_CHANGED)
  // in the sandbox; retry the whole load until the app shell renders.
  for (let attempt = 1; attempt <= 4; attempt++) {
    try {
      await page.goto(URL, { waitUntil: 'domcontentloaded', timeout: 30000 });
      await page.locator('.ccd-masthead').first().waitFor({ timeout: 15000 });
      await sleep(1500); // bootstrap /api/ado/status probe
      return true;
    } catch (e) {
      console.log('  (load attempt ' + attempt + ' failed: ' + e.message.split('\n')[0] + ' — retrying)');
      await sleep(1500);
    }
  }
  return false;
}

try {
  const loaded = await loadApp();
  check('0. App shell renders (React+Babel loaded)', loaded);
  if (!loaded) throw new Error('app shell never rendered');

  // 1. Clean-slate gate visible, utility locked.
  const gateTitle = await page.locator('.connect-gate-title').first().textContent().catch(() => null);
  check('1. Clean-slate gate shown on first launch', /connect azure devops/i.test(gateTitle || ''), gateTitle);
  const lockedLinks = await page.locator('.service-menu-link.disabled').count();
  check('1b. Service menu locked until connected', lockedLinks >= 3, lockedLinks + ' locked links');
  await page.screenshot({ path: SHOTS + '/01-gate.png' });

  // 2. Error path: bad Org URL → clear error message (retry past network flake).
  await page.locator('.connect-gate button.btn').first().click();
  await sleep(400);
  let errText = null;
  for (let attempt = 1; attempt <= 4 && !/parse|organization/i.test(errText || ''); attempt++) {
    // A URL the org parser genuinely rejects (has a host but isn't dev.azure.com).
    await page.locator('.modal .form-field').first().fill('http://example.com/not-ado');
    await page.locator('.modal input[type=password]').fill('dummy');
    await page.locator('.modal .modal-foot button.btn').last().click().catch(() => {});
    await sleep(1500);
    errText = await page.locator('.modal .inline-notice.error').first().textContent().catch(() => null);
    if (!errText) await sleep(600);
  }
  check('2. Invalid Org URL shows a clear error', /connection failed|could not parse|organization/i.test(errText || ''), (errText || '').replace(/\s+/g, ' ').slice(0, 90));
  await page.screenshot({ path: SHOTS + '/02-error.png' });

  // 3. Happy path: valid org + PAT connects (dev mode). Retry the round-trip
  // because the sandbox localhost fetch can transiently ERR_NETWORK_CHANGED.
  let connected = false;
  for (let attempt = 1; attempt <= 5 && !connected; attempt++) {
    // Ensure the Azure Configuration modal is open.
    if (await page.locator('.modal').count() === 0) {
      await page.locator('.ccd-mast-action', { hasText: /Azure/ }).first().click().catch(() => {});
      await sleep(400);
    }
    await page.locator('.modal .form-field').first().fill('https://dev.azure.com/contoso');
    await page.locator('.modal input[type=password]').fill('devpat');
    await page.locator('.modal .modal-foot button.btn').last().click().catch(() => {});
    // Wait for either the success badge or the phase banner flipping to LIVE.
    for (let i = 0; i < 16 && !connected; i++) {
      await sleep(500);
      const badge = await page.locator('.modal .connect-badge').count().catch(() => 0);
      const phaseTag = await page.locator('.ccd-phase-row .ccd-tag').first().textContent().catch(() => '');
      if (badge > 0 || /live/i.test(phaseTag || '')) connected = true;
    }
    if (!connected) { console.log('  (connect attempt ' + attempt + ' did not land — retrying)'); await sleep(800); }
  }
  check('3. Valid creds connect (dev mode)', connected);
  await page.screenshot({ path: SHOTS + '/03-connected.png' });

  // close modal if still open
  if (await page.locator('.modal').count() > 0) {
    await page.locator('.modal .modal-foot button.btn.ghost').first().click().catch(() => {});
    await sleep(800);
  }

  // 4. Tabs unlock, phase banner LIVE.
  const stillLocked = await page.locator('.service-menu-link.disabled').count();
  check('4. Tabs unlocked after connect', stillLocked === 0, stillLocked + ' locked');
  const phase = await page.locator('.ccd-phase-row .ccd-tag').first().textContent().catch(() => null);
  check('4b. Phase banner shows LIVE', /live/i.test(phase || ''), phase);

  if (!connected) {
    check('SKIP downstream (not connected)', false, 'connection never landed — skipping tab checks');
    throw new Error('not connected — cannot exercise tabs');
  }

  // 5. Pipelines tab — repo-wise dropdown, search, lazy.
  await page.locator('.service-menu-link', { hasText: 'Pipelines' }).click();
  await sleep(1000);
  const subtitle = await page.locator('.page-header').first().innerText().catch(() => '');
  check('5. Pipelines loaded repo-wise (100+)', /pipelines across \d+ reposit/i.test(subtitle), subtitle.replace(/\s+/g, ' ').slice(0, 90));
  await page.locator('.pipeline-select-button').click();
  await sleep(400);
  const groupCount = await page.locator('.pipeline-select-group').count();
  check('5b. Dropdown groups by repository', groupCount >= 2, groupCount + ' repo groups visible');
  await page.locator('.pipeline-select-search input').fill('payments');
  await sleep(400);
  const matchTxt = await page.locator('.pipeline-select-count').textContent().catch(() => '');
  check('5c. Dropdown search filters', /match/i.test(matchTxt), matchTxt);
  await page.screenshot({ path: SHOTS + '/05-pipelines-dropdown.png' });
  // pick first option
  await page.locator('.pipeline-select-option').first().click();
  await sleep(800);

  // 6. Recommendation actions + real-time decide.
  const recVisible = await page.locator('.pipe-drill-rec').count();
  check('6. Recommendation panel present', recVisible >= 1);
  const applyBtn = page.locator('.pipe-drill-rec button.btn', { hasText: 'Apply Recommendation' });
  const onCleanest = await page.locator('.pipe-drill-saving', { hasText: 'already the cleanest' }).count();
  if (await applyBtn.count()) {
    await applyBtn.first().click();
    await page.locator('.action-result.done, .action-result.error').first().waitFor({ timeout: 8000 }).catch(() => {});
    const ar = await page.locator('.action-result').first().textContent().catch(() => '');
    check('6b. Decide action returns real-time status + API response', /decision|saving|selected region|failed/i.test(ar || ''), (ar || '').replace(/\s+/g, ' ').slice(0, 90));
    await page.screenshot({ path: SHOTS + '/06-decision.png' });
  } else {
    check('6b. Actions hidden because home == recommended region', onCleanest >= 1, 'home is cleanest');
  }

  // 7. Regions tab — column rename, no Clean %.
  await page.locator('.service-menu-link', { hasText: 'Regions' }).click();
  await sleep(1200);
  const head = await page.locator('.region-list-head').first().innerText().catch(() => '');
  // CSS text-transform:uppercase means innerText is upper-cased — match case-insensitively.
  check('7. Region column renamed to "Intensity (gCO₂/kWh)"', /intensity \(gco₂\/kwh\)/i.test(head), head.replace(/\s+/g, ' '));
  check('7b. "Clean %" column removed', !/clean\s*%/i.test(head), head.replace(/\s+/g, ' '));
  // duplicate check: region codes unique
  const codes = await page.locator('.region-row .reg-name code').allInnerTexts().catch(() => []);
  const dupes = codes.filter((c, i) => codes.indexOf(c) !== i);
  check('7c. No duplicate region rows', dupes.length === 0, dupes.length ? 'dupes: ' + dupes.join(',') : codes.length + ' unique regions');
  await page.screenshot({ path: SHOTS + '/07-regions.png' });

  // 8. Glossary — placeholder "Search", no header counts.
  await page.locator('.service-menu-link', { hasText: 'Glossary' }).click();
  await sleep(800);
  const ph = await page.locator('input[type=search]').first().getAttribute('placeholder').catch(() => '');
  check('8. Glossary search placeholder is "Search"', ph === 'Search', JSON.stringify(ph));
  const counts = await page.locator('.glossary-section-count').count();
  check('8b. Glossary header counts removed', counts === 0, counts + ' count chips');
  await page.screenshot({ path: SHOTS + '/08-glossary.png' });

  // 9. Research tab hidden.
  const research = await page.locator('.service-menu-link', { hasText: 'Research' }).count();
  check('9. Research tab hidden from nav', research === 0);

  // 10. No console/runtime errors.
  check('10. No console/runtime errors', consoleErrors.length === 0, consoleErrors.slice(0, 3).join(' | '));

} catch (e) {
  check('FATAL', false, e.message);
  try { await page.screenshot({ path: SHOTS + '/fatal.png' }); } catch { /* best effort */ }
} finally {
  await browser.close();
  const passed = results.filter(r => r.ok).length;
  console.log('\n==== ' + passed + '/' + results.length + ' checks passed ====');
  if (consoleErrors.length) {
    console.log('\nConsole errors:');
    consoleErrors.slice(0, 10).forEach(e => console.log('  - ' + e));
  }
  process.exit(passed === results.length ? 0 : 1);
}
