/* global React, Atoms, useStore */
// =======================================================================
// Regions tab — live region grid + 24h forecast.
// 100% API-driven (no fixtures):
//   - GET /api/carbon?provider=<tweaks.provider>     -> region intensity grid
//   - GET /api/forecast?region=<homeId>              -> 24h NESO forecast
// Each region's "Make as Home" action updates the `home_region` tweak.
// NOTE: the "Strategy Mix" section (consumed /api/overview strategy_mix) was
// removed and parked in to_be_deleted/region-strategy-mix.jsx for future reuse.
// =======================================================================

const { PageHeader } = Atoms;

// Accessible, text-first intensity band (no colour-only encoding).
function intensityBand(v) {
  if (v == null) return '—';
  if (v <= 50)  return 'Very low';
  if (v <= 150) return 'Low';
  if (v <= 250) return 'Moderate';
  if (v <= 400) return 'High';
  return 'Very high';
}

function useLiveRegions(provider) {
  const [state, setState] = React.useState({ regions: [], loading: true, error: null });

  React.useEffect(() => {
    let cancelled = false;
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured()) {
      setState({ regions: [], loading: false, error: 'no_api_url' });
      return undefined;
    }
    setState(s => ({ ...s, loading: true }));
    api.carbon({ provider }).then((res) => {
      if (cancelled) return;
      if (!res.ok || !res.data || !Array.isArray(res.data.regions)) {
        setState({ regions: [], loading: false, error: res.error || 'bad_payload' });
        return;
      }
      // De-duplicate by region code (guards against a region appearing twice,
      // e.g. uksouth/ukwest rendering more than once in the grid + charts).
      const seen = Object.create(null);
      const regions = [];
      for (const live of res.data.regions) {
        if (!live || !live.code || seen[live.code]) continue;
        seen[live.code] = true;
        const liveIntensity = live.intensity_gco2_kwh ?? live.grid_intensity_gco2_kwh;
        regions.push({
          id: live.code,
          name: live.display_name || live.code,
          country: live.country_code || '',
          intensity: typeof liveIntensity === 'number' ? liveIntensity : null,
          renewable: typeof live.renewable_pct === 'number' ? live.renewable_pct : null,
          source: live.source || null,
          sampledAt: live.sampled_at || null
        });
      }
      setState({ regions, loading: false, error: null });
    });
    return () => { cancelled = true; };
  }, [provider]);

  return state;
}

function useLiveForecast(region) {
  const [state, setState] = React.useState({ periods: [], source: 'none' });

  React.useEffect(() => {
    const api = (typeof window !== 'undefined') && window.greenQaApi;
    if (!api || !api.isConfigured() || !region) return undefined;
    let cancelled = false;
    api.forecast({ region }).then((res) => {
      if (cancelled) return;
      if (!res.ok || !res.data || !Array.isArray(res.data.periods)) {
        setState({ periods: [], source: 'none' });
        return;
      }
      setState({ periods: res.data.periods, source: res.data.source || 'neso' });
    });
    return () => { cancelled = true; };
  }, [region]);

  return state;
}

function RegionsAndForecast({ tweaks }) {
  const { setTweak, toast } = useStore();
  const homeId = tweaks.home_region || 'uksouth';

  const { regions: REGIONS, loading, error: liveError } = useLiveRegions(tweaks.provider || 'azure');
  const { periods: forecastPeriods, source: forecastSource } = useLiveForecast(homeId);

  // Regions may have a null intensity until the first sample is ingested;
  // sort those to the end so the cleanest known region ranks first.
  const sorted = [...REGIONS].sort((a, b) => {
    if (a.intensity == null) return 1;
    if (b.intensity == null) return -1;
    return a.intensity - b.intensity;
  });
  const home = REGIONS.find(r => r.id === homeId) || sorted[0];

  const onMakeHome = (id) => {
    if (id === homeId) return;
    setTweak('home_region', id);
    toast({
      kind: 'success',
      title: 'Home region updated',
      message: 'Set ' + id + ' as your home region.',
      ttl: 2400
    });
  };

  const subtitle = 'Grid carbon intensity across ' + REGIONS.length + ' '
    + (tweaks.provider || 'azure') + ' regions.';

  return (
    <section aria-label="Regions">
      <PageHeader title="Regions" subtitle={subtitle} />

      {loading && <p className="muted" role="status">Loading regions…</p>}
      {!loading && liveError && liveError !== 'no_api_url' && (
        <p className="inline-notice error" role="alert">
          Could not load the carbon feed ({liveError}).
        </p>
      )}
      {!loading && !liveError && REGIONS.length === 0 && (
        <p className="inline-notice" role="status">No regions returned by the carbon feed yet.</p>
      )}

      {REGIONS.length > 0 && (
        <div className="region-board">
          <div className="region-list-wrap">
            <div className="region-list-head region-list-head-3col">
              <span>#</span>
              <span>Region</span>
              <span>Intensity (gCO₂/kWh)</span>
              <span aria-label="Actions">Action</span>
            </div>
            <ol className="region-list compact">
              {sorted.map((r, i) => {
                const isBest = i === 0 && r.intensity != null;
                const isHome = r.id === homeId;
                return (
                  <li
                    key={r.id}
                    className={'region-row region-row-3col' + (isBest ? ' best' : '') + (isHome ? ' home' : '')}
                    title={r.name + (r.country ? ' · ' + r.country : '')}
                  >
                    <span className="rank">{i + 1}</span>
                    <span className="reg-name">
                      <code>{r.id}</code>
                      {isHome && <span className="reg-flag home-flag" aria-label="Home region">Home</span>}
                      {isBest && <span className="reg-flag best-flag" aria-label="Cleanest region">Cleanest</span>}
                    </span>
                    <span className="reg-intensity-col">
                      <span className="reg-int">{r.intensity != null ? r.intensity : '—'}</span>
                      <span className="reg-band">{intensityBand(r.intensity)}</span>
                    </span>
                    <span className="reg-action">
                      {isHome ? (
                        <span className="muted" aria-label="Already home region">Home</span>
                      ) : (
                        <button
                          type="button"
                          className="btn ghost reg-make-home"
                          onClick={() => onMakeHome(r.id)}
                          aria-label={'Make ' + r.id + ' your home region'}
                        >
                          Make as Home
                        </button>
                      )}
                    </span>
                  </li>
                );
              })}
            </ol>
          </div>

          <Forecast24h
            forecast={forecastPeriods}
            region={home}
            source={forecastSource}
          />
        </div>
      )}
    </section>
  );
}

function Forecast24h({ forecast, region, source }) {
  // Backend NESO periods carry `intensity_gco2_kwh`; fixture carries `intensity`.
  const periods = forecast.map((f, i) => ({
    hour: typeof f.hour === 'number' ? f.hour : i,
    intensity: typeof f.intensity_gco2_kwh === 'number' ? f.intensity_gco2_kwh : f.intensity,
    isOptimal: f.is_optimal || f.isOptimal,
    from: f.from
  }));
  if (!periods.length) {
    return (
      <div className="forecast">
        <h3>24-hour grid forecast · {region?.id || '—'}</h3>
        <div className="muted">No forecast data available.</div>
      </div>
    );
  }
  const max = Math.max(...periods.map(f => f.intensity));
  const min = Math.min(...periods.map(f => f.intensity));
  const optimalStart = periods.findIndex(f => f.isOptimal);
  const optimalEnd = optimalStart === -1
    ? -1
    : periods.length - 1 - [...periods].reverse().findIndex(f => f.isOptimal);
  const savingPct = region?.intensity
    ? Math.round((1 - min / region.intensity) * 100)
    : 0;

  return (
    <div className="forecast">
      <h3>24-hour grid forecast · {region?.id || '—'}</h3>
      <div className="forecast-sub">
        Hourly gCO₂/kWh · sourced from {source === 'neso' ? 'NESO (api.carbonintensity.org.uk)'
                                      : source === 'modelled' ? 'modelled diurnal curve'
                                      : source === 'fixture' ? 'fixture curve'
                                      : 'live feed'}
      </div>

      {optimalStart >= 0 && (
        <div className="forecast-window-callout">
          <strong>
            Optimal window: {String(optimalStart).padStart(2, '0')}–{String(optimalEnd + 1).padStart(2, '0')}
          </strong> · defer non-critical builds for
          <strong style={{ color: 'var(--gov-green-2)' }}> −{savingPct}% emissions</strong>
        </div>
      )}

      <div className="forecast-chart" role="img" aria-label="24-hour carbon intensity forecast">
        {periods.map((f, i) => {
          const h = Math.max(8, (f.intensity / max) * 130);
          return (
            <div
              key={i}
              className={'forecast-bar' + (f.isOptimal ? ' optimal' : '')}
              style={{ height: h + 'px' }}
              title={(f.from || (String(i).padStart(2, '0') + ':00')) + ' — ' + f.intensity.toFixed(0) + ' gCO₂/kWh'
                     + (f.isOptimal ? ' (optimal window)' : '')}
            />
          );
        })}
      </div>
      <div className="forecast-x">
        {periods.map((_, i) => <span key={i}>{String(i % 24).padStart(2, '0')}</span>)}
      </div>

      <div className="forecast-legend">
        <span className="forecast-legend-item">
          <span className="forecast-legend-swatch" aria-hidden="true" /> Bar height = gCO₂/kWh (taller is dirtier)
        </span>
        <span className="forecast-legend-item">
          <span className="forecast-legend-swatch optimal" aria-hidden="true" /> Optimal low-carbon window
        </span>
      </div>
    </div>
  );
}

window.RegionsAndForecast = RegionsAndForecast;
